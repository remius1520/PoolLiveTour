found=0
for p in $(paths); do
  if [ -f "$p/pp_cap.txt" ]; then
    echo "== $p/pp_cap.txt"; cat "$p/pp_cap.txt"
    cp -f "$p/pp_cap.txt" /sdcard/Download/pp_cap.txt 2>/dev/null
    found=1; break
  fi
done
[ $found = 0 ] && echo "(no pp_cap.txt yet)"
