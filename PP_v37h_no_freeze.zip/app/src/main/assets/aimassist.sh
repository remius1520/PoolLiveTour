# Aim assist (the game's OWN target line), ported from AimTool_100 (Patcher.kt: AA_MOV_RVA / AA_DRAW_RVA).
# It changes only the draw call inside CueBall.get_canDrawTarget, so every other reader of the aim-assist state (e.g. the game's bot) still sees the real value.
# One press toggles: original -> patched -> original. Nothing is written unless BOTH original words match and the libil2cpp fingerprint matches.
AA_MOV=0x5DD6EC0; AA_DRAW=0x5DD6EC8; FP=0x5D25340
if [ -z "$pid" ]; then echo "ERROR: اللعبة مش شغالة (افتحها وادخل ماتش الأول)"; exit 1; fi
rd4() { dd if=/proc/$pid/mem bs=1 skip=$(( $1 )) count=4 2>/dev/null | od -An -v -tx1 | tr -d ' \n'; }
wr4() { echo "$2" | base64 -d | dd of=/proc/$pid/mem bs=4 seek=$(( $1 / 4 )) conv=notrunc 2>/dev/null; }
BASE=""
for s in $(grep libil2cpp.so /proc/$pid/maps | cut -d- -f1 | sort -u); do
  b=$(( 0x$s ))
  if [ "$(rd4 $((b+FP)))" = "002440bd" ] && [ "$(rd4 $((b+FP+4)))" = "c0035fd6" ] && [ "$(rd4 $((b+FP+140)))" = "002c40bd" ] && [ "$(rd4 $((b+FP+144)))" = "c0035fd6" ]; then BASE=$b; break; fi
done
if [ -z "$BASE" ]; then echo "ERROR: بصمة libil2cpp مش متطابقة (نسخة تانية من اللعبة؟). ما اتكتبش حاجة."; exit 1; fi
A1=$((BASE+AA_MOV)); A2=$((BASE+AA_DRAW)); c1=$(rd4 $A1); c2=$(rd4 $A2)
if [ "$c1" = "e1031faa" ] && [ "$c2" = "561ffe17" ]; then
  wr4 $A2 wANf1g==      # the ret first, then the mov: every moment in between is safe
  wr4 $A1 IACAUg==
  echo "ايم اسيست: شغّال (خط الهدف بتاع اللعبة ظاهر) - تحقق: $(rd4 $A1) $(rd4 $A2)"
elif [ "$c1" = "20008052" ] && [ "$c2" = "c0035fd6" ]; then
  wr4 $A1 4QMfqg==      # reverse order when switching off
  wr4 $A2 Vh/+Fw==
  echo "ايم اسيست: مقفول (رجع الأصلي) - تحقق: $(rd4 $A1) $(rd4 $A2)"
else
  echo "ERROR: التعليمات مش الأصلية ولا المعدّلة ($c1 $c2). ما اتكتبش حاجة."; exit 1
fi
echo "ملحوظة: التعديل في ذاكرة اللعبة بس؛ لو قفلت اللعبة وفتحتها اضغط الزر تاني."
