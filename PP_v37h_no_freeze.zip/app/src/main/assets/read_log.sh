found=0
for p in $(paths); do
  if [ -f "$p/pp_log.txt" ]; then echo "== $p/pp_log.txt"; tail -n 40 "$p/pp_log.txt"; found=1; break; fi
done
echo "== logcat (tag PremiumPath: the payload mirrors every stage here, so this works even if the file is not reachable)"
logcat -d -s PremiumPath:I 2>/dev/null | tail -n 30
[ $found = 0 ] && echo "(no pp_log.txt reachable from root; use the logcat lines above)"
