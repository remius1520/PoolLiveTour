found=0
for p in $(paths); do
  if [ -f "$p/pp_shots.txt" ]; then
    echo "== $p/pp_shots.txt"; tail -c 60000 "$p/pp_shots.txt"
    cp -f "$p/pp_shots.txt" /sdcard/Download/pp_shots.txt 2>/dev/null
    found=1; break
  fi
done
[ $found = 0 ] && echo "(no pp_shots.txt yet: take a few shots first)"
