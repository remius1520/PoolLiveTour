found=0
for p in $(paths); do
  if [ -f "$p/pp_log.txt" ]; then grep "\[10\] power:" "$p/pp_log.txt" | tail -n 8; found=1; break; fi
done
[ $found = 0 ] && logcat -d -s PremiumPath:I 2>/dev/null | grep "\[10\] power:" | tail -n 8
