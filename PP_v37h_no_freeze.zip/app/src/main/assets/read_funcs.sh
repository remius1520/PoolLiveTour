found=0
for p in $(paths); do
  if [ -f "$p/pp_funcs.txt" ]; then
    echo "== $p/pp_funcs.txt ($(wc -c < "$p/pp_funcs.txt") bytes)"; head -c 200 "$p/pp_funcs.txt" | head -n 1
    cp -f "$p/pp_funcs.txt" /sdcard/Download/pp_funcs.txt 2>/dev/null && echo "saved: Download/pp_funcs.txt"
    found=1; break
  fi
done
echo "== log lines [7]"
for p in $(paths); do [ -f "$p/pp_log.txt" ] && { grep "\[7\]" "$p/pp_log.txt" | tail -n 8; break; }; done
logcat -d -s PremiumPath:I 2>/dev/null | grep "\[7\]" | tail -n 8
[ $found = 0 ] && echo "(no pp_funcs.txt yet: press the request button, restart the game, wait ~30s, then press this again)"
