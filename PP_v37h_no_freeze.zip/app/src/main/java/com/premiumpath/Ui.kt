package com.premiumpath

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// Shared look: luxury black with a glowing blood-red accent and gold headings. Used by the main screen and the floating panel.
object Ui {
    const val BG = "#07060A"; const val CARD = "#0F0A0E"; const val EDGE = "#4A0F1A"; const val INK = "#160B11"
    const val CYAN = "#FF2A44"      // the accent (glowing blood red). The old name is kept so every call site still compiles.
    const val GREEN = "#E3BE78"     // gold: titles and status text
    const val RED = "#C2283C"       // destructive actions
    const val TEXT = "#F7E9EB"; const val DIM = "#A78B90"

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun shape(c: Context, fill: String, stroke: String?, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(Color.parseColor(fill)); cornerRadius = dp(c, radius).toFloat(); if (stroke != null) setStroke(dp(c, 1), Color.parseColor(stroke))
    }

    // a soft red halo: a faint wide outline around the normal shape (fake glow, no blur needed)
    fun glow(c: Context, fill: String, color: String, radius: Int): LayerDrawable {
        val halo = GradientDrawable().apply {
            setColor(Color.TRANSPARENT); cornerRadius = dp(c, radius + 3).toFloat(); setStroke(dp(c, 3), (Color.parseColor(color) and 0x00FFFFFF) or 0x40000000)
        }
        return LayerDrawable(arrayOf(halo, shape(c, fill, color, radius))).apply { setLayerInset(1, dp(c, 3), dp(c, 3), dp(c, 3), dp(c, 3)) }
    }

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; background = shape(c, CARD, EDGE, 14); setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(c, 8)) }
    }

    // a titled box: gold title, a thin red rule, then the controls of that box
    fun section(c: Context, title: String): LinearLayout = card(c).apply {
        addView(TextView(c).apply { text = title; textSize = 13f; letterSpacing = 0.12f; setTextColor(Color.parseColor(GREEN)); setPadding(0, 0, 0, dp(c, 4)) })
        addView(View(c).apply { setBackgroundColor(Color.parseColor(CYAN)); layoutParams = LinearLayout.LayoutParams(-1, dp(c, 1)).apply { setMargins(0, 0, 0, dp(c, 8)) } })
    }

    fun label(c: Context, t: String, size: Float = 12f, color: String = DIM): TextView = TextView(c).apply { text = t; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, 0, 0, dp(c, 6)) }

    fun chip(c: Context, t: String, selected: Boolean = false, click: () -> Unit): Button = Button(c).apply {
        text = t; textSize = 12f; isAllCaps = false; minWidth = 0; minHeight = 0; minimumWidth = 0; minimumHeight = 0; stateListAnimator = null
        setPadding(dp(c, 6), dp(c, 6), dp(c, 6), dp(c, 6)); gravity = Gravity.CENTER
        setTextColor(Color.parseColor(if (selected) BG else TEXT)); background = shape(c, if (selected) CYAN else INK, if (selected) CYAN else "#B3394D", 10)
        layoutParams = LinearLayout.LayoutParams(0, dp(c, 36), 1f).apply { setMargins(dp(c, 2), dp(c, 2), dp(c, 2), dp(c, 2)) }
        setOnClickListener { click() }
    }

    fun action(c: Context, t: String, color: String = CYAN, click: () -> Unit): Button = Button(c).apply {
        text = t; textSize = 13f; isAllCaps = false; stateListAnimator = null; setTextColor(Color.parseColor(if (color == CYAN) TEXT else color)); background = glow(c, INK, color, 12)
        layoutParams = LinearLayout.LayoutParams(-1, dp(c, 44)).apply { setMargins(0, 0, 0, dp(c, 6)) }
        setOnClickListener { click() }
    }

    // A row of numbered chips. The selected one is lit; pressing one calls pick(n) and re-lights the row.
    fun chipRow(c: Context, values: List<Int>, current: () -> Int, pick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1, -2) }
        val btns = ArrayList<Button>()
        fun paint() { for ((i, b) in btns.withIndex()) { val sel = values[i] == current(); b.setTextColor(Color.parseColor(if (sel) BG else TEXT)); b.background = shape(c, if (sel) CYAN else INK, if (sel) CYAN else EDGE, 10) } }
        for (v in values) { val b = chip(c, v.toString()) { pick(v); paint() }; btns.add(b); row.addView(b) }
        paint(); return row
    }

    // the round face used as the floating button and in the header
    fun face(c: Context, size: Int): ImageView = ImageView(c).apply {
        setImageResource(R.drawable.bubble_face); scaleType = ImageView.ScaleType.CENTER_CROP
        outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) } }
        clipToOutline = true
        foreground = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(c, 2), Color.parseColor(CYAN)) }
        elevation = dp(c, 6).toFloat()
        layoutParams = LinearLayout.LayoutParams(dp(c, size), dp(c, size))
    }
}
