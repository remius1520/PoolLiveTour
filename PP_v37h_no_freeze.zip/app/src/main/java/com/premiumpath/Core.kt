package com.premiumpath

import android.content.Context

// Shared logic used by both the main screen and the floating button. Needs root.
object Core {
    const val pkg = "com.PoolLiveTour"
    var on = 1
    var bounces = 2
    var chain = 2
    var colormode = 0
    var maxlines = 40
    var rings = 1
    var spinsrc = 1
    var calStep = 0              // 0 = idle, 1 = power test running
    private lateinit var app: Context

    fun init(c: Context) { app = c.applicationContext }

    private fun asset(name: String) = app.assets.open(name).bufferedReader().readText()

    // su -mm = Magisk "mount master": run in the global mount namespace (an app-isolated namespace cannot see other apps' data dirs).
    private fun suOnce(args: Array<String>, script: String): String = try {
        val p = ProcessBuilder(*args).redirectErrorStream(true).start()
        p.outputStream.bufferedWriter().use { it.write(script); it.write("\nexit\n") }
        val out = p.inputStream.bufferedReader().readText(); p.waitFor(); out.trim()
    } catch (e: Exception) { "su failed: ${e.message}" }

    fun suScript(script: String): String {
        val r = suOnce(arrayOf("su", "-mm"), script)
        return if (Regex("(?i)(invalid|unknown|unrecognized) option|usage:").containsMatchIn(r.take(300))) suOnce(arrayOf("su"), script) else r
    }

    fun run(name: String, extra: Map<String, String> = emptyMap()): String {
        var s = (asset("pp_common.sh") + "\n" + asset(name)).replace("@PKG@", pkg)
        for ((k, v) in extra) s = s.replace(k, v)
        return suScript(s)
    }

    fun writeCfg(extra: String = ""): String = run("write_cfg.sh", mapOf("@BODY@" to "on=$on\\nbounces=$bounces\\nchain=$chain\\ncolormode=$colormode\\nmaxlines=$maxlines\\nrings=$rings\\n$extra"))

    fun install(): String {
        val r = run("install.sh", mapOf("@LIB@" to app.applicationInfo.nativeLibraryDir + "/libpremiumpath.so"))
        Thread.sleep(6000)                       // the payload already works with defaults; this only applies the chosen settings
        return r + "\n" + writeCfg("pwroff=32\\npwrdiv=0\\nspinsrc=1\\n")
    }

    fun diagnose(): String {
        val r = run("diagnose.sh")
        suScript("cat > /sdcard/Download/pp_report.txt <<'PPEOF'\n" + r + "\nPPEOF")
        return r + "\n(saved: Download/pp_report.txt)"
    }

    // Power calibration: the payload logs horizontalForce(0x20), previewForce(0x24), finalVelocity(0x40) every 3s.
    private fun fmt4(x: Double) = String.format(java.util.Locale.US, "%.4f", x)
    private val fields = listOf("horizontalForce" to 0x20, "previewForce" to 0x24, "finalVelocity" to 0x40)
    private fun stats(): List<Triple<String, Int, DoubleArray>> {
        val txt = run("read_power.sh")
        return fields.map { (n, o) ->
            val v = Regex(n + "@0x[0-9A-Fa-f]+=(-?[0-9.]+)").findAll(txt).mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
            Triple(n, o, if (v.isEmpty()) doubleArrayOf(0.0, 0.0, 0.0) else doubleArrayOf(v.minOrNull()!!, v.maxOrNull()!!, v.size.toDouble()))
        }
    }
    // Spin: the payload reads SpinController / ClientSpinController (found in dump.cs) and logs them as "[12] spin". src 0 = SpinController, 1 = ClientSpinController.
    fun spinRead(): String = run("read_spin.sh").ifBlank { "No [12] spin lines yet. Aim in a match, move the spin point, then try again." }
    fun spinSource(src: Int): String = writeCfg("spinsrc=$src\\n") + "\nspin source = " + (if (src == 0) "SpinController" else if (src == 1) "ClientSpinController" else "off")
    fun powerTest(): String = writeCfg("pwroff=32\\npwrdiv=0\\ndisc=1\\n") + "\nNow in a match: aim, move the power slider from min to max a few times, wait 10s, then press Read power values."
    fun powerRead(): String {
        val st = stats()
        if (st.all { it.third[2] == 0.0 }) return "No [10] power lines yet. Run Power test, aim in a match, then try again."
        return st.joinToString("\n") { (n, o, a) -> "$n @0x${o.toString(16)}: min=${fmt4(a[0])} max=${fmt4(a[1])} samples=${a[2].toInt()}" }
    }
    fun powerApply(): String {
        val best = stats().filter { it.third[2] > 0 }.maxByOrNull { it.third[1] - it.third[0] } ?: return "No data. Run Power test first."
        val range = best.third[1] - best.third[0]
        if (range < 0.01) return "No field changed while you moved the slider. Move it more and read again."
        val r = writeCfg("pwroff=${best.second}\\npwrdiv=0\\n")
        return "Applied: power = ${best.first}@0x${best.second.toString(16)} / levelMaxPower\n$r"
    }

    // One button for power: first press starts the capture, second press applies the field that moved.
    fun powerAuto(): String {
        if (calStep == 0) { calStep = 1; return powerTest() }
        calStep = 0; return powerApply()
    }
    // v26: one-press capture. The payload samples the power / spin fields while the player moves them and dumps the code of the power / spin methods into pp_cap.txt.
    fun capture(step: (String, String) -> Unit): String {
        val id = System.currentTimeMillis() / 1000
        step("بيبدأ القراءة ...", "...")
        val w = writeCfg("cap=$id\\n")
        if (w.contains("ERROR")) return w
        Thread.sleep(3000)                       // the payload sees the new cfg within 1 s, then dumps the methods once (a short hitch in the game)
        for (s in 28 downTo 1) { step("① حرّك سلايدر الباور من الأقل للأقصى ببطء كذا مرة. باقي $s ث", "P$s"); Thread.sleep(1000) }
        for (s in 28 downTo 1) { step("② حرّك نقطة الاسبين: النص، فوق، تحت، شمال، يمين، وارجع للنص. باقي $s ث", "S$s"); Thread.sleep(1000) }
        step("بيحفظ ...", "...")
        Thread.sleep(6000)
        return capRead()
    }
    // v29: the shot recorder writes pp_shots.txt (prediction vs what the game really did); this copies it to Download/pp_shots.txt
    fun shotsRead(): String {
        val r = run("read_shots.sh"); val n = Regex("=== SHOT").findAll(r).count()
        return if (n == 0) r.take(300) else "$n تصويبة اتسجلت (Download/pp_shots.txt)"
    }
    // v37: ask the payload to (re)write pp_funcs.txt = machine code of the physics functions; takes effect at the next game start (~30s after launch)
    fun funcsRequest(): String = writeCfg("dumpfn=${System.currentTimeMillis() / 1000}\\n") + "\nدلوقتي اقفل اللعبة وافتحها (الأداة هتعيد تشغيلها لو ضغطت Install)، استنى 30 ثانية، وبعدين اضغط حفظ الدوال."
    fun funcsRead(): String {
        val r = run("read_funcs.sh")
        return if (r.contains("saved:")) r.lines().filter { it.startsWith("==") || it.contains("[7]") || it.startsWith("saved") }.joinToString("\n") else r.take(400)
    }
    fun capRead(): String {
        val r = run("read_cap.sh")
        val i = r.indexOf("--- POWER")
        return if (i < 0) "القراءة ما خلصتش أو الملف مش موجود (لازم تكون في ماتش وفي دورك).\n" + r.take(500) else r.substring(i) + "\n(saved: Download/pp_cap.txt)"
    }
    // v26: aim assist = the game's own target line, ported from AimTool_100. One press toggles it (the script reads the current state itself).
    fun aimAssist(): String = run("aimassist.sh")
    fun spinCycle(): String { spinsrc = (spinsrc + 1) % 3; return spinSource(spinsrc) }
}
