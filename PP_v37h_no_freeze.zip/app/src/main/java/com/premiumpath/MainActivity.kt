package com.premiumpath

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// Control screen for the in-game path lines (needs root). Two boxes (lines, tools) and a gear that reveals the settings box (install / floating button / diagnose / remove).
// Works in portrait and landscape: two columns when the screen is wide.
// All shell logic lives in shell scripts under assets (never put a slash followed by a star in this file: Kotlin block comments nest).
class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun async(label: String, work: () -> String) {
        status.text = "$label ..."
        Thread { val r = work(); runOnUiThread { status.text = "$label\n$r" } }.start()
    }

    private fun showFloating() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "فعّل Display over other apps لـ PremiumPath ثم اضغط الزر تاني."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else { startService(Intent(this, FloatingService::class.java)); status.text = "الزر العايم اشتغل. افتح اللعبة." }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Core.init(this)
        val c = this
        val wide = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels
        status = TextView(this).apply { setTextColor(Color.parseColor(Ui.GREEN)); textSize = 12f; text = "جاهز. محتاج روت." }

        val master = Button(this).apply {
            isAllCaps = false; textSize = 16f; stateListAnimator = null
            fun paint() { text = if (Core.on == 1) "الخطوط: شغّالة" else "الخطوط: مقفولة"; setTextColor(Color.parseColor(if (Core.on == 1) Ui.BG else Ui.DIM)); background = if (Core.on == 1) Ui.glow(c, Ui.CYAN, Ui.CYAN, 16) else Ui.shape(c, Ui.INK, Ui.EDGE, 16) }
            paint(); layoutParams = LinearLayout.LayoutParams(-1, Ui.dp(c, 54)).apply { setMargins(0, 0, 0, Ui.dp(c, 8)) }
            setOnClickListener { Core.on = 1 - Core.on; paint(); async(if (Core.on == 1) "ON" else "OFF") { Core.writeCfg() } }
        }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // settings box: hidden until the gear is pressed
        val settings = Ui.section(c, "الإعدادات والتشغيل").apply {
            visibility = View.GONE
            addView(Ui.action(c, "تثبيت + إعادة تشغيل اللعبة", Ui.GREEN) { async("install") { Core.install() } })
            addView(Ui.action(c, "الزر العايم (وش البنت)") { showFloating() })
            addView(Ui.action(c, "تقرير التشخيص (ابعته لي)") { async("diagnose") { Core.diagnose() } })
            addView(Ui.action(c, "إزالة (رجوع للأصلي)", Ui.RED) { async("remove") { Core.run("remove.sh") } })
        }

        // box 1: the lines
        left.addView(master)
        left.addView(Ui.section(c, "الخطوط").apply {
            addView(Ui.label(c, "عدد الارتدادات (باند)"))
            addView(Ui.chipRow(c, (1..6).toList(), { Core.bounces }) { Core.bounces = it; async("bounces=$it") { Core.writeCfg() } })
            addView(Ui.chipRow(c, (7..12).toList(), { Core.bounces }) { Core.bounces = it; async("bounces=$it") { Core.writeCfg() } })
            addView(Ui.label(c, "عمق الكور (كومبو / كيك / عكسيات)"))
            addView(Ui.chipRow(c, (1..6).toList(), { Core.chain }) { Core.chain = it; async("chain=$it") { Core.writeCfg() } })
            addView(Ui.label(c, "عدد الخطوط الظاهرة"))
            addView(Ui.chipRow(c, listOf(5, 10, 20, 30), { Core.maxlines }) { Core.maxlines = it; async("lines=$it") { Core.writeCfg() } })
            addView(Ui.chipRow(c, listOf(40, 50, 60), { Core.maxlines }) { Core.maxlines = it; async("lines=$it") { Core.writeCfg() } })
        })

        // box 2: the tools
        right.addView(Ui.section(c, "الأدوات").apply {
            addView(Ui.action(c, "ايم اسيست (خط الهدف الأصلي): شغّال / مقفول", Ui.GREEN) { async("aim assist") { Core.aimAssist() } })
            addView(Ui.action(c, "ألوان: رقم الكورة / حسب الدور") { Core.colormode = 1 - Core.colormode; async("colormode=${Core.colormode}") { Core.writeCfg() } })
            addView(Ui.action(c, "دواير الجيوب: شغّال / مقفول") { Core.rings = 1 - Core.rings; async("rings=${Core.rings}") { Core.writeCfg() } })
            addView(Ui.action(c, "معايرة الباور (اضغط مرتين)") { async("power") { Core.powerAuto() } })
            addView(Ui.action(c, "مصدر الاسبين: تبديل") { async("spin") { Core.spinCycle() } })
            addView(Ui.action(c, "قراءة الناقص: باور + اسبين (دوس وأنت في دورك)", Ui.GREEN) {
                status.text = "..."
                Thread { val r = Core.capture { m, _ -> runOnUiThread { status.text = m } }; runOnUiThread { status.text = "تم\n$r" } }.start()
            })
        })

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(c, 14), Ui.dp(c, 14), Ui.dp(c, 14), Ui.dp(c, 14)); setBackgroundColor(Color.parseColor(Ui.BG)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, Ui.dp(c, 10)) }
        head.addView(Ui.face(c, 46))
        head.addView(TextView(this).apply { text = "PREMIUM PATH"; setTextColor(Color.parseColor(Ui.GREEN)); textSize = 19f; letterSpacing = 0.2f; setPadding(Ui.dp(c, 12), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        head.addView(Ui.chip(c, "⚙ الإعدادات") { settings.visibility = if (settings.visibility == View.GONE) View.VISIBLE else View.GONE }.apply { layoutParams = LinearLayout.LayoutParams(Ui.dp(c, 112), Ui.dp(c, 36)) })
        root.addView(head)
        root.addView(settings)
        if (wide) {
            root.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(left, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, Ui.dp(c, 6), 0) })
                addView(right, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(Ui.dp(c, 6), 0, 0, 0) })
            })
        } else { root.addView(left); root.addView(right) }
        root.addView(status)
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor(Ui.BG)); addView(root) })
    }
}
