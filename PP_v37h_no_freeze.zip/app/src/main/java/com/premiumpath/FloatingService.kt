package com.premiumpath

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// A draggable round face over every app. Tap it to open the control panel: two boxes (lines, tools) and a gear that reveals the settings box.
// The panel has a FIXED size (fixed-height scroll area and a fixed status strip) so its window never resizes while you scroll or press a button.
class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var box: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var out: TextView
    private lateinit var badge: TextView

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun act(label: String, work: () -> String) {
        out.text = "$label ..."
        Thread { val r = work(); out.post { out.text = "$label\n$r" } }.start()
    }

    private fun setBadge(t: String) { badge.text = t; badge.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE }

    override fun onCreate() {
        super.onCreate()
        Core.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val c = this
        val dm = resources.displayMetrics
        val landscape = dm.widthPixels > dm.heightPixels
        val pw = Math.min(dp(if (landscape) 300 else 270), (dm.widthPixels - dp(24)).coerceAtLeast(dp(120)))
        // Reserve space for the bubble, panel padding/header/status strip, and a small safety margin.
        // Keep the scroll area compact on short screens so the complete overlay can still fit.
        val desiredScrollH = (dm.heightPixels * (if (landscape) 0.40f else 0.34f)).toInt()
        val availableScrollH = (dm.heightPixels - dp(196)).coerceAtLeast(dp(64))
        val scrollH = Math.min(desiredScrollH, availableScrollH).coerceAtLeast(dp(64))
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = dp(8); lp.y = dp(160)

        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ---- the round face (+ a small badge that shows the capture countdown) ----
        val bubble = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(dp(58), dp(58)) }
        bubble.addView(Ui.face(c, 56).apply { layoutParams = FrameLayout.LayoutParams(dp(56), dp(56)) })
        badge = TextView(this).apply {
            textSize = 10f; setTextColor(Color.parseColor(Ui.BG)); gravity = Gravity.CENTER; visibility = View.GONE
            setPadding(dp(5), dp(1), dp(5), dp(1)); background = Ui.shape(c, Ui.CYAN, null, 8)
            layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END)
        }
        bubble.addView(badge)

        // ---- panel: header, fixed-height scroll area, fixed status strip ----
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(dp(8), dp(8), dp(8), dp(8))
            background = Ui.glow(c, "#F207060A", Ui.CYAN, 16)
            layoutParams = LinearLayout.LayoutParams(pw, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(6), 0, 0) }
        }
        out = TextView(this).apply { setTextColor(Color.parseColor(Ui.GREEN)); textSize = 13f; text = "جاهز" }

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            visibility = View.GONE                                   // v27: no empty black box while the settings are closed
            overScrollMode = View.OVER_SCROLL_NEVER; isVerticalScrollBarEnabled = true; addView(body)
            layoutParams = LinearLayout.LayoutParams(-1, scrollH)
        }

        // settings box (hidden until the gear is pressed): install / diagnose / remove / close
        val settings = Ui.section(c, "الإعدادات").apply {
            visibility = View.GONE
            addView(Ui.action(c, "تثبيت + إعادة تشغيل اللعبة", Ui.GREEN) { act("install") { Core.install() } })
            addView(Ui.action(c, "تقرير التشخيص") { act("diagnose") { Core.diagnose() } })
            addView(Ui.action(c, "إزالة (رجوع للأصلي)", Ui.RED) { act("remove") { Core.run("remove.sh") } })
            addView(Ui.action(c, "إغلاق الزر العايم", Ui.RED) { stopSelf() })
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutParams = LinearLayout.LayoutParams(-1, dp(40)) }
        header.addView(TextView(this).apply { text = "PREMIUM PATH"; textSize = 12f; letterSpacing = 0.18f; setTextColor(Color.parseColor(Ui.GREEN)); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        header.addView(Ui.chip(c, "⚙ الإعدادات") {
            settings.visibility = if (settings.visibility == View.GONE) View.VISIBLE else View.GONE
            scroll.visibility = settings.visibility
            scroll.post { scroll.scrollTo(0, 0) }
        }.apply { layoutParams = LinearLayout.LayoutParams(dp(112), dp(34)) })

        // box 1: the lines
        val master = Button(this).apply {
            isAllCaps = false; textSize = 14f; stateListAnimator = null
            fun paint() { text = if (Core.on == 1) "الخطوط: شغّالة" else "الخطوط: مقفولة"; setTextColor(Color.parseColor(if (Core.on == 1) Ui.BG else Ui.DIM)); background = if (Core.on == 1) Ui.glow(c, Ui.CYAN, Ui.CYAN, 14) else Ui.shape(c, Ui.INK, Ui.EDGE, 14) }
            paint(); layoutParams = LinearLayout.LayoutParams(-1, dp(46)).apply { setMargins(0, 0, 0, dp(8)) }
            setOnClickListener { Core.on = 1 - Core.on; paint(); act(if (Core.on == 1) "ON" else "OFF") { Core.writeCfg() } }
        }
        val lines = Ui.section(c, "الخطوط").apply {
            addView(master)
            addView(Ui.label(c, "عدد الارتدادات", 11f))
            addView(Ui.chipRow(c, (1..6).toList(), { Core.bounces }) { Core.bounces = it; act("bounces=$it") { Core.writeCfg() } })
            addView(Ui.chipRow(c, (7..12).toList(), { Core.bounces }) { Core.bounces = it; act("bounces=$it") { Core.writeCfg() } })
            addView(Ui.label(c, "عمق الكور", 11f))
            addView(Ui.chipRow(c, (1..6).toList(), { Core.chain }) { Core.chain = it; act("chain=$it") { Core.writeCfg() } })
            addView(Ui.label(c, "عدد الخطوط", 11f))
            addView(Ui.chipRow(c, listOf(5, 10, 20, 30), { Core.maxlines }) { Core.maxlines = it; act("lines=$it") { Core.writeCfg() } })
            addView(Ui.chipRow(c, listOf(40, 50, 60), { Core.maxlines }) { Core.maxlines = it; act("lines=$it") { Core.writeCfg() } })
        }

        // box 2: the tools
        val tools = Ui.section(c, "الأدوات").apply {
            addView(LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL
                addView(Ui.chip(c, "ألوان") { Core.colormode = 1 - Core.colormode; act("colormode=${Core.colormode}") { Core.writeCfg() } })
                addView(Ui.chip(c, "جيوب") { Core.rings = 1 - Core.rings; act("rings=${Core.rings}") { Core.writeCfg() } })
                addView(Ui.chip(c, "باور") { act("power") { Core.powerAuto() } }) })
            addView(LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL
                addView(Ui.chip(c, "اسبين") { act("spin") { Core.spinCycle() } })
                addView(Ui.chip(c, "ايم اسيست") { act("aim assist") { Core.aimAssist() } }) })
            addView(Ui.label(c, "", 4f))
            addView(Ui.action(c, "حفظ تسجيل التصويبات") { act("shots") { Core.shotsRead() } })
            addView(Ui.action(c, "طلب تسجيل دوال الفيزياء") { act("funcs request") { Core.funcsRequest() } })
            addView(Ui.action(c, "حفظ دوال الفيزياء") { act("funcs") { Core.funcsRead() } })
            addView(Ui.action(c, "قراءة الناقص (باور + اسبين)") {
                out.text = "..."
                Thread { val r = Core.capture { m, sh -> out.post { out.text = m; setBadge(sh) } }; out.post { out.text = "تم\n$r"; setBadge("") } }.start()
            })
        }

        settings.addView(lines); settings.addView(tools)
        body.addView(settings)
        val strip = ScrollView(this).apply { addView(out); layoutParams = LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(6), 0, 0) } }
        panel.addView(header); panel.addView(scroll); panel.addView(strip)
        box.addView(bubble); box.addView(panel)

        // drag to move, tap to open or close the panel
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) {
                        val panelOpen = panel.visibility == View.VISIBLE
                        val estimatedW = if (panelOpen) pw else dp(58)
                        val estimatedH = if (panelOpen) dp(58 + 6 + 16 + 40 + 64) + scrollH else dp(58)
                        val actualW = box.width.takeIf { it > 0 } ?: estimatedW
                        val actualH = box.height.takeIf { it > 0 } ?: estimatedH
                        val maxX = (dm.widthPixels - actualW).coerceAtLeast(0)
                        val maxY = (dm.heightPixels - actualH).coerceAtLeast(0)
                        lp.x = (ox + dx).coerceIn(0, maxX)
                        lp.y = (oy + dy).coerceIn(0, maxY)
                        wm.updateViewLayout(box, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    val open = panel.visibility == View.GONE
                    panel.visibility = if (open) View.VISIBLE else View.GONE
                    if (open) {
                        // Wait for measurement, then clamp using the actual overlay size rather than estimates.
                        box.post {
                            val maxX = (dm.widthPixels - box.width).coerceAtLeast(0)
                            val maxY = (dm.heightPixels - box.height).coerceAtLeast(0)
                            lp.x = lp.x.coerceIn(0, maxX)
                            lp.y = lp.y.coerceIn(0, maxY)
                            try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                        }
                    }
                }
            }
            true
        }
        wm.addView(box, lp)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        try { wm.removeView(box) } catch (_: Exception) {}
        super.onDestroy()
    }
}
