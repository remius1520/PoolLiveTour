#!/usr/bin/env python3
"""Replay recorded shots (pp_shots*.txt) through core/predict_core.hpp (via tools/sim_cli.cpp) and print prediction-vs-real errors.

usage: replay_shots.py pp_shots_4.txt [more files] [--cli PATH] [--set key=value ...] [--verbose] [--table pockets.json]
Real power = |PWR_RING 0x28| / |dir.x| (forceDirection magnitude = last pull value, HANDOFF) falling back to the logged power.
A shot is used when the cue ball really moved. Balls that end in the tray (z < -0.85 while starting on the table) count as pocketed.
Exit code 0 always; the table is the product. Summary line: median / p90 cue-end error and ball-end errors in ball radii (R = 0.0325).
"""
import re, sys, os, subprocess, statistics, argparse, math, tempfile

R = 0.0325
PK = [(-0.0022, 0.4516), (-1.1080, 0.4182), (1.1182, 0.4246), (0.0013, -0.7703), (-1.1102, -0.7287), (1.1168, -0.7373)]  # table 5 (dump)

def pairs(s):
    return {int(a): (float(b), float(c)) for a, b, c in re.findall(r'(-?\d+):(-?[\d.]+),(-?[\d.]+)', s)}

def parse(path):
    shots, cur = [], None
    for ln in open(path, encoding='utf-8', errors='replace'):
        ln = ln.rstrip('\n')
        m = re.match(r'=== SHOT (\d+) \(([^)]*)\) after ([\d.]+)s \| power=([\d.]+) dir=\(([-\d.]+),([-\d.]+)\) spin=\(([-\d.]+),([-\d.]+)\).*cue0=\(([-\d.]+),([-\d.]+)\)', ln)
        if m:
            cur = dict(n=int(m[1]), why=m[2], dur=float(m[3]), power=float(m[4]), dir=(float(m[5]), float(m[6])), spin=(float(m[7]), float(m[8])), cue0=(float(m[9]), float(m[10])), ring=None)
            shots.append(cur); continue
        if cur is None: continue
        if ln.startswith('BALLS0'): cur['b0'] = pairs(ln[6:])
        elif ln.startswith('BALLS_END'): cur['b1'] = pairs(ln[9:])
        elif ln.startswith('PWR_RING'):
            rows = [r.split('/') for r in ln.split(':', 1)[1].split()]
            cur['ring'] = [float(r[3]) for r in rows if len(r) >= 5]
        elif ln.startswith('PWR_LATCH'):
            m2 = re.search(r'real power=([\d.]+)', ln)
            if m2: cur['latch'] = float(m2[1])
        elif ln.startswith('CUE_REAL'):
            cur['cue'] = [tuple(map(float, t.split(','))) for t in ln.split(':', 1)[1].split()]
    return shots

def real_power(s, vmax):
    if s.get('latch') is not None and s['latch'] > 0.005: return s['latch'] * vmax   # payload v37 logs |forceDirection|/levelMaxPower after the shot
    dx = s['dir'][0]
    if s['ring'] and abs(dx) > 0.3:
        mag = abs(s['ring'][-1] / dx)
        if 0.1 < mag < 20: return mag
    return s['power'] * vmax

def run(cli, s, balls0, speed, opts):
    inp = ''.join('PK %f %f\n' % p for p in PK)
    inp += ''.join('BALL %d %f %f %f\n' % (i, p[0], p[1], R) for i, p in balls0.items() if i != 0)
    inp += 'CUE %f %f %f\nSHOT %f %f %f\n' % (*balls0[0], R, s['dir'][0], s['dir'][1], speed)
    out = subprocess.run([cli] + opts, input=inp, capture_output=True, text=True, check=True).stdout
    fin = {}
    for l in out.splitlines():
        t = l.split()
        if t and t[0] == 'FINAL': fin[0 if t[1] == '-1' else int(t[1])] = (float(t[2]), float(t[3]), bool(int(t[4])))
    return fin, out

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('files', nargs='+'); ap.add_argument('--cli', default=None); ap.add_argument('--set', nargs='*', default=[]); ap.add_argument('--verbose', action='store_true'); ap.add_argument('--vmax', type=float, default=4.3)
    a = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__)); cli = a.cli
    if not cli:
        cli = os.path.join(tempfile.gettempdir(), 'pp_sim_cli')
        subprocess.run(['g++', '-std=c++17', '-O2', '-o', cli, os.path.join(here, 'sim_cli.cpp')], check=True)
    cue_err, ball_err, rows = [], [], []
    for f in a.files:
        for s in parse(f):
            if 'b0' not in s or 'b1' not in s or 'cue' not in s: continue
            if len(s['cue']) < 3 or max(math.hypot(c[0] - s['cue'][0][0], c[1] - s['cue'][0][1]) for c in s['cue']) < 0.05: continue
            b0 = dict(s['b0']); b0[0] = s['cue0']
            sp = real_power(s, a.vmax)
            fin, out = run(cli, s, b0, sp, a.set)
            line = ['shot %3d speed %.3f' % (s['n'], sp)]
            for i, p1 in sorted(s['b1'].items()):
                p0 = b0.get(i, p1)
                real_in_tray = p1[1] < -0.85 and p0[1] >= -0.85
                if i not in fin: continue
                fx, fz, pk = fin[i]
                moved_real = math.hypot(p1[0] - p0[0], p1[1] - p0[1]) > 0.01
                if not (moved_real or pk or math.hypot(fx - p0[0], fz - p0[1]) > 0.01): continue
                if real_in_tray or pk:
                    ok = real_in_tray == pk
                    line.append('b%d:%s' % (i, 'POT-ok' if ok and pk else ('POT-MISS(real %s, pred %s)' % ('pot' if real_in_tray else 'no', 'pot' if pk else 'no'))))
                    if i == 0 and not real_in_tray: pass
                    continue
                e = math.hypot(fx - p1[0], fz - p1[1]) / R
                (cue_err if i == 0 else ball_err).append(e)
                line.append('b%d:%.1fR' % (i, e))
            rows.append(' '.join(line))
    print('\n'.join(rows))
    def st(x): return 'n=%d median %.1fR p90 %.1fR' % (len(x), statistics.median(x), sorted(x)[int(0.9 * (len(x) - 1))]) if x else 'n=0'
    print('cue end error:   ', st(cue_err)); print('other balls error:', st(ball_err))

if __name__ == '__main__': main()
