// Command line front end of core/predict_core.hpp, used by tools/replay_shots.py.
//   args: key=value overrides (drag vmax keep ballkeep distf mincuesin gamecue inset corner mid gapc gapm minspeed dt xmin xmax zmin zmax)
//   stdin: PK x z | BALL id x z r | CUE x z r | SHOT dx dz speed        (one SHOT per run, may be several; each starts from the same position)
//   stdout: for every SHOT: FINAL id x z pocketed pocketIdx tRest ... and TRACK id gen end hitId pocket n x z x z ...
#include "../core/predict_core.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <map>
#include <sstream>
#include <iostream>
using namespace pp;
int main(int argc, char** argv) {
    std::map<std::string, double> o;
    for (int i = 1; i < argc; ++i) { std::string a = argv[i]; auto e = a.find('='); if (e != std::string::npos) o[a.substr(0, e)] = std::atof(a.c_str() + e + 1); }
    auto g = [&](const char* k, double d) { auto it = o.find(k); return it == o.end() ? d : it->second; };
    std::vector<V2> pk; std::vector<BallIn> balls; V2 cue{0, 0}; double cr = 0.0325;
    Config C; C.drag = g("drag", 0.62); C.vMax = g("vmax", 4.3); C.cushionKeep = g("keep", 0.92); C.ballKeep = g("ballkeep", 0.92);
    C.distFactor = g("distf", 1.0); C.minCueSin = g("mincuesin", 0.04); C.gameCueSpeed = g("gamecue", 1) > 0.5; C.minSpeed = g("minspeed", 0.03);
    C.dt = g("dt", 1.0 / 240.0); C.maxBounces = (int)g("bounces", 99); C.maxChain = (int)g("chain", 99);
    std::string line; std::vector<std::string> shots;
    while (std::getline(std::cin, line)) {
        std::istringstream ss(line); std::string k; ss >> k;
        if (k == "PK") { V2 p; ss >> p.x >> p.z; pk.push_back(p); }
        else if (k == "BALL") { BallIn b; ss >> b.id >> b.p.x >> b.p.z >> b.r; balls.push_back(b); }
        else if (k == "CUE") { ss >> cue.x >> cue.z >> cr; }
        else if (k == "SHOT") shots.push_back(line);
    }
    Table T = o.count("xmin") ? Table::fromLimits(pk, g("xmin", 0), g("xmax", 0), g("zmin", 0), g("zmax", 0), g("corner", 0.12), g("mid", 0.10), g("gapc", 0.11), g("gapm", 0.07))
                              : Table::fromPockets(pk, g("inset", 0.085), g("corner", 0.12), g("mid", 0.10), g("gapc", 0.11), g("gapm", 0.07));
    for (auto& s : shots) {
        std::istringstream ss(s); std::string k; double dx, dz, sp; ss >> k >> dx >> dz >> sp;
        Sim sim(T, C, balls, cue, cr); Result R = sim.runSpeed({dx, dz}, sp);
        std::printf("RUN\n");
        for (auto& f : R.finals) std::printf("FINAL %d %.5f %.5f %d %d %.3f\n", f.id, f.p.x, f.p.z, (int)f.pocketed, f.pocket, f.tRest);
        for (auto& t : R.tracks) { std::printf("TRACK %d %d %d %d %d %.3f %.3f %zu", t.id, t.gen, (int)t.end, t.hitId, t.pocket, t.t0, t.t1, t.pts.size()); for (auto& p : t.pts) std::printf(" %.5f %.5f", p.x, p.z); std::printf("\n"); }
    }
}
