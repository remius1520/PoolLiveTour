pp_funcs.txt  : 53 physics functions, exact sizes (saved by the app).
                (Actions tab) -> artifact "physics_asm" = readable ARM64 of SolveCollisions, SolveBallWithBall,
                SetCueDirectionAfterBallCollide, PredictCueDirAfterBallCollision ... Send physics_asm.txt back.
tables/       : live memory dumps per table (pockets, GamePhysics mass/drag, ball numbers).
Spin_Physics_Extraction_Report.txt : SpinController field offsets + spin mapping asm.
