#include "../core/predict_core.hpp"
#include <cstdio>
using namespace pp;
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { ++fails; std::printf("FAIL: %s\n", msg); } else std::printf("ok:   %s\n", msg); } while (0)
static bool near(double a, double b, double e = 1e-6) { return std::fabs(a - b) < e; }


// v36: mock "game geometry" = infinite planes (n points toward the playable side, surface n.x = c). Stands in for Physics.SphereCast in the tests.
struct PlaneProbe : Probe {
    struct Pl { V2 n; double c; }; std::vector<Pl> pls; double off = 0;   // off = extra cast radius (the game adds 2 x defaultContactOffset)
    bool cast(V2 p, V2 d, double r, double maxDist, CastHit& o) const override {
        double best = 1e18; V2 bn{0, 0};
        for (auto& q : pls) { double nd = dot(q.n, d); if (nd >= -1e-12) continue; double t = (q.c + r + off - dot(q.n, p)) / nd; if (t >= 0 && t < best && t < maxDist) { best = t; bn = q.n; } }
        if (best > 1e17) return false;
        o.t = best; o.n = bn; return true;
    }
};

int main() {
    // table 5 pockets from the dump
    std::vector<V2> pk = {{-0.0022, 0.4516}, {-1.1080, 0.4182}, {1.1182, 0.4246}, {0.0013, -0.7703}, {-1.1102, -0.7287}, {1.1168, -0.7373}};
    Table T = Table::fromPockets(pk, 0.085, 0.12, 0.10);
    Config C; C.maxBounces = 3;
    const double r = 0.0325;

    { // 1. straight shot, nothing in the way: one bounce off the right cushion, mirror symmetry
        Sim s(T, C, {}, {0.0, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        const Track& t = R.tracks[0];
        CHECK(t.pts.size() >= 2 && near(t.pts[1].x, T.xmax) && near(t.pts[1].z, 0.0), "cue hits right cushion exactly at xmax");
        CHECK(t.bounceIdx.size() >= 1, "bounce recorded");
    }
    { // 2. 45 degree bank: after bounce on top (z) the z component flips, x unchanged
        Sim s(T, C, {}, {0.0, 0.0}, r); double k = std::sqrt(0.5); Result R = s.run({k, k}, 1.0);
        const Track& t = R.tracks[0]; V2 a = t.pts[1], b = t.pts[2];
        CHECK(near(a.z, T.zmax) && near((b - a).x, std::fabs((b - a).z) * ((b - a).x > 0 ? 1 : -1)) , "45deg bank mirrors (|dx|==|dz| after bounce)");
        CHECK((b - a).z < 0, "z flipped after top cushion");
    }
    { // 3. head-on ball: target moves along the line, cue stops (tangent speed 0)
        std::vector<BallIn> b = {{1, {0.5, 0.0}, r}};
        Sim s(T, C, b, {0.0, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        CHECK(R.tracks[0].end == END_BALL && R.tracks[0].hitId == 1, "cue ends on ball 1");
        CHECK(near(R.tracks[0].pts.back().x, 0.5 - 2 * r, 1e-9), "ghost ball position = centre - 2r");
        const Track* cc = nullptr; for (auto& t : R.tracks) if (t.id == -1 && t.gen == 1) cc = &t;
        CHECK((R.tracks.size() == 3 && R.tracks[1].id == 1) || cc, "head-on: target track + (v37) the cue creeps on at ~4% of its speed");
        double vin = 4.3 - 0.62 * (0.5 - 2 * r), creep = cc ? len(cc->pts.back() - cc->pts[0]) : 0;
        CHECK(cc && creep > 0 && creep < 0.1 * vin / 0.62, "head-on creep is short (<10% of the free roll)");
    }
    { // 4. 90 degree rule: cue and target leave at right angles (equal masses, no spin)
        std::vector<BallIn> b = {{1, {0.5, 0.04}, r}};
        Sim s(T, C, b, {0.0, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        const Track* tg = nullptr; const Track* cu = nullptr;
        for (auto& t : R.tracks) { if (t.id == 1) tg = &t; if (t.id == -1 && t.gen == 1) cu = &t; }
        CHECK(tg && cu, "cut shot spawns target + cue continuation");
        if (tg && cu) {
            V2 dt = tg->pts[1] - tg->pts[0], dc = cu->pts[1] - cu->pts[0];
            CHECK(near(dot(dt, dc) / (len(dt) * len(dc)), 0.0, 1e-9), "target and cue directions are perpendicular");
        }
    }
    { // 5. pocket: target ball lined up with the top-right corner pocket stops there
        V2 pp_ = pk[2];                                   // (1.1182, 0.4246)
        V2 dir = pp_ - V2{0.6, 0.0}; double L = len(dir); dir = dir * (1.0 / L);
        V2 ballPos = V2{0.6, 0.0};
        V2 cuePos = ballPos - dir * 0.4;                  // straight line cue->ball->pocket
        std::vector<BallIn> b = {{3, ballPos, r}};
        Sim s(T, C, b, cuePos, r); Result R = s.run(dir, 1.0);
        const Track* tg = nullptr; for (auto& t : R.tracks) if (t.id == 3) tg = &t;
        CHECK(tg && tg->end == END_POCKET && tg->pocket == 2, "target ball ends in pocket 2");
    }
    { // 6. chain: cue -> ball1 -> ball2 (ball2 sits on ball1's line)
        std::vector<BallIn> b = {{1, {0.3, 0.0}, r}, {2, {0.6, 0.0}, r}};
        Sim s(T, C, b, {-0.4, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        bool ok = false; for (auto& t : R.tracks) if (t.id == 1 && t.end == END_BALL && t.hitId == 2) ok = true;
        bool has2 = false; for (auto& t : R.tracks) if (t.id == 2) has2 = true;
        CHECK(ok && has2, "ball1 hits ball2, ball2 gets its own path");
    }
    { // 7. power: lower power -> shorter path (travel = v0/drag), stops at rest
        Sim s(T, C, {}, {0.0, 0.0}, r); Result R = s.run({1, 0}, 0.1);
        const Track& t = R.tracks[0];
        CHECK(t.end == END_REST && near(len(t.pts.back() - t.pts[0]), 0.1 * 4.3 / 0.62, 1e-9), "power 0.1 -> distance = 0.1*vMax/drag");
    }
    { // 8. bounce limit
        Config c2 = C; c2.maxBounces = 1; c2.cushionKeep = 1.0;
        Sim s(T, c2, {}, {0.0, 0.0}, r); double k = std::sqrt(0.5); Result R = s.run({k, k}, 1.0);
        CHECK(R.tracks[0].bounceIdx.size() == 1 && R.tracks[0].end == END_BOUNCELIMIT, "maxBounces=1: exactly one bounce, then the track ends at the next cushion");
    }
    { // 9. v20: a ball sliding along the bottom rail toward the corner pocket is POCKETED (old code bounced off the wall line before the mouth)
        double z = T.zmin + 0.004;
        Sim s(T, C, {}, {0.2, z}, r); Result R = s.run({1, 0}, 1.0);
        CHECK(R.tracks[0].end == END_POCKET && R.tracks[0].pocket == 5, "rail-hugging shot drops into the corner pocket");
    }
    { // 10. v20: pocket end point stays ON the aim line (no snapping to the pocket centre); off-centre by 0.05 is still pocketed
        V2 pc = pk[2]; V2 start = {0.2, 0.0}; V2 tgt = {pc.x, pc.z - 0.05}; V2 aim = tgt - start; aim = aim * (1.0 / len(aim));
        Sim s(T, C, {}, start, r); Result R = s.run(aim, 1.0);
        const Track& t = R.tracks[0]; V2 e = t.pts.back() - start; double cross = e.x * aim.z - e.z * aim.x;
        CHECK(t.end == END_POCKET && t.pocket == 2 && t.bounceIdx.empty() && std::fabs(cross) < 1e-9, "off-centre pocket shot: no bounce, last point lies exactly on the aim ray");
    }
    { // 10b. v20: aimed exactly at the pocket centre from a shallow angle -> always pocketed
        V2 pc = pk[2]; V2 start = {0.2, 0.0}; V2 aim = pc - start; aim = aim * (1.0 / len(aim));
        Sim s(T, C, {}, start, r); Result R = s.run(aim, 1.0);
        CHECK(R.tracks[0].end == END_POCKET && R.tracks[0].bounceIdx.empty(), "centre-aimed shallow shot goes in (old code bounced on the wall line)");
    }
    { // 11. v20: shot well wide of the mouth still bounces
        Sim s(T, C, {}, {0.2, T.zmax - 0.3}, r); Result R = s.run({1, 0}, 1.0);
        CHECK(R.tracks[0].end != END_POCKET && R.tracks[0].bounceIdx.size() >= 1, "wide shot bounces, not pocketed");
    }
    { // 12. v20: balls in the tray (outside the table) are ignored
        std::vector<BallIn> b = {{1, {0.5, T.zmin - 0.2}, r}};
        Sim s(T, C, b, {0.0, T.zmin + 0.001}, r); Result R = s.run({1, 0}, 1.0);
        CHECK(R.tracks[0].end != END_BALL, "tray ball does not stop the cue ball");
    }
    { // 13. v37: drag law. A free roll stops after v0/drag and the time is -ln(1 - drag*s/v0)/drag (checked through t1 of the track)
        Config c = C; c.cushionKeep = 1.0; Sim s(T, c, {}, {0.0, 0.0}, r); Result R = s.run({0, 1}, 0.04);
        const Track& t = R.tracks[0]; double v0 = 0.04 * 4.3;
        CHECK(t.end == END_REST && std::fabs(R.finals.back().p.z - v0 / 0.62) < 0.03, "stopping distance = v0/drag (within the rest-threshold creep)");
    }
    { // 14. v37: cushion keeps edgerestitution of the speed: bounce, then the remaining roll is (v_at_wall*0.92)/drag
        Sim s(T, C, {}, {0.0, 0.0}, r); Result R = s.run({1, 0}, 0.45);
        double v0 = 0.45 * 4.3, dw = T.xmax, vw = v0 - 0.62 * dw, back = vw * 0.92 / 0.62;
        const Track& t = R.tracks[0]; V2 e = t.pts.back();
        CHECK(near(e.x, T.xmax - back, 0.03) && t.bounceIdx.size() == 1, "after the cushion the ball rolls (v_wall*0.92)/drag back");
    }
    { // 15. v37: combo - the cue hits ball 1 which, while still rolling, hits ball 2 (ball 2 is placed so that ball 1 reaches it)
        std::vector<BallIn> b = {{1, {0.3, 0.0}, r}, {2, {0.6, 0.0}, r}};
        Sim s(T, C, b, {0.0, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        bool hit12 = false; for (auto& t : R.tracks) if (t.id == 1 && t.end == END_BALL && t.hitId == 2) hit12 = true;
        double x2 = 0, x1 = 0; for (auto& f : R.finals) { if (f.id == 2) x2 = f.p.x; if (f.id == 1) x1 = f.p.x; }
        CHECK(hit12 && x2 > 0.6 + 0.1, "combo: ball 2 is driven forward by ball 1");
        CHECK(x1 < x2, "ball 1 stays behind ball 2");
    }
    { // 16. v37: a ball that is hit while ANOTHER ball is already moving (two movers) - momentum along the line of centres is conserved
        // ball 1 rests at (0.5,0), ball 2 rests at (0.5+..): the cue goes through the middle of two touching balls; all balls move afterwards
        std::vector<BallIn> b = {{1, {0.5, 0.0}, r}, {2, {0.5, 0.0655}, r}};
        Sim s(T, C, b, {0.0, 0.03275}, r); Result R = s.run({1, 0}, 1.0);
        int moved = 0; for (auto& f : R.finals) if (f.id > 0 && len(f.p - (f.id == 1 ? V2{0.5, 0.0} : V2{0.5, 0.0655})) > 0.02) ++moved;
        CHECK(moved == 2, "a hit on a touching pair moves both balls");
    }
    { // 17. v37: break - a rack of 15 touching balls; every ball is accounted for and none overlaps another at the end
        std::vector<BallIn> b; int id = 1; double d = 2 * r + 1e-4;
        for (int row = 0; row < 5; ++row) for (int k = 0; k <= row; ++k) { b.push_back({id++, {0.4 + row * d * 0.8660254, (k - row * 0.5) * d}, r}); }
        Sim s(T, C, b, {-0.5, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        CHECK(R.finals.size() == 16, "break: 15 balls + cue reported");
        int movers = 0; for (auto& f : R.finals) { for (auto& g : b) if (g.id == f.id && len(f.p - g.p) > 0.05) ++movers; }
        CHECK(movers >= 8, "break scatters the rack (>= 8 balls move)");
        bool overlap = false; for (size_t i = 0; i < R.finals.size(); ++i) for (size_t j = i + 1; j < R.finals.size(); ++j) if (!R.finals[i].pocketed && !R.finals[j].pocketed && len(R.finals[i].p - R.finals[j].p) < 2 * r - 0.01) overlap = true;
        CHECK(!overlap, "no overlapping balls at rest after the break");
    }
    { // 18. v37: sequential contacts of one ball (cue hits ball 1, comes back and hits ball 2 later) - ball 2 gets its own track
        std::vector<BallIn> b = {{1, {0.3, 0.0}, r}, {2, {0.0, 0.3}, r}};
        Sim s(T, C, b, {0.0, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        int hits = 0; for (auto& t : R.tracks) if (t.id == -1 && t.end == END_BALL) ++hits;
        CHECK(hits >= 1, "cue ball keeps being tracked after its first contact");
    }
    { // 19. v37: cut shot - target leaves along the line of centres with 0.92*cos*v, cue along the tangent
        double cut = 0.04; std::vector<BallIn> b = {{1, {0.5, cut}, r}};
        Sim s(T, C, b, {0.0, 0.0}, r); Result R = s.run({1, 0}, 0.12);
        const Track* tg = nullptr; for (auto& t : R.tracks) if (t.id == 1 && t.gen == 1) tg = &t;
        V2 ghost = R.tracks[0].pts.back(); V2 n = V2{0.5, cut} - ghost; n = n * (1.0 / len(n)); double cs = n.x;
        double vin = 0.12 * 4.3 - 0.62 * ghost.x; double expect = 0.92 * cs * vin / 0.62;
        CHECK(tg && near(len(tg->pts.back() - tg->pts[0]), expect, 0.03), "target travels 0.92*cos*v_in/drag");
    }
    { // 20. v37: ball pocketed in a corner is removed and reported
        V2 pc = pk[2]; V2 start = {0.6, 0.0}; V2 aim = pc - start; aim = aim * (1.0 / len(aim));
        std::vector<BallIn> b = {{7, {0.9, -0.2}, r}};
        Sim s(T, C, b, start, r); Result R = s.run(aim, 1.0);
        bool potted = false; for (auto& f : R.finals) if (f.id == -1 && f.pocketed && f.pocket == 2) potted = true;
        CHECK(potted, "finals report the pocketed ball and its pocket");
    }
    { // 15. v20: measured limits are used as given
        Table M = Table::fromLimits(pk, -1.0, 1.0, -0.6, 0.3, 0.12, 0.10);
        Sim s(M, C, {}, {0.0, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        CHECK(near(R.tracks[0].pts[1].x, 1.0), "fromLimits: bounce exactly at the measured x limit");
    }
    { // 16. v21: the game's own first-contact directions replace the 90-degree rule (when they agree with the line of centres)
        std::vector<BallIn> b = {{1, {0.5, 0.02}, r}};
        Config co = C; co.hasOv = true; V2 n0 = {0.929, 0.370}; n0 = n0 * (1.0 / len(n0)); co.ovTarget = n0; co.ovCue = V2{0.1, -0.99} * (1.0 / len(V2{0.1, -0.99}));
        Sim s(T, co, b, {0.0, 0.0}, r); Result R = s.run({1, 0}, 1.0);
        const Track* tg = nullptr; const Track* cu = nullptr; for (auto& t : R.tracks) { if (t.id == 1) tg = &t; if (t.id == -1 && t.gen == 1) cu = &t; }
        CHECK(tg && near(len((tg->pts[1] - tg->pts[0]) * (1.0 / len(tg->pts[1] - tg->pts[0])) - n0), 0.0, 1e-9), "game target direction is used");
        CHECK(cu && (cu->pts[1] - cu->pts[0]).z < 0, "game cue direction is used");
        Config bad = co; bad.ovTarget = V2{0, 1};                       // disagrees with the geometry -> ignored
        Sim s2(T, bad, b, {0.0, 0.0}, r); Result R2 = s2.run({1, 0}, 1.0); const Track* t2 = nullptr; for (auto& t : R2.tracks) if (t.id == 1) t2 = &t;
        CHECK(t2 && (t2->pts[1] - t2->pts[0]).x > 0, "implausible game direction is ignored");
    }
    { // 12. game geometry (probe): same box as fromLimits -> identical bounce point
        PlaneProbe pr; pr.pls = {{{1, 0}, -1.1}, {{-1, 0}, -1.1}, {{0, 1}, -0.6}, {{0, -1}, -0.6}};   // walls at x=+-1.1, z=+-0.6
        Table Tb = Table::fromLimits(pk, -1.1 + r, 1.1 - r, -0.6 + r, 0.6 - r, 0.12, 0.10);
        Sim a(Tb, C, {}, {0.1, 0.05}, r); Sim b(Tb, C, {}, {0.1, 0.05}, r); b.setProbe(&pr);
        double k = std::sqrt(0.5); Result Ra = a.run({k, k}, 1.0), Rb = b.run({k, k}, 1.0);
        bool same = Ra.tracks[0].pts.size() == Rb.tracks[0].pts.size();
        for (size_t i = 0; same && i < Ra.tracks[0].pts.size(); ++i) same = near(Ra.tracks[0].pts[i].x, Rb.tracks[0].pts[i].x, 1e-3) && near(Ra.tracks[0].pts[i].z, Rb.tracks[0].pts[i].z, 1e-3);
        CHECK(same, "probe with an axis-aligned box == rectangle limits");
    }
    { // 13. a wall tilted 45 degrees: a ball moving +x leaves along +z (mirror about the REAL normal), contact on the cast-radius offset
        PlaneProbe pr; double k = std::sqrt(0.5); pr.pls = {{{-k, k}, 0.0}}; pr.off = 0.02;   // surface x*(-k)+z*k = 0 ; ball is on the side n.p > 0
        Sim s(T, C, {}, {-0.5, 0.0}, r); s.setProbe(&pr);   // start at (-0.5,0): n.p = 0.3535 > 0 (playable side)
        Result R = s.run({1, 0}, 1.0); const Track& t = R.tracks[0];
        V2 a = t.pts[1], b = t.pts[2]; V2 dv = b - a; double l = len(dv);
        CHECK(t.pts.size() >= 3 && near(dv.x / l, 0.0, 1e-3) && near(dv.z / l, 1.0, 1e-3), "45 degree wall: leaves along +z");
        CHECK(near(dot(pr.pls[0].n, a), r + 0.02, 1e-6), "contact point sits cast-radius from the surface");
    }
    { // 14. probe + ball: ball hit still handled by the circle test (probe only supplies cushions)
        PlaneProbe pr; pr.pls = {{{-1, 0}, -1.1}};
        std::vector<BallIn> b = {{1, {0.5, 0.0}, r}};
        Sim s(T, C, b, {0.0, 0.0}, r); s.setProbe(&pr); Result R = s.run({1, 0}, 1.0);
        CHECK(R.tracks[0].end == END_BALL && R.tracks[0].hitId == 1, "probe mode still stops on a ball");
    }
    std::printf("%s (%d failures)\n", fails ? "FAILED" : "ALL PASSED", fails);
    return fails ? 1 : 0;
}
