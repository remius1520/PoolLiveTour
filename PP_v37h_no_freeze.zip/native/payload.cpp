// PremiumPath payload v20 (runs INSIDE the game process; intended for OFFLINE / vs-computer matches only).
// Hooks CueBallView.LateUpdate by swapping its MethodInfo.methodPointer (no code bytes are patched), then each frame while the player is
// aiming: reads balls / pockets / aim / power, runs pp::Sim, and draws every resulting path with cloned in-game LineRenderers.
#include "il2cpp.hpp"
#include "../core/predict_core.hpp"
#include <android/log.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include <ucontext.h>
#include <sys/syscall.h>
#include <cstring>
#include <algorithm>
#include <setjmp.h>
#include <cstdio>
#include <cstdarg>
#include <sys/stat.h>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <string>

#define TAG "PremiumPath"
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

struct Vec3 { float x, y, z; };
struct Col { float r, g, b, a; };
using namespace il2;

// ---------- field offsets from dump.cs (this game build) ----------
namespace off {
    // CueBallView
    constexpr int CBV_trajectoryHandler = 0x20, CBV_cueBall = 0x28, CBV_gameManager = 0x30;
    // TrajectoryHandler
    constexpr int TH_targetLine = 0x40;
    // CueBall (: Ball)
    constexpr int CB_scaledDirection = 0x1B0, CB_cueRay = 0x1F4 /* origin 3f, direction 3f at +0x0C */, CB_isAiming = 0x26D;
    // Ball
    constexpr int B_radius = 0xB4, B_isCue = 0x109, B_insidePocket = 0x10B;
    // GameManager
    constexpr int GM_balls = 0xB8, GM_tableTubes = 0x190;
    // PhysicsBuilder
    constexpr int PB_previewForce = 0x24, PB_levelMaxPower = 0x48;
    // UnityEngine.Object.m_CachedPtr
    constexpr int UO_cachedPtr = 0x10;
    // List<T>: _items 0x10, _size 0x18; array elements start at 0x20
    constexpr int L_items = 0x10, L_size = 0x18, ARR_data = 0x20, ARR_len = 0x18;
}

template <class T> static inline T rd(const void* base, int o) { return *(const T*)((const char*)base + o); }
static inline bool plausible(const void* p) { return (uintptr_t)p > 0x10000 && (uintptr_t)p < 0x0000800000000000ULL; }
static inline bool alive(const void* uobj) { return plausible(uobj) && plausible(rd<void*>(uobj, off::UO_cachedPtr)); }

// ---------- config (written by the app with root) ----------
struct Cfg {
    int on = 1, bounces = 2, chain = 2;
    // dirsrc: 0 CueRay, 1 scaledDirection (default: the real aim, also right for bank shots), 2 ghost ball (WRONG for bank shots: the ghost is after the cushion), 3 ballAngle
    double inset = 0.055, dirsrc = 1, angoff = 0, angsgn = 1, keep = 0.92, ballkeep = 0.92, corner = 0.09, mid = 0.07, gapc = 0.11, gapm = 0.07;
    double fpower = 1.0, drag = 0.62, vmax = 4.3, lift = 0.012, width = 0.011;
    double usecol = 1;                 // 1 = take the cushion faces from the real colliders when they can be read, 0 = always use inset
    double colormode = 0;              // 0 = colour by ball number, 1 = colour by role (cue / target / other)
    double markers = 1;                // 1 = ghost-ball ring + end rings
    double probe = 1;                  // v36: 1 = cushions come from the game's own Physics.SphereCast against the real cushion colliders (0 = old rectangle limits)
    double castoff = 2;                // v36: cast radius = ball radius + castoff x Physics.defaultContactOffset (the game's own CueBall.OnCastCueBall uses radius + 2 x offset)
    double pwrsrc = 0;                 // v37: 0 = |PhysicsBuilder.forceDirection| (0x28/0x30: stays at the last pull after release), 1 = float@pwroff (horizontalForce, jumps back to levelMaxPower at release)
    double pwroff = 0x20, pwrdiv = 0;  // power = float@pwroff of PhysicsBuilder / (pwrdiv, or levelMaxPower when 0)
    double spinxoff = 0, spinyoff = 0, spinsgnx = 1, spinsgny = 1, spinscale = 1;   // float offsets inside CueBall (0 = spin off). Find them with the [10] log.
    double kside = 0.25, kfollow = 0.5, kdraw = 0.7;
    double spinsrc = 1;                // v22: 0 = SpinController.spinFactorx/y, 1 = ClientSpinController horizontal/vertical, 2 = spin off
    double useov = 1;                  // 1 = take the first-contact directions from the game itself when they agree with the geometry
    double maxlines = 40;              // v23: how many path lines may be drawn (the app's line-count control)
    double autophys = 1;               // v23: 1 = read drag (and the ball colours) from the game each match instead of the typed values
    double rings = 1;                  // v23: pocket rings, lit when a path ends in the pocket
    double cap = 0;                    // v26: the app writes a new number here to start the one-press capture (pp_cap.txt)
    double dots = 1;                   // v26: 1 = filled dot where a path ends (like the reference tool), 0 = ring
    double dumpfn = 0;                 // v37: the app writes a new number here to make the payload (re)write pp_funcs.txt = machine code of the physics functions
    double disc = 1;                   // 1 = log [10] "field changed" lines (to find the power / spin offsets)
};
static Cfg g_cfg;
static std::string g_dir;
static bool probeDir(const std::string& d) {
    std::string f = d + "/.pp_probe"; FILE* x = fopen(f.c_str(), "w"); if (!x) return false; fclose(x); unlink(f.c_str()); return true;
}
// The game may run as another Android user (dual app / secure folder), so the data dir is not always /data/data/<pkg>. Probe candidates; first writable wins.
static const std::string& dirNow() {
    if (!g_dir.empty()) return g_dir;
    const char* pkg = "com.PoolLiveTour"; int n = (int)(getuid() / 100000); char b[256]; std::vector<std::string> c;
    snprintf(b, sizeof b, "/data/data/%s/cache", pkg); c.push_back(b);
    snprintf(b, sizeof b, "/data/user/%d/%s/cache", n, pkg); c.push_back(b);
    snprintf(b, sizeof b, "/storage/emulated/%d/Android/data/%s/files", n, pkg); c.push_back(b);
    snprintf(b, sizeof b, "/storage/emulated/%d/Android/data/%s/cache", n, pkg); c.push_back(b);
    snprintf(b, sizeof b, "/sdcard/Android/data/%s/files", pkg); c.push_back(b);
    for (auto& d : c) { if (probeDir(d)) { g_dir = d + "/"; LOG("dir=%s uid=%d", g_dir.c_str(), (int)getuid()); return g_dir; } }
    static int warned = 0; if (!warned++) LOG("no writable dir found, uid=%d", (int)getuid());
    return g_dir;
}
static void loadCfg() {
    if (dirNow().empty()) return;
    FILE* f = fopen((g_dir + "pp_cfg.txt").c_str(), "r"); if (!f) return;
    char k[64]; double v; Cfg c = g_cfg;
    struct Kv { const char* k; double* v; };
    Kv tab[] = {{"inset", &c.inset}, {"dirsrc", &c.dirsrc}, {"angoff", &c.angoff}, {"angsgn", &c.angsgn}, {"keep", &c.keep}, {"ballkeep", &c.ballkeep}, {"maxlines", &c.maxlines}, {"autophys", &c.autophys}, {"rings", &c.rings}, {"corner", &c.corner}, {"mid", &c.mid},
        {"gapc", &c.gapc}, {"gapm", &c.gapm}, {"fpower", &c.fpower}, {"drag", &c.drag}, {"vmax", &c.vmax}, {"lift", &c.lift}, {"width", &c.width}, {"usecol", &c.usecol},
        {"colormode", &c.colormode}, {"markers", &c.markers}, {"pwroff", &c.pwroff}, {"pwrsrc", &c.pwrsrc}, {"pwrdiv", &c.pwrdiv}, {"spinxoff", &c.spinxoff}, {"spinyoff", &c.spinyoff},
        {"spinsgnx", &c.spinsgnx}, {"spinsgny", &c.spinsgny}, {"spinscale", &c.spinscale}, {"kside", &c.kside}, {"kfollow", &c.kfollow}, {"kdraw", &c.kdraw}, {"disc", &c.disc}, {"cap", &c.cap}, {"dots", &c.dots}, {"useov", &c.useov}, {"spinsrc", &c.spinsrc}, {"probe", &c.probe}, {"castoff", &c.castoff}, {"dumpfn", &c.dumpfn}};
    while (fscanf(f, " %63[^=]=%lf", k, &v) == 2) {
        std::string s = k;
        if (s == "on") c.on = (int)v; else if (s == "bounces") c.bounces = std::max(0, std::min(12, (int)v)); else if (s == "chain") c.chain = std::max(0, std::min(6, (int)v));
        else for (auto& e : tab) if (s == e.k) { *e.v = v; break; }
    }
    fclose(f); g_cfg = c;
}
static void logFile(const char* fmt, ...) {
    { va_list a2; va_start(a2, fmt); __android_log_vprint(ANDROID_LOG_INFO, TAG, fmt, a2); va_end(a2); }   // always visible in logcat (tag PremiumPath)
    if (dirNow().empty()) return;
    FILE* f = fopen((g_dir + "pp_log.txt").c_str(), "a"); if (!f) return;
    va_list ap; va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap); fputc('\n', f); fclose(f);
}

// ---------- resolved Unity functions ----------
static const Method *mGetTransform, *mGetPosition, *mInstantiate, *mFindObjs, *mSetCount, *mSetPos, *mSetW0, *mSetW1, *mSetC0, *mSetC1, *mSetWorld;
static const Method *mGetGO, *mSetActive, *mActiveInH, *mRendSetEn, *mRendGetEn, *mSetSW, *mSetEW, *mSetWM, *mGetCnt, *mGetSW;
static Klass* kPhysicsBuilder; static Klass* kGamePhysics = nullptr; static const Method* mGetBounds = nullptr; static void* g_bndFor = nullptr;
struct Bnd { float c[3], e[3]; };
static void* callObj(const Method* m, void* self) { return ((void* (*)(void*, const Method*))fnptr(m))(self, m); }
static bool getPos(void* comp, Vec3& out) {
    if (!alive(comp)) return false;
    void* tr = callObj(mGetTransform, comp); if (!alive(tr)) return false;
    out = ((Vec3 (*)(void*, const Method*))fnptr(mGetPosition))(tr, mGetPosition); return true;
}

// ---------- crash guard: any fault inside our drawing code disables the feature instead of killing the game ----------
static sigjmp_buf g_jb; static volatile sig_atomic_t g_in = 0; static volatile long g_tid = 0; static struct sigaction g_old;
static sigjmp_buf g_jbI; static volatile sig_atomic_t g_inI = 0; static volatile long g_tidI = 0; static volatile int g_stage = 0;   // separate guard for the init thread
static volatile uintptr_t g_fPc = 0, g_fAddr = 0; static volatile int g_dstage = 0; static uintptr_t g_il2Base = 0;
static inline long tidNow() { return (long)syscall(SYS_gettid); }
static void onSegv(int sig, siginfo_t* si, void* ctx) {
#if defined(__aarch64__)
    if (g_inI && tidNow() == g_tidI) { g_fPc = (uintptr_t)((ucontext_t*)ctx)->uc_mcontext.pc; g_fAddr = (uintptr_t)si->si_addr; }
#endif
    if (g_inI && tidNow() == g_tidI) siglongjmp(g_jbI, 1);
#if defined(__aarch64__)
    if (g_in && tidNow() == g_tid) { g_fPc = (uintptr_t)((ucontext_t*)ctx)->uc_mcontext.pc; g_fAddr = (uintptr_t)si->si_addr; }
#endif
    if (g_in && tidNow() == g_tid) siglongjmp(g_jb, 1);      // only the thread that is inside draw(): a fault on another thread must not jump into our frame
    // v26: Unity's handler (installed on top of ours) chains back to us, and we chain to it: without this guard a fault outside our code would bounce between the two forever.
    static thread_local int depth = 0;
    if (depth > 0) { signal(sig, SIG_DFL); raise(sig); return; }
    ++depth;
    if (g_old.sa_flags & SA_SIGINFO) { if (g_old.sa_sigaction && g_old.sa_sigaction != onSegv) { g_old.sa_sigaction(sig, si, ctx); --depth; return; } }
    else if (g_old.sa_handler && g_old.sa_handler != SIG_IGN && g_old.sa_handler != SIG_DFL) { g_old.sa_handler(sig); --depth; return; }
    --depth; signal(sig, SIG_DFL); raise(sig);
}

// v25: Unity installs its OWN SIGSEGV handler (it printed \"E CRASH signal 11\" and then killed the game ~4s after our guard had caught the fault in pp_report_12).
// Handlers stack: the one installed LAST runs first. Ours was installed first, so Unity's ran before ours. Now we check every 2 s and re-install on top.
static void ensureHandler() {
    struct sigaction cur; if (sigaction(SIGSEGV, nullptr, &cur) != 0) return;
    if ((cur.sa_flags & SA_SIGINFO) && cur.sa_sigaction == onSegv) return;
    struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_sigaction = onSegv; sa.sa_flags = SA_SIGINFO | SA_ONSTACK; sigemptyset(&sa.sa_mask);
    struct sigaction prev; if (sigaction(SIGSEGV, &sa, &prev) == 0) { g_old = prev; static int n = 0; if (n++ < 5) logFile("[X] SIGSEGV handler had been replaced (by the game); ours re-installed on top (#%d)", n); }
}
// ---------- line pool ----------
struct Line { void* lr = nullptr; uint32_t gch = 0; };
static std::vector<Line> g_pool; static void* g_poolOwner = nullptr; static void* g_template = nullptr; static double g_drawAfter = 0; static void* g_lrKlass = nullptr;   // v25: Il2CppObject.klass of the template: a clone whose klass changed is freed/reused memory
static inline bool validLine(void* lr) { return alive(lr) && g_lrKlass && rd<void*>(lr, 0) == g_lrKlass; }
static const Col WHITE{1, 1, 1, 1}, CUE2{0.8f, 0.9f, 1, 0.85f};
// ball number -> colour (1-7 solids, 8 = grey so it shows on the blue cloth, 9-15 = the stripe of the same colour)
static Col g_ballCol[64]; static bool g_hasCol[64];   // v23: the ball's OWN colour (Ball.color @0xF8), indexed like the ball list
static Col ballColor(int id) {
    if (id >= 0 && id < 64 && g_hasCol[id]) return g_ballCol[id];
    static const Col BC[8] = {{1, 0.85f, 0.1f, 1}, {0.2f, 0.9f, 1, 1}, {1, 0.25f, 0.25f, 1}, {0.7f, 0.5f, 1, 1}, {1, 0.5f, 0.1f, 1}, {0.4f, 1, 0.4f, 1}, {1, 0.2f, 0.9f, 1}, {0.65f, 0.65f, 0.65f, 1}};
    int k = id > 8 ? id - 8 : id; return (k >= 1 && k <= 8) ? BC[k - 1] : WHITE;
}
static Col trackColor(const pp::Track& t, int mode) {
    if (t.id == -1) return t.gen == 0 ? WHITE : (mode == 0 ? WHITE : CUE2);
    if (mode == 0) return ballColor(t.id);
    static const Col R[3] = {{0.4f, 1, 0.4f, 1}, {1, 0.85f, 0.1f, 1}, {1, 0.5f, 0.1f, 1}};
    return R[std::min(2, std::max(0, t.gen - 1))];
}

static void setCount(void* lr, int n) { ((void (*)(void*, int, const Method*))fnptr(mSetCount))(lr, n, mSetCount); }
// v26: after a fault the old clones are not trusted any more; they are parked here and released (hidden + gchandle freed) later from the guarded draw path, instead of leaking
static std::vector<Line> g_pending; static volatile bool g_skipDrain = false;
static void drainPending() {
    int n = 0;
    while (!g_pending.empty() && n++ < 64) { Line l = g_pending.back(); g_pending.pop_back(); if (l.gch && il2cpp_gchandle_free) il2cpp_gchandle_free(l.gch); }   // v27: never call into a parked clone (it may be destroyed); only drop the strong handle
}
static void setPos(void* lr, int i, Vec3 v) { ((void (*)(void*, int, Vec3, const Method*))fnptr(mSetPos))(lr, i, v, mSetPos); }
static void setColor(void* lr, Col c) {
    ((void (*)(void*, Col, const Method*))fnptr(mSetC0))(lr, c, mSetC0); ((void (*)(void*, Col, const Method*))fnptr(mSetC1))(lr, c, mSetC1);
}
static void hideAll() { for (auto& l : g_pool) if (validLine(l.lr)) setCount(l.lr, 0); }

// v17: make a cloned line really visible: active GameObject, enabled renderer, explicit width (the template's own state/width may be "hidden")
static inline bool callBool(const Method* m, void* o) { return m && fnptr(m) ? ((bool (*)(void*, const Method*))fnptr(m))(o, m) : false; }
static void forceVisible(void* lr, float w) {
    if (mGetGO && mSetActive) { void* go = callObj(mGetGO, lr); if (alive(go)) ((void (*)(void*, bool, const Method*))fnptr(mSetActive))(go, true, mSetActive); }
    if (mRendSetEn) ((void (*)(void*, bool, const Method*))fnptr(mRendSetEn))(lr, true, mRendSetEn);
    if (mSetSW) ((void (*)(void*, float, const Method*))fnptr(mSetSW))(lr, w, mSetSW);
    if (mSetEW) ((void (*)(void*, float, const Method*))fnptr(mSetEW))(lr, w, mSetEW);
}
static void diagLine(void* lr) {
    bool act = false, en = false; int cnt = -1; float sw = -1;
    if (mGetGO && mActiveInH) { void* go = callObj(mGetGO, lr); if (alive(go)) act = callBool(mActiveInH, go); }
    en = callBool(mRendGetEn, lr);
    if (mGetCnt && fnptr(mGetCnt)) cnt = ((int (*)(void*, const Method*))fnptr(mGetCnt))(lr, mGetCnt);
    if (mGetSW && fnptr(mGetSW)) sw = ((float (*)(void*, const Method*))fnptr(mGetSW))(lr, mGetSW);
    logFile("[7] line0 readback: activeInHierarchy=%d enabled=%d positionCount=%d startWidth=%.4f", (int)act, (int)en, cnt, (double)sw);
}
// v21: the clones are managed objects that ONLY our native code points to; the GC was free to collect them (-> stale pointer -> fault in draw() stage 6,
// then "feature disabled for this session" = the tool "closed after the first match", and a crash when the player toggled it on again).
// Now every clone is held by a strong GC handle, and a clone that Unity destroyed (scene change) is re-created in place.
static void* makeClone(void* templ, uint32_t& gch) {
    void* c = ((void* (*)(void*, const Method*))fnptr(mInstantiate))(templ, mInstantiate);
    if (!alive(c)) return nullptr;
    gch = (il2cpp_gchandle_new && plausible(c)) ? il2cpp_gchandle_new((Obj*)c, false) : 0;
    ((void (*)(void*, bool, const Method*))fnptr(mSetWorld))(c, true, mSetWorld);
    forceVisible(c, (float)g_cfg.width);
    return c;
}
static void releasePool() { for (auto& l : g_pool) if (l.gch && il2cpp_gchandle_free) il2cpp_gchandle_free(l.gch); g_pool.clear(); }
static void* ensureLine(size_t i, void* templ) {
    while (g_pool.size() <= i) { uint32_t g = 0; void* c = makeClone(templ, g); if (!c) return nullptr; g_pool.push_back({c, g}); }
    if (!validLine(g_pool[i].lr)) {                              // destroyed by Unity or memory reused: re-create this slot
        if (g_pool[i].gch && il2cpp_gchandle_free) il2cpp_gchandle_free(g_pool[i].gch);
        uint32_t g = 0; void* c = makeClone(templ, g); g_pool[i] = {c, g}; if (!c) return nullptr;
    }
    return g_pool[i].lr;
}

// ---------- PhysicsBuilder (power) ----------
static void* g_pb = nullptr; static double g_pbNext = 0;
static double nowSec() { timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }
static void shotLog(const char* fmt, ...);
static void logRestitutionShot(const char* tag, double tRel);
static void logRestitutionLive();   // v37c: re-reads PhysicsSolver statics while aiming (they are 0 at start-up)
static void* findPB() {
    if (alive(g_pb)) return g_pb;
    if (nowSec() < g_pbNext) return nullptr;
    g_pbNext = nowSec() + 2.0;
    if (!mFindObjs || !kPhysicsBuilder) return nullptr;
    Obj* tobj = il2cpp_type_get_object(il2cpp_class_get_type(kPhysicsBuilder));
    void* arr = ((void* (*)(void*, int, const Method*))fnptr(mFindObjs))(tobj, 0, mFindObjs);
    if (!plausible(arr) || rd<int>(arr, off::ARR_len) < 1) return nullptr;
    g_pb = rd<void*>(arr, off::ARR_data); return alive(g_pb) ? g_pb : nullptr;
}

// ---------- v22: spin (found in dump.cs): SpinController (PoolLiveTourMax.Gameplay.Shot) spinFactorx@0x11C spinFactory@0x120; ClientSpinController (Client.UI) vertical@0x3C horizontal@0x40 radius@0x44 ----------
static Klass *kSpinCtl = nullptr, *kClientSpin = nullptr; static void *g_spin = nullptr, *g_cspin = nullptr; static double g_spinNext = 0, g_cspinNext = 0;
static void* findOne(Klass* k, void*& cache, double& next) {
    if (alive(cache)) return cache;
    if (nowSec() < next) return nullptr;
    next = nowSec() + 2.0;
    if (!mFindObjs || !k) return nullptr;
    Obj* tobj = il2cpp_type_get_object(il2cpp_class_get_type(k));
    void* arr = ((void* (*)(void*, int, const Method*))fnptr(mFindObjs))(tobj, 0, mFindObjs);
    if (!plausible(arr) || rd<int>(arr, off::ARR_len) < 1) return nullptr;
    cache = rd<void*>(arr, off::ARR_data); return alive(cache) ? cache : nullptr;
}

static void* g_gp = nullptr; static double g_gpNext = 0;
// v23: GamePhysics (dump.cs): mass@0x30 drag@0x34 angularDrag@0x38 = the Rigidbody values every ball gets (GamePhysics.BallBuilder: set_mass/set_drag/set_angularDrag from 0x30/0x34/0x38)
static bool readGameDrag(double& drag) {
    void* gp = findOne(kGamePhysics, g_gp, g_gpNext); if (!gp) return false;
    float d = rd<float>(gp, 0x34); if (!(d > 0.01f && d < 10.f)) return false; drag = d; return true;
}
static Klass* kPocket = nullptr; static std::vector<pp::V2> g_pk; static double g_pkNext = 0; static void* g_pkFor = nullptr;
static std::vector<pp::V2> readPockets(void* gm) {
    if (g_pkFor == gm && g_pk.size() >= 4 && nowSec() < g_pkNext) return g_pk;
    if (g_pkFor != gm) { g_pk.clear(); g_pkFor = gm; }
    g_pkNext = nowSec() + 3.0;
    if (!mFindObjs || !kPocket) return g_pk;
    Obj* tobj = il2cpp_type_get_object(il2cpp_class_get_type(kPocket));
    void* arr = ((void* (*)(void*, int, const Method*))fnptr(mFindObjs))(tobj, 0, mFindObjs);
    if (!plausible(arr)) return g_pk;
    int n = rd<int>(arr, off::ARR_len); if (n < 1 || n > 64) return g_pk;
    bool got[8] = {false}; pp::V2 pos[8]; int cnt = 0;
    for (int i = 0; i < n; ++i) {
        void* po = rd<void*>(arr, off::ARR_data + 8 * i); if (!alive(po)) continue;
        int loc = rd<int>(po, 0x20); if (loc < 1 || loc > 6 || got[loc]) continue;      // PocketLocation 1..6, one per location
        void* orb = rd<void*>(po, 0x28);                                  // Pocket.orbitPoint: THE point that sits on the table (the old tool's pocketObj[..] positions came from it)
        Vec3 p; if (!(alive(orb) && getPos(orb, p)) && !getPos(po, p)) continue; got[loc] = true; pos[loc] = {p.x, p.z}; ++cnt;
    }
    if (cnt >= 4) { g_pk.clear(); for (int l = 1; l <= 6; ++l) if (got[l]) g_pk.push_back(pos[l]); }
    return g_pk;
}

// ---------- v20: field watcher. Logs every float inside [from,to) of an object that CHANGES while the player moves power / spin, so the right offsets can be read from one report ----------
struct Watch { void* owner = nullptr; float prev[128]; int chg[128]; bool init = false; double next = 0; };
static void watchFloats(Watch& w, const char* name, const void* base, int from, int to) {
    double t = nowSec(); if (t < w.next) return; w.next = t + 0.2;
    if (w.owner != base) { w.owner = (void*)base; w.init = false; memset(w.chg, 0, sizeof w.chg); }
    int n = std::min(128, (to - from) / 4);
    for (int i = 0; i < n; ++i) {
        float v = rd<float>(base, from + 4 * i);
        if (!w.init) { w.prev[i] = v; continue; }
        if (v != w.prev[i] && v == v) { if (w.chg[i] < 10) logFile("[10] %s+0x%X: %.4f -> %.4f", name, from + 4 * i, (double)w.prev[i], (double)v); ++w.chg[i]; w.prev[i] = v; }
    }
    w.init = true;
}


// ---------- v36: GAME GEOMETRY. The game's own aim code (CueBall.OnCastCueBall, rva 0x5DD6BB8) does tail-call
// Physics.SphereCast(Vector3 origin, float radius, Vector3 dir, out RaycastHit, float maxDistance, int layerMask) with radius = Ball.radius(0xB4) + 2 x Physics.defaultContactOffset
// (verified from the hex: ldr s8,[x21,#0xb4]; bl get_defaultContactOffset; fadd s0,s11,s11; fadd s11,s8,s0; ... b Physics.SphereCast).
// We make the same call against the REAL cushion MeshColliders (PhysicsBuilder.caushions @0x50), so angled faces and pocket jaws are exact - no rectangle, no inset.
struct RayHit { float p[3], n[3]; int face; float dist; float uv[2]; int col; };   // UnityEngine.RaycastHit = 44 bytes (CueBall: hit@0x1C8 .. CueRay@0x1F4)
static const Method *mSphereCast = nullptr, *mHitCollider = nullptr, *mGetLayer = nullptr, *mDefContact = nullptr;
static std::vector<void*> g_cush; static int g_cushMask = 0; static void* g_cushFor = nullptr; static double g_cushNext = 0; static int g_cushTry = 0;
static double g_probeLastT = -1, g_probeLastNx = 0, g_probeLastNz = 0; static int g_probeCalls = 0, g_probeHits = 0, g_probeSkipped = 0;
static float contactOffset() { return mDefContact && fnptr(mDefContact) ? ((float (*)(const Method*))fnptr(mDefContact))(mDefContact) : 0.01f; }
struct GameProbe : pp::Probe {
    float y = 0, extra = 0; int mask = 0;
    bool cast(pp::V2 p, pp::V2 d, double r, double maxDist, pp::CastHit& o) const override {
        ++g_probeCalls;
        double travelled = 0; pp::V2 q = p;
        for (int k = 0; k < 8; ++k) {                       // a hit on something that is NOT a cushion (e.g. a ball, if the layer mask is shared) is skipped and the cast continues behind it
            RayHit h; memset(&h, 0, sizeof h);
            bool ok = ((bool (*)(Vec3, float, Vec3, RayHit*, float, int, const Method*))fnptr(mSphereCast))(Vec3{(float)q.x, y, (float)q.z}, (float)(r + extra), Vec3{(float)d.x, 0.f, (float)d.z}, &h, (float)(maxDist - travelled), mask, mSphereCast);
            if (!ok) return false;
            void* col = ((void* (*)(RayHit*, const Method*))fnptr(mHitCollider))(&h, mHitCollider);
            bool isCush = false; for (void* c : g_cush) if (c == col) { isCush = true; break; }
            if (isCush) { o.t = travelled + h.dist; o.n = {h.n[0], h.n[2]}; ++g_probeHits; g_probeLastT = o.t; g_probeLastNx = h.n[0]; g_probeLastNz = h.n[2]; return true; }
            ++g_probeSkipped; travelled += (double)h.dist + 1e-3; q = p + d * travelled; if (travelled >= maxDist) return false;
        }
        return false;
    }
};
static GameProbe g_probe;
// find the live cushion colliders + the layer mask they use; true when the probe can be used this frame
static bool ensureProbe(void* gm, float y, double castoff) {
    if (!mSphereCast || !mHitCollider || !mGetLayer || !mGetGO || !fnptr(mSphereCast) || !fnptr(mHitCollider)) return false;
    if (g_cushFor != gm || g_cush.empty()) {
        if (nowSec() < g_cushNext) return false;
        g_cushNext = nowSec() + 2.0; ++g_cushTry;
        void* pb = findPB(); if (!pb) { if (g_cushTry <= 3) logFile("[14] probe: PhysicsBuilder not found yet (try %d)", g_cushTry); return false; }
        void* cl = rd<void*>(pb, 0x50); void* it = plausible(cl) ? rd<void*>(cl, off::L_items) : nullptr; int n = plausible(cl) ? rd<int>(cl, off::L_size) : 0;
        std::vector<void*> v; int mask = 0; std::string layers;
        if (plausible(it) && n > 0 && n <= 16) for (int i = 0; i < n; ++i) {
            void* col = rd<void*>(it, off::ARR_data + 8 * i); if (!alive(col)) continue;
            void* go = callObj(mGetGO, col); if (!alive(go)) continue;
            int layer = ((int (*)(void*, const Method*))fnptr(mGetLayer))(go, mGetLayer);
            if (layer < 0 || layer > 31) continue; v.push_back(col); mask |= 1 << layer; layers += std::to_string(layer) + " ";
        }
        logFile("[14] probe: caushions listed=%d alive=%d layers=[%s] mask=0x%x contactOffset=%.4f", n, (int)v.size(), layers.c_str(), (unsigned)mask, (double)contactOffset());
        if (v.empty() || !mask) return false;
        g_cush = v; g_cushMask = mask; g_cushFor = gm;
    }
    g_probe.y = y; g_probe.mask = g_cushMask; g_probe.extra = (float)(castoff * (double)contactOffset());
    return true;
}

// ---------- v37d: PhysX material values (bounciness / friction / combine modes) of the live cushion colliders + the cue ball + the world default material.
// The ball moves with PhysX (PhysicsSolver statics stay 0 when the solver is unused), so these are the numbers that decide the real bounce. Logged as [15] lines.
static const Method *mColSharedMat = nullptr, *mPmBounce = nullptr, *mPmDyn = nullptr, *mPmStat = nullptr, *mPmBComb = nullptr, *mPmFComb = nullptr, *mGetComp = nullptr, *mPhysDefMat = nullptr;
// v37f: the game strips unused managed getters (v37d log: sharedMaterial=0 bounciness=0 ...), but the Unity internal calls behind them still exist -> il2cpp_resolve_icall
static void* (*icShared)(void*) = nullptr; static float (*icBounce)(void*) = nullptr; static float (*icDyn)(void*) = nullptr; static float (*icStat)(void*) = nullptr;
static int (*icBComb)(void*) = nullptr; static int (*icFComb)(void*) = nullptr; static void* (*icDefMat)() = nullptr;
static Klass* kColl = nullptr; static bool g_matInit = false;
static void* resolveIc(const char* a1, const char* a2 = nullptr) {
    if (!il2cpp_resolve_icall) return nullptr; void* f = il2cpp_resolve_icall(a1); if (!f && a2) f = il2cpp_resolve_icall(a2); return f;
}
static void initMatMethods() {
    g_matInit = true;
    kColl = findClass("UnityEngine", "Collider"); Klass* kComp2 = findClass("UnityEngine", "Component"); Klass* kPh2 = findClass("UnityEngine", "Physics");
    Klass* kPM = findClass("UnityEngine", "PhysicMaterial"); if (!kPM) kPM = findClass("UnityEngine", "PhysicsMaterial");
    if (kColl) mColSharedMat = findMethod(kColl, "get_sharedMaterial", 0);
    if (kComp2) mGetComp = findMethod(kComp2, "GetComponent", 1, "System.Type");
    if (kPh2) mPhysDefMat = findMethod(kPh2, "get_defaultMaterial", 0);
    if (kPM) { mPmBounce = findMethod(kPM, "get_bounciness", 0); mPmDyn = findMethod(kPM, "get_dynamicFriction", 0); mPmStat = findMethod(kPM, "get_staticFriction", 0); mPmBComb = findMethod(kPM, "get_bounceCombine", 0); mPmFComb = findMethod(kPM, "get_frictionCombine", 0); }
    if (!mColSharedMat) icShared = (void* (*)(void*))resolveIc("UnityEngine.Collider::get_sharedMaterial", "UnityEngine.Collider::GetSharedMaterial");
    if (!mPmBounce) {
        icBounce = (float (*)(void*))resolveIc("UnityEngine.PhysicMaterial::get_bounciness", "UnityEngine.PhysicsMaterial::get_bounciness");
        icDyn = (float (*)(void*))resolveIc("UnityEngine.PhysicMaterial::get_dynamicFriction", "UnityEngine.PhysicsMaterial::get_dynamicFriction");
        icStat = (float (*)(void*))resolveIc("UnityEngine.PhysicMaterial::get_staticFriction", "UnityEngine.PhysicsMaterial::get_staticFriction");
        icBComb = (int (*)(void*))resolveIc("UnityEngine.PhysicMaterial::get_bounceCombine", "UnityEngine.PhysicsMaterial::get_bounceCombine");
        icFComb = (int (*)(void*))resolveIc("UnityEngine.PhysicMaterial::get_frictionCombine", "UnityEngine.PhysicsMaterial::get_frictionCombine");
    }
    if (!mPhysDefMat) icDefMat = (void* (*)())resolveIc("UnityEngine.Physics::get_defaultMaterial");
    logFile("[15] material methods: managed: sharedMaterial=%d GetComponent=%d defaultMaterial=%d PhysicMaterial class=%d bounciness=%d | icalls: resolveApi=%d shared=%d bounce=%d dyn=%d stat=%d bcomb=%d fcomb=%d defMat=%d",
        mColSharedMat != nullptr, mGetComp != nullptr, mPhysDefMat != nullptr, kPM != nullptr, mPmBounce != nullptr,
        il2cpp_resolve_icall != nullptr, icShared != nullptr, icBounce != nullptr, icDyn != nullptr, icStat != nullptr, icBComb != nullptr, icFComb != nullptr, icDefMat != nullptr);
}
static void* sharedMatOf(void* col) {
    if (icShared) return icShared(col);
    if (mColSharedMat && fnptr(mColSharedMat)) return ((void* (*)(void*, const Method*))fnptr(mColSharedMat))(col, mColSharedMat);
    return nullptr;
}
static void matLine(const char* tag, void* mat) {
    if (!alive(mat)) { logFile("[15] %s: no material object (collider uses the world default material)", tag); return; }
    auto gf = [&](float (*ic)(void*), const Method* m) -> float { if (ic) return ic(mat); return (m && fnptr(m)) ? ((float (*)(void*, const Method*))fnptr(m))(mat, m) : -1.f; };
    auto gi = [&](int (*ic)(void*), const Method* m) -> int { if (ic) return ic(mat); return (m && fnptr(m)) ? ((int (*)(void*, const Method*))fnptr(m))(mat, m) : -1; };
    logFile("[15] %s: bounciness=%.4f dynFriction=%.4f statFriction=%.4f bounceCombine=%d frictionCombine=%d  (combine: 0=Average 1=Minimum 2=Multiply 3=Maximum; -1 = getter unavailable)", tag,
        (double)gf(icBounce, mPmBounce), (double)gf(icDyn, mPmDyn), (double)gf(icStat, mPmStat), gi(icBComb, mPmBComb), gi(icFComb, mPmFComb));
}
static void logPhysMat(void* cueBall) {
    static double nx = 0; static void* lastFor = nullptr;
    if (g_cush.empty() || (lastFor == g_cushFor && nowSec() < nx)) return;
    lastFor = g_cushFor; nx = nowSec() + 30.0;
    if (!g_matInit) initMatMethods();
    if (!icShared && !(mColSharedMat && fnptr(mColSharedMat))) return;
    for (size_t i = 0; i < g_cush.size() && i < 8; ++i) { char tag[32]; snprintf(tag, sizeof tag, "cushion[%d]", (int)i); matLine(tag, sharedMatOf(g_cush[i])); }
    if (mGetComp && fnptr(mGetComp) && kColl && plausible(cueBall)) {
        Obj* tobj = il2cpp_type_get_object(il2cpp_class_get_type(kColl));
        void* col = tobj ? ((void* (*)(void*, Obj*, const Method*))fnptr(mGetComp))(cueBall, tobj, mGetComp) : nullptr;
        if (alive(col)) matLine("cueBall", sharedMatOf(col)); else logFile("[15] cueBall: Collider not found via GetComponent");
    }
    if (icDefMat) matLine("world default", icDefMat());
    else if (mPhysDefMat && fnptr(mPhysDefMat)) matLine("world default", ((void* (*)(const Method*))fnptr(mPhysDefMat))(mPhysDefMat));
}

// ---------- v37e: QUERY FILE. Write commands to <dir>/pp_q.txt (first line "id=N", N must change to run again) and read the answers in pp_q_out.txt (also logged as [Q]).
//   fields  <Class>                       list fields of the class with their offsets
//   methods <Class>                       list methods (name, arg count, rva)
//   static  <Class> <field>               read a static field (float / int / hex)
//   inst    <Class> <hexoffset> <f|i|p> [count]   read values from the first live instance (UnityEngine.Object-derived classes)
//   call    <Class> <method> <f|i|p>      call a 0-argument getter on the first live instance
//   icall   <Unity::icall_name>           check that a Unity internal call exists (e.g. UnityEngine.PhysicMaterial::get_bounciness)
// No rebuild is needed for new questions - only for new commands. The id is marked done BEFORE running, so a command that crashes is never repeated.
static Klass* findClassByName(const char* nm) {
    if (!il2cpp_image_get_class_count || !il2cpp_image_get_class || !il2cpp_class_get_name) return nullptr;
    size_t na = 0; Assembly** as = il2cpp_domain_get_assemblies(il2cpp_domain_get(), &na);
    for (size_t i = 0; as && i < na; ++i) {
        const Image* im = il2cpp_assembly_get_image(as[i]); size_t nc = il2cpp_image_get_class_count(im);
        for (size_t c = 0; c < nc; ++c) { const Klass* kc = il2cpp_image_get_class(im, c); const char* cn = kc ? il2cpp_class_get_name(kc) : nullptr; if (cn && !strcmp(cn, nm)) return (Klass*)kc; }
    }
    return nullptr;
}
static void* firstInstance(Klass* k) {
    if (!mFindObjs || !fnptr(mFindObjs) || !k) return nullptr;
    Obj* t = il2cpp_type_get_object(il2cpp_class_get_type(k));
    void* arr = ((void* (*)(void*, int, const Method*))fnptr(mFindObjs))(t, 0, mFindObjs);
    if (!plausible(arr) || rd<int>(arr, off::ARR_len) < 1) return nullptr;
    void* o = rd<void*>(arr, off::ARR_data); return alive(o) ? o : nullptr;
}
static FILE* g_qOut = nullptr;
static void qlog(const char* fmt, ...) {
    char b[512]; va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap);
    logFile("[Q] %s", b); if (g_qOut) { fputs(b, g_qOut); fputc('\n', g_qOut); fflush(g_qOut); }
}
static void runQuery(const char* line) {
    char cmd[16] = {0}, a[96] = {0}, b[96] = {0}, c[16] = {0}; unsigned cnt = 1;
    int n = sscanf(line, " %15s %95s %95s %15s %u", cmd, a, b, c, &cnt); if (n < 2 || cmd[0] == '#') return;
    qlog(">> %s", line);
    if (!strcmp(cmd, "icall")) { void* f = il2cpp_resolve_icall ? il2cpp_resolve_icall(a) : nullptr; qlog("  icall %s -> %p%s", a, f, il2cpp_resolve_icall ? "" : " (il2cpp_resolve_icall not exported)"); return; }
    Klass* k = findClassByName(a); if (!k) { qlog("class '%s' not found", a); return; }
    if (!strcmp(cmd, "fields")) {
        if (!il2cpp_class_get_fields || !il2cpp_field_get_name || !il2cpp_field_get_offset) { qlog("field listing API not exported"); return; }
        void* it = nullptr; int cntf = 0; while (void* f = il2cpp_class_get_fields(k, &it)) { qlog("  %s +0x%zX", il2cpp_field_get_name(f), (size_t)il2cpp_field_get_offset(f)); if (++cntf >= 300) break; }
        qlog("  (%d fields; own fields only, static ones show their offset inside static_fields)", cntf);
    } else if (!strcmp(cmd, "methods")) {
        void* it = nullptr; int cm = 0; while (const Method* m = il2cpp_class_get_methods(k, &it)) {
            uintptr_t fp = (uintptr_t)fnptr(m); qlog("  %s(%u) rva=0x%lx", il2cpp_method_get_name(m), (unsigned)il2cpp_method_get_param_count(m), (unsigned long)(g_il2Base && fp > g_il2Base ? fp - g_il2Base : fp)); if (++cm >= 300) break;
        }
    } else if (!strcmp(cmd, "static")) {
        if (!il2cpp_class_get_field_from_name || !il2cpp_field_static_get_value) { qlog("static API not exported"); return; }
        void* fi = il2cpp_class_get_field_from_name(k, b); if (!fi) { qlog("field '%s' not found", b); return; }
        unsigned char buf[64]; memset(buf, 0, sizeof buf); il2cpp_field_static_get_value(fi, buf);
        float f; int i32; long long i64; memcpy(&f, buf, 4); memcpy(&i32, buf, 4); memcpy(&i64, buf, 8);
        qlog("  %s.%s = float %.6f | int %d | int64/ptr 0x%llx", a, b, (double)f, i32, i64);
    } else if (!strcmp(cmd, "inst")) {
        unsigned long offs = strtoul(b, nullptr, 16); char ty = c[0] ? c[0] : 'f'; if (cnt < 1) cnt = 1; if (cnt > 64) cnt = 64;
        void* o = firstInstance(k); if (!o) { qlog("no live instance (only UnityEngine.Object-derived classes can be found)"); return; }
        for (unsigned i = 0; i < cnt; ++i) {
            if (ty == 'f') qlog("  +0x%lX = %.6f", offs + 4 * i, (double)rd<float>(o, (int)(offs + 4 * i)));
            else if (ty == 'i') qlog("  +0x%lX = %d", offs + 4 * i, rd<int>(o, (int)(offs + 4 * i)));
            else qlog("  +0x%lX = %p", offs + 8 * i, rd<void*>(o, (int)(offs + 8 * i)));
        }
    } else if (!strcmp(cmd, "call")) {
        const Method* m = findMethod(k, b, 0); if (!m || !fnptr(m)) { qlog("method '%s' (0 args) not found", b); return; }
        void* o = firstInstance(k); if (!o) { qlog("no live instance"); return; }
        char ty = c[0] ? c[0] : 'f';
        if (ty == 'f') qlog("  %s() = %.6f", b, (double)((float (*)(void*, const Method*))fnptr(m))(o, m));
        else if (ty == 'i') qlog("  %s() = %d", b, ((int (*)(void*, const Method*))fnptr(m))(o, m));
        else qlog("  %s() = %p", b, ((void* (*)(void*, const Method*))fnptr(m))(o, m));
    } else qlog("unknown command '%s' (fields, methods, static, inst, call)", cmd);
}
static void queryTick() {
    static double nx = 0; static long done = -1; double t = nowSec(); if (t < nx) return; nx = t + 1.5;
    if (dirNow().empty()) return;
    FILE* f = fopen((g_dir + "pp_q.txt").c_str(), "r"); if (!f) return;
    char first[128] = {0}; if (!fgets(first, sizeof first, f)) { fclose(f); return; }
    const char* p = strstr(first, "id="); long id = p ? atol(p + 3) : -1; if (id < 0 || id == done) { fclose(f); return; }
    done = id;                                                   // mark first: a crashing command is never retried
    std::vector<std::string> lines; char ln[256]; while (fgets(ln, sizeof ln, f)) { size_t L = strlen(ln); while (L && (ln[L - 1] == '\n' || ln[L - 1] == '\r')) ln[--L] = 0; if (L) lines.push_back(ln); }
    fclose(f);
    g_qOut = fopen((g_dir + "pp_q_out.txt").c_str(), "w"); qlog("query id=%ld: %d command(s)", id, (int)lines.size());
    for (auto& l : lines) runQuery(l.c_str());
    qlog("query id=%ld done", id); if (g_qOut) { fclose(g_qOut); g_qOut = nullptr; chmod((g_dir + "pp_q_out.txt").c_str(), 0666); }
}

// ---------- v20: real cushion faces from the Collider bounds (instead of the guessed inset) ----------
struct Meas { bool ok = false; double xmin = 0, xmax = 0, zmin = 0, zmax = 0; };
static Meas g_meas; static void* g_measFor = nullptr; static int g_bndTries = 0; static void* g_bndGm = nullptr;
static bool deriveLimits(const std::vector<Bnd>& bs, const std::vector<pp::V2>& pk, double rad, Meas& m) {
    double x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9; for (auto& q : pk) { x0 = std::min(x0, q.x); x1 = std::max(x1, q.x); z0 = std::min(z0, q.z); z1 = std::max(z1, q.z); }
    double cx = (x0 + x1) * 0.5, cz = (z0 + z1) * 0.5;
    std::vector<double> xl, xh, zl, zh;
    for (auto& b : bs) {
        double ex = b.e[0], ez = b.e[2], x = b.c[0], z = b.c[2];
        if (ex > 1.5 * ez) { if (z < cz) zl.push_back(z + ez); else zh.push_back(z - ez); }        // long in x: a top/bottom cushion; its inner face
        else if (ez > 1.5 * ex) { if (x < cx) xl.push_back(x + ex); else xh.push_back(x - ex); }  // long in z: a side cushion
    }
    if (xl.empty() || xh.empty() || zl.empty() || zh.empty()) return false;
    auto med = [](std::vector<double>& v) { std::sort(v.begin(), v.end()); return v[v.size() / 2]; };
    Meas r; r.xmin = med(xl) + rad; r.xmax = med(xh) - rad; r.zmin = med(zl) + rad; r.zmax = med(zh) - rad;
    // sanity: the limits must sit a little inside the pocket box (0 .. 0.25), otherwise the colliders are not what we think they are
    if (!(r.xmin - x0 > -0.02 && r.xmin - x0 < 0.25 && x1 - r.xmax > -0.02 && x1 - r.xmax < 0.25 && r.zmin - z0 > -0.02 && r.zmin - z0 < 0.25 && z1 - r.zmax > -0.02 && z1 - r.zmax < 0.25)) return false;
    r.ok = true; m = r; return true;
}

// v15: say WHY draw() returned early (logged when the reason changes, or every 5s), so one report tells us where it stops
static void why(const char* r, long a = 0) {
    static const char* last = nullptr; static double nxt = 0; double t = nowSec();
    if (r != last || t > nxt) { last = r; nxt = t + 5.0; logFile("[5] draw skipped: %s (%ld)", r, a); }
}
// v29: the last prediction (read by the shot recorder)
struct PredSnap { bool valid = false; double t = 0, power = 0, dx = 0, dz = 0, sx = 0, sy = 0, drag = 0, vmax = 0, keep = 0; double cx = 0, cz = 0;
                  std::vector<pp::BallIn> balls; std::vector<pp::Track> tracks; std::vector<pp::Final> finals; };
static PredSnap g_pred;
// ---------- the per-frame work ----------
static void draw(void* self) {
    g_dstage = 91;
    void* th = rd<void*>(self, off::CBV_trajectoryHandler); void* cb = rd<void*>(self, off::CBV_cueBall); void* gm = rd<void*>(self, off::CBV_gameManager);
    if (!plausible(th) || !plausible(cb) || !plausible(gm)) { why("CueBallView fields th/cb/gm not plausible", plausible(th) * 4 + plausible(cb) * 2 + plausible(gm)); return; }
    if (!rd<bool>(cb, off::CB_isAiming) || !g_cfg.on) { why(g_cfg.on ? "not aiming" : "cfg on=0"); hideAll(); return; }

    g_dstage = 92;
    void* templ = rd<void*>(th, off::TH_targetLine);
    if (!alive(templ)) { why("targetLine template not alive"); return; }
    if (g_poolOwner != gm || g_template != templ) { releasePool(); g_poolOwner = gm; g_template = templ; g_pb = nullptr; g_lrKlass = rd<void*>(templ, 0); g_drawAfter = nowSec() + 1.0; logFile("[4] new match/template: pool reset, klass=%p, gchandle new=%d free=%d; drawing resumes in 1s", g_lrKlass, il2cpp_gchandle_new != nullptr, il2cpp_gchandle_free != nullptr); }
    if (nowSec() < g_drawAfter) return;
    g_dstage = 93;
    if (!g_skipDrain) drainPending();         // v25: let the new scene settle before the first clone is made (the crash was on the first draw after a new turn)

    g_dstage = 94;
    Vec3 cp; if (!getPos(cb, cp)) { why("cue ball position unreadable"); return; }
    float cr = rd<float>(cb, off::B_radius); if (!(cr > 0.005f && cr < 0.2f)) { why("cue radius implausible", (long)(cr * 10000)); return; }

    g_dstage = 1;
    // v18: aim direction. The old source (CueRay.direction) pointed 30-80 degrees away from the game's real aim in the screenshots.
    // Candidates: 0 = CueRay.direction, 1 = scaledDirection, 2 = ghost ball (circleBallPosition - cue position), 3 = ballAngle (degrees; cfg angoff/angsgn).
    Vec3 dRay = rd<Vec3>(cb, off::CB_cueRay + 12), dScaled = rd<Vec3>(cb, off::CB_scaledDirection), gh = rd<Vec3>(cb, 0x260);
    Vec3 dGhost{gh.x - cp.x, 0, gh.z - cp.z};
    float ba = rd<float>(cb, 0x1BC); double ar = (g_cfg.angsgn * (double)ba + g_cfg.angoff) * 3.14159265358979 / 180.0;
    Vec3 dAng{(float)std::cos(ar), 0, (float)std::sin(ar)};
    auto L2 = [](const Vec3& v) { return std::fabs(v.x) + std::fabs(v.z); };
    Vec3 cand[4] = {dRay, dScaled, dGhost, dAng};
    int src = (int)g_cfg.dirsrc; if (src < 0 || src > 3) src = 1;
    Vec3 d = cand[src];
    if (L2(d) < 1e-4f) { for (int k : {2, 0, 1, 3}) if (L2(cand[k]) >= 1e-4f) { d = cand[k]; break; } }
    { static double nc = 0; if (nowSec() > nc) { nc = nowSec() + 1.5;
        auto A = [](const Vec3& v) { return std::atan2((double)v.z, (double)v.x) * 57.29578; };
        logFile("[8] dir candidates (deg=atan2(z,x)) [ghost!=scaled means bank/spin shot]: ray=%.1f scaled=%.1f ghost=%.1f ang=%.1f | ballAngle=%.2f ghostDist=%.3f hitDist=%.3f | src=%d", A(dRay), A(dScaled), A(dGhost), A(dAng), (double)ba, std::sqrt((double)dGhost.x * dGhost.x + (double)dGhost.z * dGhost.z), (double)rd<float>(cb, 0x25C), src); } }
    double dl = std::sqrt((double)d.x * d.x + (double)d.z * d.z); if (dl < 1e-4) { why("aim direction is zero"); hideAll(); return; }
    pp::V2 dir{d.x / dl, d.z / dl};

    g_dstage = 2;
    // balls
    std::vector<pp::BallIn> balls;
    void* list = rd<void*>(gm, off::GM_balls);
    if (plausible(list)) {
        void* items = rd<void*>(list, off::L_items); int n = rd<int>(list, off::L_size);
        if (plausible(items) && n > 0 && n < 64) for (int i = 0; i < n; ++i) {
            void* b = rd<void*>(items, off::ARR_data + 8 * i); if (!alive(b) || b == cb) continue;
            if (rd<bool>(b, off::B_isCue) || rd<bool>(b, off::B_insidePocket)) continue;
            Vec3 p; if (!getPos(b, p)) continue; float r = rd<float>(b, off::B_radius); if (!(r > 0.005f && r < 0.2f)) continue;
            balls.push_back({i, {p.x, p.z}, r});
            if (i < 64) {                                                   // v23: exact ball colour from the game (alpha forced to 1; too dark -> lifted so it shows on the cloth)
                Col c = rd<Col>(b, 0xF8); bool ok = c.a > 0.01f && c.r == c.r && c.g == c.g && c.b == c.b && c.r >= 0 && c.r <= 1.5f && c.g >= 0 && c.g <= 1.5f && c.b >= 0 && c.b <= 1.5f && (c.r + c.g + c.b) > 0.02f;
                if (ok) { float m = std::max(c.r, std::max(c.g, c.b)); float k = m < 0.55f ? 0.55f / m : 1.f; g_ballCol[i] = {std::min(1.f, c.r * k), std::min(1.f, c.g * k), std::min(1.f, c.b * k), 1.f}; g_hasCol[i] = true; }
                else g_hasCol[i] = false;
            }
        }
    }
    { static double nb = 0; if (nowSec() > nb) { nb = nowSec() + 1.5; logFile("[9] balls fed to the simulation: %d (cue at %.3f,%.3f)", (int)balls.size(), (double)cp.x, (double)cp.z);
        for (size_t i = 0; i < balls.size() && i < 16; ++i) logFile("[9] ball id=%d at (%.3f,%.3f) r=%.4f", balls[i].id, balls[i].p.x, balls[i].p.z, balls[i].r); } }
    // pockets: v16 - GameManager.tableTubes holds plain 'Tube' data objects (not Components), so reading a Transform from them always failed (0 pockets).
    // The real pockets are the 6 'Pocket' MonoBehaviours (PoolLiveTourMax.GameRules); position = their transform.
    std::vector<pp::V2> pk = readPockets(gm);
    if (pk.size() < 4) { why("fewer than 4 pockets read", (long)pk.size()); hideAll(); return; }

    g_dstage = 4;
    // power (v20: raw values are logged so a wrong offset is visible; offsets/divisor can be overridden from pp_cfg.txt: pwroff, pwrdiv)
    double power = g_cfg.fpower;
    if (void* pb = findPB()) {
        float lv = rd<float>(pb, off::PB_levelMaxPower), pf = rd<float>(pb, (int)g_cfg.pwroff);
        double dv = g_cfg.pwrdiv > 1e-6 ? g_cfg.pwrdiv : (lv > 0.01f ? (double)lv : 0.0);
        // v37 LATCH: horizontalForce@0x20 snaps back to levelMaxPower the moment the slider is released, so the last aiming frame (the one the recorder keeps)
        // said 1.000 for shots pulled to 0.45-0.8. |forceDirection| (Vector3 @0x28, z @0x30) follows the pull while aiming AND stays at the last pull after release
        // (pp_shots_4: 3.552 / 3.199 reproduced exactly), so it is the power source unless pwrsrc=1.
        float fx = rd<float>(pb, 0x28), fz = rd<float>(pb, 0x30); double fmag = std::sqrt((double)fx * fx + (double)fz * fz);
        double pfUse = (double)pf;
        if (g_cfg.pwrsrc < 0.5 && fmag == fmag && fmag > 0.005 && dv > 1e-6 && fmag <= dv * 1.02) pfUse = fmag;
        { static double nl = 0; if (nowSec() > nl) { nl = nowSec() + 3.0; logFile("[10b] power latch: |forceDirection|=%.4f horizontalForce=%.4f -> used %.4f (pwrsrc=%d)", fmag, (double)pf, pfUse, (int)g_cfg.pwrsrc); } }
        if (dv > 1e-6) power = std::max(0.02, std::min(1.0, pfUse / dv));   // v28: horizontalForce@0x20 ramps 0..levelMaxPower with the slider (pp_cap_3); 0 = slider at the bottom, not "unknown"
        { static double np = 0; if (nowSec() > np) { np = nowSec() + 3.0; logFile("[10] power: float@0x%X=%.4f levelMaxPower=%.4f divisor=%.4f -> power=%.3f | horizontalForce@0x20=%.4f previewForce@0x24=%.4f finalVelocity@0x40=%.4f", (int)g_cfg.pwroff, (double)pf, (double)lv, dv, power, (double)rd<float>(pb, 0x20), (double)rd<float>(pb, 0x24), (double)rd<float>(pb, 0x40)); } }
        if (g_cfg.disc > 0.5) { static Watch wp; watchFloats(wp, "PhysicsBuilder", pb, 0x10, 0x60); }
    } else { static double np2 = 0; if (nowSec() > np2) { np2 = nowSec() + 5.0; logFile("[10] power: PhysicsBuilder not found -> power=%.2f (fpower)", power); } }
    // spin: only when the offsets are known (pp_cfg.txt: spinxoff / spinyoff = float offsets inside CueBall)
    double spinX = 0, spinY = 0;
    if (g_cfg.spinxoff > 0) spinX = std::max(-1.0, std::min(1.0, (double)rd<float>(cb, (int)g_cfg.spinxoff) * g_cfg.spinsgnx * g_cfg.spinscale));
    if (g_cfg.spinyoff > 0) spinY = std::max(-1.0, std::min(1.0, (double)rd<float>(cb, (int)g_cfg.spinyoff) * g_cfg.spinsgny * g_cfg.spinscale));
    if (g_cfg.disc > 0.5) { static Watch wc; watchFloats(wc, "CueBall", cb, 0x1A0, 0x2A0); }
    // v22: spin from the game's own controllers (used when spinxoff/spinyoff are not set). spinsrc 0 = SpinController.spinFactorx/y, 1 = ClientSpinController horizontal/vertical, 2 = off
    {
        void* sc = findOne(kSpinCtl, g_spin, g_spinNext); void* cs = findOne(kClientSpin, g_cspin, g_cspinNext);
        float sfx = sc ? rd<float>(sc, 0x11C) : 0.f, sfy = sc ? rd<float>(sc, 0x120) : 0.f;
        float chx = cs ? rd<float>(cs, 0x40) : 0.f, cvy = cs ? rd<float>(cs, 0x3C) : 0.f, crad = cs ? rd<float>(cs, 0x44) : 0.f;
        { static double ns = 0; if (nowSec() > ns) { ns = nowSec() + 2.0; logFile("[12] spin: SpinController(%s) factorX=%.4f factorY=%.4f | ClientSpin(%s) horizontal=%.4f vertical=%.4f radius=%.4f | src=%d", sc ? "ok" : "none", (double)sfx, (double)sfy, cs ? "ok" : "none", (double)chx, (double)cvy, (double)crad, (int)g_cfg.spinsrc); } }
        if (g_cfg.spinxoff <= 0 && g_cfg.spinyoff <= 0 && g_cfg.spinsrc < 1.5) {
            double rx = g_cfg.spinsrc < 0.5 ? sfx : (crad > 1.f ? chx / crad : 0.0), ry = g_cfg.spinsrc < 0.5 ? sfy : (crad > 1.f ? cvy / crad : 0.0);   // v27: the client controller is in pixels (radius 60)
            spinX = std::max(-1.0, std::min(1.0, rx * g_cfg.spinsgnx * g_cfg.spinscale));
            spinY = std::max(-1.0, std::min(1.0, ry * g_cfg.spinsgny * g_cfg.spinscale));
        }
    }

    if (g_bndGm != gm) { g_bndGm = gm; g_bndTries = 0; }
    static double nextB = 0;
    if (g_bndFor != gm && g_bndTries < 12 && nowSec() >= nextB) { nextB = nowSec() + 2.6;      // v14 (v17: retried until PhysicsBuilder exists): log the REAL cushion colliders once per match, so inset/keep can be set from measurements instead of guesses
        ++g_bndTries; if (g_bndTries == 1) g_bndFor = nullptr;
        logFile("[6] pockets=%d ball.radius=%.4f", (int)pk.size(), (double)cr);
        for (size_t i = 0; i < pk.size(); ++i) logFile("[6] pocket[%d]=(%.4f,%.4f)", (int)i, pk[i].x, pk[i].z);
        void* pb2 = findPB();
        if (!pb2) logFile("[6] PhysicsBuilder not found yet (try %d) - will retry", g_bndTries);
        else if (!mGetBounds) logFile("[6] Collider.get_bounds not resolved");
        else {
            void* cl = rd<void*>(pb2, 0x50);
            void* it = plausible(cl) ? rd<void*>(cl, off::L_items) : nullptr; int n = plausible(cl) ? rd<int>(cl, off::L_size) : 0;
            logFile("[6] cushion colliders=%d", n);
            std::vector<Bnd> bs;
            if (plausible(it) && n > 0 && n <= 16) for (int i = 0; i < n; ++i) {
                void* col = rd<void*>(it, off::ARR_data + 8 * i); if (!alive(col)) continue;
                Bnd b = ((Bnd (*)(void*, const Method*))fnptr(mGetBounds))(col, mGetBounds);
                logFile("[6] cushion[%d] centre=(%.4f,%.4f,%.4f) ext=(%.4f,%.4f,%.4f)", i, (double)b.c[0], (double)b.c[1], (double)b.c[2], (double)b.e[0], (double)b.e[1], (double)b.e[2]);
                bs.push_back(b);
            }
            if (!bs.empty()) {
                g_bndFor = gm; Meas m;
                if (deriveLimits(bs, pk, (double)cr, m)) { g_meas = m; g_measFor = gm; logFile("[6] MEASURED ball-centre limits x[%.4f,%.4f] z[%.4f,%.4f] (radius %.4f)", m.xmin, m.xmax, m.zmin, m.zmax, (double)cr); }
                else logFile("[6] cushion colliders could not be turned into table limits (using inset=%.3f)", g_cfg.inset);
            }
        }
    }
    pp::Table T = (g_cfg.usecol > 0.5 && g_meas.ok && g_measFor == gm)
        ? pp::Table::fromLimits(pk, g_meas.xmin, g_meas.xmax, g_meas.zmin, g_meas.zmax, g_cfg.corner, g_cfg.mid, g_cfg.gapc, g_cfg.gapm)
        : pp::Table::fromPockets(pk, g_cfg.inset, g_cfg.corner, g_cfg.mid, g_cfg.gapc, g_cfg.gapm);
    // v21: the game's own first-contact result (CueBall: forceDirectionAfterCollided 0x220, collidedBallForceDirection 0x22C, collided 0x26C, hitDistance 0x25C)
    Vec3 gCue = rd<Vec3>(cb, 0x220), gTgt = rd<Vec3>(cb, 0x22C); bool gColl = rd<bool>(cb, 0x26C);
    auto nrm = [](const Vec3& v, pp::V2& o) { double l = std::sqrt((double)v.x * v.x + (double)v.z * v.z); if (!(l > 0.2 && l < 1e3) || v.x != v.x) return false; o = {v.x / l, v.z / l}; return true; };
    pp::V2 ovC, ovT; bool ovOk = g_cfg.useov > 0.5 && nrm(gTgt, ovT) && nrm(gCue, ovC);
    { static double nov = 0; if (nowSec() > nov) { nov = nowSec() + 2.0; logFile("[11] game post-contact: collided=%d cueAfter=(%.3f,%.3f) target=(%.3f,%.3f) spinMagnitude=%.4f valid=%d", (int)gColl, (double)gCue.x, (double)gCue.z, (double)gTgt.x, (double)gTgt.z, (double)rd<float>(cb, 0x20C), (int)ovOk); } }
    double dragNow = g_cfg.drag; if (g_cfg.autophys > 0.5) { double gd; if (readGameDrag(gd)) dragNow = gd; { static double nd2 = 0; if (nowSec() > nd2) { nd2 = nowSec() + 4.0; logFile("[13] table/physics: drag=%.4f (game) vmax=%.3f ballRadius=%.4f cushionKeep=%.3f ballKeep=%.3f pockets=%d measuredLimits=%d", dragNow, g_cfg.vmax, (double)cr, g_cfg.keep, g_cfg.ballkeep, (int)pk.size(), (int)(g_meas.ok && g_measFor == gm)); } } }
    pp::Config C; C.maxBounces = g_cfg.bounces; C.maxChain = g_cfg.chain; C.cushionKeep = g_cfg.keep; C.ballKeep = g_cfg.ballkeep; C.drag = dragNow; C.vMax = g_cfg.vmax;
    C.hasOv = ovOk; C.ovTarget = ovT; C.ovCue = ovC; C.spinX = spinX; C.spinY = spinY; C.kSide = g_cfg.kside; C.kFollow = g_cfg.kfollow; C.kDraw = g_cfg.kdraw;
    g_dstage = 5;
    bool useProbe = g_cfg.probe > 0.5 && ensureProbe(gm, cp.y, g_cfg.castoff);
    // v37h: no more per-frame full simulation (it froze the game at the start of a match: 450k SphereCasts in one report).
    // (1) same inputs as last time -> reuse the result; (2) inputs changed -> recompute at most every 50 ms; (3) every run has a 6 ms wall-clock budget.
    C.budgetMs = 6.0;
    static pp::Result s_R; static bool s_has = false; static double s_t = 0; static uint64_t s_sig = 0; static void* s_gm = nullptr;
    uint64_t sig = 1469598103934665603ULL; auto mix = [&](double v) { int64_t q = (int64_t)std::llround(v * 20000.0); sig = (sig ^ (uint64_t)q) * 1099511628211ULL; };
    mix(dir.x); mix(dir.z); mix(power); mix(spinX); mix(spinY); mix(cp.x); mix(cp.z); mix(dragNow); mix((double)balls.size()); for (auto& bb : balls) { mix(bb.p.x); mix(bb.p.z); }
    pp::Result R;
    double tnow = nowSec();
    if (s_has && s_gm == gm && (sig == s_sig || tnow - s_t < 0.05)) { R = s_R; }
    else { pp::Sim sim(T, C, balls, {cp.x, cp.z}, cr); if (useProbe) sim.setProbe(&g_probe); R = sim.run(dir, power); s_R = R; s_has = true; s_t = tnow; s_sig = sig; s_gm = gm; }
    logRestitutionLive();
    logPhysMat(cb);
    { static double np = 0; if (nowSec() > np) { np = nowSec() + 3.0; logFile("[14] geometry: %s | casts=%d cushionHits=%d skippedNonCushion=%d lastHit t=%.4f n=(%.3f,%.3f) castRadius=%.4f", useProbe ? "GAME SphereCast" : (g_cfg.probe > 0.5 ? "probe unavailable -> rectangle fallback" : "rectangle (probe=0)"), g_probeCalls, g_probeHits, g_probeSkipped, g_probeLastT, g_probeLastNx, g_probeLastNz, (double)cr + (useProbe ? (double)g_probe.extra : 0.0)); } }

    { static double nextHb = 0; double tn = nowSec(); if (tn > nextHb) { nextHb = tn + 3.0; logFile("[5] draw: tracks=%d power=%.2f dir=(%.2f,%.2f)", (int)R.tracks.size(), (double)power, (double)dir.x, (double)dir.z); } }
    { g_pred.valid = true; g_pred.t = nowSec(); g_pred.power = power; g_pred.dx = dir.x; g_pred.dz = dir.z; g_pred.sx = spinX; g_pred.sy = spinY; g_pred.drag = dragNow; g_pred.vmax = g_cfg.vmax; g_pred.keep = g_cfg.keep;
      g_pred.cx = cp.x; g_pred.cz = cp.z; g_pred.balls = balls; g_pred.tracks = R.tracks; g_pred.finals = R.finals; }
    g_dstage = 6;
    size_t used = 0; const float y0 = cp.y + (float)g_cfg.lift; const int cm = (int)g_cfg.colormode; const size_t MAXL = (size_t)std::max(1.0, std::min(60.0, g_cfg.maxlines));
    auto lineAt = [&](size_t i) -> void* { void* lr = ensureLine(i, templ); if (lr) forceVisible(lr, (float)g_cfg.width); return lr; };
    auto ring = [&](pp::V2 c, double rad, Col col) -> bool {          // circle marker (ghost ball / end of a path)
        if (used >= MAXL) return true; void* lr = lineAt(used); if (!lr) return false;
        const int N = 24; setCount(lr, N + 1); float y = y0 + 0.0006f * (float)used;
        for (int k = 0; k <= N; ++k) { double a = 6.28318530718 * k / N; setPos(lr, k, {(float)(c.x + rad * std::cos(a)), y, (float)(c.z + rad * std::sin(a))}); }
        setColor(lr, col); ++used; return true;
    };
    auto dot = [&](pp::V2 c, Col col) -> bool {                 // v26: filled dot (a thick, tiny ring) at the end of a path, like the reference tool
        if (used >= MAXL) return true; void* lr = ensureLine(used, templ); if (!lr) return false;
        forceVisible(lr, (float)(cr * 1.3)); const int N = 10; setCount(lr, N + 1); float y = y0 + 0.0006f * (float)used; double rr = cr * 0.22;
        for (int k = 0; k <= N; ++k) { double a = 6.28318530718 * k / N; setPos(lr, k, {(float)(c.x + rr * std::cos(a)), y, (float)(c.z + rr * std::sin(a))}); }
        setColor(lr, col); ++used; return true;
    };
    // draw order: target / chain paths first, the cue path LAST (white on top), each line a hair higher than the previous so equal heights never z-fight
    std::vector<const pp::Track*> order; for (auto& t : R.tracks) if (t.pts.size() >= 2 && !(t.id == -1 && t.gen == 0)) order.push_back(&t);
    for (auto& t : R.tracks) if (t.pts.size() >= 2 && t.id == -1 && t.gen == 0) order.push_back(&t);
    for (const pp::Track* tp : order) {
        const pp::Track& t = *tp; if (used >= MAXL) break;
        void* lr = lineAt(used); if (!lr) { why("could not create a line (ensureLine failed)"); hideAll(); return; }
        float y = y0 + 0.0006f * (float)used;
        setCount(lr, (int)t.pts.size());
        for (size_t i = 0; i < t.pts.size(); ++i) setPos(lr, (int)i, {(float)t.pts[i].x, y, (float)t.pts[i].z});
        Col col = trackColor(t, cm); setColor(lr, col); ++used;
        if (g_cfg.markers > 0.5) {
            if (t.end == pp::END_BALL) { if (!ring(t.ghost, cr, t.id == -1 && t.gen == 0 ? WHITE : col)) { hideAll(); return; } }
            else if (t.end == pp::END_REST || t.end == pp::END_BOUNCELIMIT) { bool okd = g_cfg.dots > 0.5 ? dot(t.pts.back(), col) : ring(t.pts.back(), cr * 0.7, col); if (!okd) { hideAll(); return; } }
        }
    }
    // v23: pocket rings. Every pocket gets a dim ring (its capture radius); a pocket that a path ends in lights up (bright green, double ring, thicker).
    if (g_cfg.rings > 0.5) {
        std::vector<int> lit(T.pockets.size(), 0); for (auto& t : R.tracks) if (t.end == pp::END_POCKET && t.pocket >= 0 && t.pocket < (int)lit.size()) lit[t.pocket] = 1 + (t.id == -1 && t.gen == 0 ? 1 : 0);
        auto ringX = [&](pp::V2 c, double rad, Col col, float w) -> bool {
            void* lr = ensureLine(used, templ); if (!lr) return false; forceVisible(lr, w);
            const int N = 32; setCount(lr, N + 1); float y = y0 + 0.0006f * (float)used;
            for (int k = 0; k <= N; ++k) { double a2 = 6.28318530718 * k / N; setPos(lr, k, {(float)(c.x + rad * std::cos(a2)), y, (float)(c.z + rad * std::sin(a2))}); }
            setColor(lr, col); ++used; return true;
        };
        for (size_t i = 0; i < T.pockets.size(); ++i) {
            const pp::Pocket& k = T.pockets[i];
            if (!lit[i]) { if (!ringX(k.p, k.mouth, Col{0.3f, 0.8f, 1.f, 0.55f}, (float)g_cfg.width * 0.7f)) break; }
            else {
                Col c = lit[i] == 2 ? Col{0.2f, 1.f, 0.35f, 1.f} : Col{1.f, 0.9f, 0.2f, 1.f};    // green = the cue-ball line itself pockets, yellow = a hit ball pockets
                if (!ringX(k.p, k.mouth, c, (float)g_cfg.width * 1.8f)) break; if (!ringX(k.p, k.mouth * 0.6, c, (float)g_cfg.width * 1.4f)) break;
            }
        }
    }
    { static double nd = 0; if (used > 0 && nowSec() > nd) { nd = nowSec() + 4.0; diagLine(g_pool[0].lr); } }
    for (size_t i = used; i < g_pool.size(); ++i) if (validLine(g_pool[i].lr)) setCount(g_pool[i].lr, 0);
}

// ---------- v26: one-press capture (app button). Phase 1 (0-28 s): the player moves the POWER slider. Phase 2 (28-56 s): moves the SPIN point.
// Everything goes to pp_cap.txt: per-field min / max / change-count of the power and spin objects, a time series, and the machine code of every
// method whose name has to do with power / spin (found by NAME in every class, so the class of the unknown ApplySpin singleton is revealed too).
static const struct { const char* name; int from, n; } CAPD[4] = {{"PhysicsBuilder", 0x10, 56}, {"SpinController", 0x100, 40}, {"ClientSpinController", 0x20, 40}, {"CueBall", 0x1A0, 96}};
struct CapF { float mn = 0, mx = 0, last = 0; int chg = 0; bool init = false; };
static CapF g_cf[2][4][96];
static double g_capSeen = 0, g_capT0 = 0, g_capRow = 0; static int g_capPhase = 0; static bool g_capInit = false;
static void capLog(const char* fmt, ...) {
    if (dirNow().empty()) return; FILE* f = fopen((g_dir + "pp_cap.txt").c_str(), "a"); if (!f) return;
    va_list ap; va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap); fputc('\n', f); fclose(f);
}
static bool capWanted(const char* n) {
    static const char* K[] = {"ApplySpin", "HorizontalForce", "FinalVelocity", "LevelPower", "PredictedFinal", "GetPower", "SetPower", "CalcPower", "SpinAngel", "SetSpin", "UpdatePower"};
    for (auto k : K) if (strstr(n, k)) return true; return false;
}
static void capMethods() {
    if (!il2cpp_image_get_class_count || !il2cpp_image_get_class || !il2cpp_class_get_name) { capLog("[M] class enumeration API not available in this il2cpp"); return; }
    int found = 0; size_t na = 0; Assembly** as = il2cpp_domain_get_assemblies(il2cpp_domain_get(), &na);
    for (size_t a = 0; a < na && found < 40; ++a) {
        const Image* im = il2cpp_assembly_get_image(as[a]); const char* in = il2cpp_image_get_name(im); if (!in || !strstr(in, "Assembly-CSharp")) continue;
        size_t nc = il2cpp_image_get_class_count(im);
        for (size_t c = 0; c < nc && found < 40; ++c) {
            Klass* k = (Klass*)il2cpp_image_get_class(im, c); if (!k) continue; void* it = nullptr;
            while (const Method* m = il2cpp_class_get_methods(k, &it)) {
                const char* mn = il2cpp_method_get_name(m); if (!mn || !capWanted(mn)) continue;
                void* fp = fnptr(m); if (!plausible(fp)) continue; ++found; unsigned long rva = (unsigned long)((uintptr_t)fp - g_il2Base);
                const char* cn = il2cpp_class_get_name(k); const char* ns = il2cpp_class_get_namespace ? il2cpp_class_get_namespace(k) : "";
                capLog("[M] %s.%s::%s argc=%u rva=0x%lx", ns ? ns : "", cn ? cn : "?", mn, (unsigned)il2cpp_method_get_param_count(m), rva);
                for (int o = 0; o < 0x500; o += 32) {
                    char b[100]; int n = 0; for (int j = 0; j < 32; ++j) n += snprintf(b + n, sizeof b - n, "%02x", ((const unsigned char*)fp)[o + j]);
                    capLog("  %lx: %s", rva + (unsigned long)o, b);
                }
            }
        }
    }
    capLog("[M] %d methods dumped", found);
}
static void capSample(int ph, int o, const void* base) {
    if (!base) return;
    for (int i = 0; i < CAPD[o].n; ++i) {
        float v = rd<float>(base, CAPD[o].from + 4 * i); if (!(v == v) || std::fabs(v) > 1e9f) continue; CapF& f = g_cf[ph][o][i];
        if (!f.init) { f.init = true; f.mn = f.mx = f.last = v; } else { if (v < f.mn) f.mn = v; if (v > f.mx) f.mx = v; if (v != f.last) { ++f.chg; f.last = v; } }
    }
}
static void capSummary() {
    for (int ph = 0; ph < 2; ++ph) for (int o = 0; o < 4; ++o) {
        struct E { int off; float mn, mx; int chg; }; std::vector<E> v;
        for (int i = 0; i < CAPD[o].n; ++i) { const CapF& f = g_cf[ph][o][i]; if (f.init && f.chg >= 2 && f.mx - f.mn > 1e-4f) v.push_back({CAPD[o].from + 4 * i, f.mn, f.mx, f.chg}); }
        std::sort(v.begin(), v.end(), [](const E& a, const E& b) { return (a.mx - a.mn) > (b.mx - b.mn); });
        capLog("--- %s phase: %s: %d fields changed", ph == 0 ? "POWER" : "SPIN", CAPD[o].name, (int)v.size());
        for (size_t i = 0; i < v.size() && i < 14; ++i) capLog("  %s+0x%X min=%.4f max=%.4f changes=%d", CAPD[o].name, v[i].off, (double)v[i].mn, (double)v[i].mx, v[i].chg);
    }
    capLog("=== CAPTURE DONE");
}
static void capTick(void* self) {
    double t = nowSec();
    if (!g_capInit) { g_capInit = true; g_capSeen = g_cfg.cap; return; }      // a cap value left in the cfg file from an earlier session must not start a capture
    if (g_cfg.cap > 0 && g_cfg.cap != g_capSeen) {
        g_capSeen = g_cfg.cap; g_capPhase = 1; for (auto& a : g_cf) for (auto& b : a) for (auto& f : b) f = CapF();
        if (dirNow().empty()) { g_capPhase = 0; return; }
        { FILE* f = fopen((g_dir + "pp_cap.txt").c_str(), "w"); if (f) fclose(f); }
        capLog("=== PremiumPath capture v26 (power phase 0-28s, spin phase 28-56s)  il2cpp base=%p", (void*)g_il2Base);
        capMethods(); g_capT0 = nowSec(); g_capRow = 0; return;
    }
    if (g_capPhase == 0) return;
    double el = t - g_capT0;
    if (el > 56.0) { capSummary(); g_capPhase = 0; return; }
    void* cb = rd<void*>(self, off::CBV_cueBall); if (!plausible(cb)) return;
    void* pb = findPB(); void* sc = findOne(kSpinCtl, g_spin, g_spinNext); void* cs = findOne(kClientSpin, g_cspin, g_cspinNext);
    int ph = el < 28.0 ? 0 : 1;
    capSample(ph, 0, pb); capSample(ph, 1, sc); capSample(ph, 2, cs); capSample(ph, 3, cb);
    if (t > g_capRow) {
        g_capRow = t + 0.4;
        capLog("t=%.1f %s aim=%d | PB 20=%.3f 24=%.3f 40=%.3f 48=%.3f | SC 11C=%.3f 120=%.3f | CS 3C=%.3f 40=%.3f 44=%.3f", el, ph == 0 ? "POWER" : "SPIN", (int)rd<bool>(cb, off::CB_isAiming),
               pb ? (double)rd<float>(pb, 0x20) : -1.0, pb ? (double)rd<float>(pb, 0x24) : -1.0, pb ? (double)rd<float>(pb, 0x40) : -1.0, pb ? (double)rd<float>(pb, 0x48) : -1.0,
               sc ? (double)rd<float>(sc, 0x11C) : -1.0, sc ? (double)rd<float>(sc, 0x120) : -1.0, cs ? (double)rd<float>(cs, 0x3C) : -1.0, cs ? (double)rd<float>(cs, 0x40) : -1.0, cs ? (double)rd<float>(cs, 0x44) : -1.0);
    }
}


// ---------- v29: shot recorder. Every real shot is written to pp_shots.txt: what we predicted (power, direction, spin, the cue path and every track end)
// next to what the game really did (cue ball position every 0.04 s until it stops, and where every ball ended). This is the ground truth that
// the drag / cushion / spin constants are fitted from, instead of guessing them.
static bool g_wasAim = false, g_recOn = false; static double g_recT0 = 0, g_recNext = 0, g_recStill = 0, g_lastAimT = 0, g_recMoved = 0; static int g_shotNo = 0;
static std::vector<float> g_recPath; static PredSnap g_recPred; static double g_recLx = 0, g_recLz = 0;
// v30: a ring of the power fields, one row per 0.04 s (t, aim, PB+0x20, PB+0x28, PB+0x40): pp_cap_4 showed PB+0x20 sits at levelMaxPower the whole time the player is NOT
// touching the slider and drops to 0 after the shot, so the number we drew with at the last aiming frame was not what the player had pulled. The ring shows what happens at release.
struct PwrRow { float t, aim, f20, f28, f40; };
static std::vector<PwrRow> g_ring; static double g_ringNext = 0;
static void shotLog(const char* fmt, ...) {
    if (dirNow().empty()) return; FILE* f = fopen((g_dir + "pp_shots.txt").c_str(), "a"); if (!f) return;
    va_list ap; va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap); fputc('\n', f); fclose(f);
}
static void shotTrim() {   // keep the file small: when it passes ~150 KB, start it again
    if (dirNow().empty()) return; std::string fn = g_dir + "pp_shots.txt"; FILE* f = fopen(fn.c_str(), "r"); if (!f) return;
    fseek(f, 0, SEEK_END); long n = ftell(f); fclose(f); if (n > 150000) { f = fopen(fn.c_str(), "w"); if (f) fclose(f); }
}
static void shotFinish(void* self, const char* why_) {
    void* gm = rd<void*>(self, off::CBV_gameManager);
    shotTrim(); ++g_shotNo; const PredSnap& P = g_recPred;
    shotLog("=== SHOT %d (%s) after %.1fs | power=%.3f dir=(%.4f,%.4f) spin=(%.3f,%.3f) drag=%.3f vmax=%.3f cushionKeep=%.3f cue0=(%.4f,%.4f)",
            g_shotNo, why_, nowSec() - g_recT0, P.power, P.dx, P.dz, P.sx, P.sy, P.drag, P.vmax, P.keep, P.cx, P.cz);
    for (auto& t : P.tracks) {
        std::string s2; for (auto& q : t.pts) { char b[40]; snprintf(b, sizeof b, " %.3f,%.3f", q.x, q.z); s2 += b; }
        shotLog("PRED track id=%d gen=%d end=%d bounces=%d pts:%s", t.id, t.gen, (int)t.end, (int)t.bounceIdx.size(), s2.c_str());
    }
    { std::string s2; for (auto& f : P.finals) { char t[64]; snprintf(t, sizeof t, " %d:%.3f,%.3f%s", f.id < 0 ? 0 : f.id, f.p.x, f.p.z, f.pocketed ? "P" : ""); s2 += t; } shotLog("PRED_END%s", s2.c_str()); }
    { void* pb = findPB(); if (pb) { float fx = rd<float>(pb, 0x28), fz = rd<float>(pb, 0x30), lv = rd<float>(pb, off::PB_levelMaxPower); shotLog("PWR_LATCH |forceDirection|=%.4f levelMaxPower=%.4f -> real power=%.4f (logged power above is the prediction's)", std::sqrt((double)fx * fx + (double)fz * fz), (double)lv, lv > 0.01f ? std::sqrt((double)fx * fx + (double)fz * fz) / lv : 0.0); } }
    { std::string s2; for (auto& b : P.balls) { char t[48]; snprintf(t, sizeof t, " %d:%.3f,%.3f", b.id, b.p.x, b.p.z); s2 += t; } shotLog("BALLS0%s", s2.c_str()); }
    { std::string s2; for (auto& r : g_ring) if (r.t > g_recT0 - 2.0 && r.t < g_recT0 + 1.2) { char b[80]; snprintf(b, sizeof b, " %.2f/%d/%.3f/%.3f/%.3f", r.t - g_recT0, (int)r.aim, r.f20, r.f28, r.f40); s2 += b; }
      shotLog("PWR_RING (t_rel/aim/0x20/0x28/0x40):%s", s2.c_str()); }
    { std::string s2; for (size_t i = 0; i + 2 < g_recPath.size(); i += 3) { char b[48]; snprintf(b, sizeof b, " %.3f,%.3f,%.2f", g_recPath[i], g_recPath[i + 1], g_recPath[i + 2]); s2 += b; } shotLog("CUE_REAL (x,z,t_rel):%s", s2.c_str()); }
    std::string s3; void* list = plausible(gm) ? rd<void*>(gm, off::GM_balls) : nullptr;
    if (plausible(list)) { void* items = rd<void*>(list, off::L_items); int n = rd<int>(list, off::L_size);
        if (plausible(items) && n > 0 && n < 64) for (int i = 0; i < n; ++i) { void* b = rd<void*>(items, off::ARR_data + 8 * i); if (!alive(b)) continue;
            Vec3 p; if (!getPos(b, p)) continue; char t[64]; snprintf(t, sizeof t, " %d:%.3f,%.3f%s", i, (double)p.x, (double)p.z, rd<bool>(b, off::B_insidePocket) ? "P" : ""); s3 += t; } }
    shotLog("BALLS_END%s", s3.c_str());
    g_recOn = false; g_recPath.clear(); g_recPath.shrink_to_fit();
}
static void shotTick(void* self) {
    double t = nowSec(); void* cb = rd<void*>(self, off::CBV_cueBall); if (!plausible(cb)) return;
    bool aim = rd<bool>(cb, off::CB_isAiming);
    if (t >= g_ringNext) { g_ringNext = t + 0.04; void* pb = findPB();
        g_ring.push_back({(float)t, aim ? 1.f : 0.f, pb ? rd<float>(pb, 0x20) : -1.f, pb ? rd<float>(pb, 0x28) : -1.f, pb ? rd<float>(pb, 0x40) : -1.f});
        if (g_ring.size() > 220) g_ring.erase(g_ring.begin(), g_ring.begin() + 40); }
    if (aim) { g_wasAim = true; g_lastAimT = t; if (g_recOn && t - g_recT0 > 0.3) shotFinish(self, "new aim started"); }
    if (!g_recOn && !aim && g_wasAim) {                       // aiming just ended: a shot if we had a fresh prediction
        g_wasAim = false;
        if (g_pred.valid && t - g_pred.t < 1.0 && t - g_lastAimT < 1.0) { g_recOn = true; g_recPred = g_pred; g_recT0 = t; g_recNext = 0; g_recStill = 0; g_recMoved = 0; g_recPath.clear(); Vec3 p; if (getPos(cb, p)) { g_recLx = p.x; g_recLz = p.z; } }
    }
    if (!g_recOn) return;
    double el = t - g_recT0; Vec3 p; if (!getPos(cb, p)) { if (el > 0.5) shotFinish(self, "cue gone/pocketed"); return; }
    { static int rs = 0; static double lastT0 = -1; if (lastT0 != g_recT0) { lastT0 = g_recT0; rs = 0; }   // v37g: PhysicsSolver statics at 0.2 s, 0.8 s and 2.0 s after release
      if (rs == 0 && el > 0.2) { rs = 1; logRestitutionShot("AFTER", el); } else if (rs == 1 && el > 0.8) { rs = 2; logRestitutionShot("AFTER", el); } else if (rs == 2 && el > 2.0) { rs = 3; logRestitutionShot("AFTER", el); } }
    if (t >= g_recNext) { g_recNext = t + 0.04; g_recPath.push_back(p.x); g_recPath.push_back(p.z); g_recPath.push_back((float)el);
        double mv = std::fabs((double)p.x - g_recLx) + std::fabs((double)p.z - g_recLz); g_recLx = p.x; g_recLz = p.z;
        if (mv > 0.6) { shotFinish(self, "cue teleported (ball in hand / new rack)"); return; }
        g_recMoved += mv; if (mv < 2e-4) g_recStill += 0.04; else g_recStill = 0; }
    if (g_recPath.size() > 3 * 700) { shotFinish(self, "time limit"); return; }
    if (g_recMoved > 0.02 && el > 1.2 && g_recStill > 0.8) { shotFinish(self, "stopped"); return; }          // only after the ball has moved: the cue stick animation takes ~0.3 s first
    if (g_recMoved <= 0.02 && el > 12.0) { g_recOn = false; g_recPath.clear(); }                               // aiming was cancelled, nothing moved
}

// ---------- hook ----------
static void (*g_orig)(void*, const Method*) = nullptr; static volatile bool g_dead = false; static int g_err = 0;
static double g_coolUntil = 0; static double g_faultT[8]; static int g_faultN = 0;
// v21: a fault no longer kills the feature for the whole session. All caches (lines, PhysicsBuilder, pockets, cushions) are dropped and rebuilt after a 2 s cool-down;
// only 5 faults inside 2 minutes disable it for real.
static void resetAll() {
    for (auto& l : g_pool) g_pending.push_back(l);
    g_pool.clear(); g_poolOwner = nullptr; g_template = nullptr; g_pb = nullptr; g_gp = nullptr; g_pk.clear(); g_pkFor = nullptr; g_meas = Meas(); g_measFor = nullptr; g_bndFor = nullptr; g_bndTries = 0; g_bndGm = nullptr; g_cush.clear(); g_cushFor = nullptr; g_cushMask = 0; g_cushNext = 0; g_cushTry = 0;
}
static void hooked(void* self, const Method* mi) {
    g_orig(self, mi);
    { static bool first = true; if (first) { first = false; logFile("[5] hook is being called by the game (LateUpdate running)"); } }
    static double nextCfg = 0, nextH = 0; double t = nowSec(); if (t > nextCfg) { nextCfg = t + 1.0; loadCfg(); }
    if (t > nextH) { nextH = t + 2.0; ensureHandler(); }
    if (g_dead || t < g_coolUntil) return;
    g_tid = tidNow(); g_in = 1;
    if (sigsetjmp(g_jb, 1) == 0) { g_dstage = 95; capTick(self); g_dstage = 96; shotTick(self); g_dstage = 97; queryTick(); draw(self); }
    else {
        g_in = 0; ++g_err; resetAll(); g_coolUntil = nowSec() + 2.0;
        g_faultT[g_faultN++ & 7] = nowSec(); int recent = 0; for (int i = 0; i < 8; ++i) if (g_faultT[i] > nowSec() - 120.0) ++recent;
        if (g_dstage == 93) { g_skipDrain = true; g_pending.clear(); logFile("[X] stage 93 (drainPending) faulted: parked clones are now dropped without being touched"); }
        logFile("fault inside draw() at stage %d addr=%p pc=%p (libil2cpp+0x%lx): caches reset, retry in 2s (faults in last 2min: %d)", (int)g_dstage, (void*)g_fAddr, (void*)g_fPc, (unsigned long)(g_fPc - g_il2Base), recent);
        if (recent >= 5) { g_dead = true; logFile("too many faults: feature disabled until the game restarts"); }
    }
    g_in = 0;
}

static bool resolve() {
    Klass *kObj = findClass("UnityEngine", "Object"), *kComp = findClass("UnityEngine", "Component"), *kTr = findClass("UnityEngine", "Transform"), *kLR = findClass("UnityEngine", "LineRenderer");
    kPhysicsBuilder = findClass("PoolLiveTourMax.Physic.Handlers", "PhysicsBuilder"); if (!kPhysicsBuilder) kPhysicsBuilder = findClass("", "PhysicsBuilder");
    logFile("[4] PhysicsBuilder class %s", kPhysicsBuilder ? "found" : "NOT found");
    kSpinCtl = findClass("PoolLiveTourMax.Gameplay.Shot", "SpinController"); if (!kSpinCtl) kSpinCtl = findClass("", "SpinController");
    kClientSpin = findClass("PoolLiveTourMax.Client.UI", "ClientSpinController"); if (!kClientSpin) kClientSpin = findClass("", "ClientSpinController");
    kGamePhysics = findClass("PoolLiveTour.Physic.Handlers", "GamePhysics"); if (!kGamePhysics) kGamePhysics = findClass("PoolLiveTourMax.Physic.Handlers", "GamePhysics"); if (!kGamePhysics) kGamePhysics = findClass("", "GamePhysics");
    logFile("[4] GamePhysics class %s", kGamePhysics ? "found" : "NOT found");
    logFile("[4] spin classes: SpinController %s, ClientSpinController %s", kSpinCtl ? "found" : "NOT found", kClientSpin ? "found" : "NOT found");
    { Klass* kC = findClass("UnityEngine", "Component"); Klass* kG = findClass("UnityEngine", "GameObject"); Klass* kR = findClass("UnityEngine", "Renderer"); Klass* kL = findClass("UnityEngine", "LineRenderer");
      if (kC) mGetGO = findMethod(kC, "get_gameObject", 0);
      if (kG) { mSetActive = findMethod(kG, "SetActive", 1); mActiveInH = findMethod(kG, "get_activeInHierarchy", 0); }
      if (kR) { mRendSetEn = findMethod(kR, "set_enabled", 1); mRendGetEn = findMethod(kR, "get_enabled", 0); }
      if (kL) { mSetSW = findMethod(kL, "set_startWidth", 1); mSetEW = findMethod(kL, "set_endWidth", 1); mSetWM = findMethod(kL, "set_widthMultiplier", 1); mGetCnt = findMethod(kL, "get_positionCount", 0); mGetSW = findMethod(kL, "get_startWidth", 0); }
      logFile("[4] optional methods: gameObject=%d SetActive=%d activeInHierarchy=%d rendererEnabled=%d widths=%d", mGetGO != nullptr, mSetActive != nullptr, mActiveInH != nullptr, mRendSetEn != nullptr, mSetSW != nullptr); }
    kPocket = findClass("PoolLiveTourMax.GameRules", "Pocket"); if (!kPocket) kPocket = findClass("", "Pocket");
    { Klass* kCol = findClass("UnityEngine", "Collider"); if (kCol) mGetBounds = findMethod(kCol, "get_bounds", 0); }
    {   // v36: the game's own cast + hit helpers
        Klass* kPh = findClass("UnityEngine", "Physics"); Klass* kRH = findClass("UnityEngine", "RaycastHit"); Klass* kGO2 = findClass("UnityEngine", "GameObject");
        if (kPh) { mSphereCast = findMethod(kPh, "SphereCast", 6, "UnityEngine.Vector3"); mDefContact = findMethod(kPh, "get_defaultContactOffset", 0); }
        if (kRH) mHitCollider = findMethod(kRH, "get_collider", 0);
        if (kGO2) mGetLayer = findMethod(kGO2, "get_layer", 0);
        logFile("[4] probe methods: Physics.SphereCast(6 args, Vector3 first)=%d RaycastHit.get_collider=%d GameObject.get_layer=%d defaultContactOffset=%d", mSphereCast != nullptr, mHitCollider != nullptr, mGetLayer != nullptr, mDefContact != nullptr);
    }
    if (!kObj || !kComp || !kTr || !kLR) return false;
    mGetTransform = findMethod(kComp, "get_transform", 0); mGetPosition = findMethod(kTr, "get_position", 0);
    mInstantiate = findMethod(kObj, "Instantiate", 1, "UnityEngine.Object"); mFindObjs = findMethod(kObj, "FindObjectsByType", 2, "System.Type");
    mSetCount = findMethod(kLR, "set_positionCount", 1); mSetPos = findMethod(kLR, "SetPosition", 2); mSetWorld = findMethod(kLR, "set_useWorldSpace", 1);
    mSetC0 = findMethod(kLR, "set_startColor", 1); mSetC1 = findMethod(kLR, "set_endColor", 1);
    const Method* all[] = {mGetTransform, mGetPosition, mInstantiate, mSetCount, mSetPos, mSetWorld, mSetC0, mSetC1};
    for (auto m : all) if (!m || !fnptr(m)) return false;
    return true;
}

// ---------- v37: physics function dump. libil2cpp.so is already mapped in this process, so base + RVA (RVAs from dump.cs, ranges up to the next function)
// gives the exact machine code of the physics functions. They are written as hex to pp_funcs.txt; tools/disasm_funcs.py (CI "Disassemble") turns them into assembly.
// Also logs the static restitution floats of PhysicsSolver (the two constants every ball/cushion bounce uses).
struct FnRec { const char* name; uint32_t rva; uint32_t len; };
static const FnRec FN_TABLE[] = {
#include "funcs_table.inc"
};
static bool funcsNeeded() {
    std::string fn = g_dir + "pp_funcs.txt"; FILE* f = fopen(fn.c_str(), "r"); if (!f) return true;
    char line[128]; long id = 0; bool ok = fgets(line, sizeof line, f) != nullptr; fclose(f);
    if (!ok) return true;
    const char* p = strstr(line, "id="); if (p) id = atol(p + 3);
    return g_cfg.dumpfn != 0 && id != (long)g_cfg.dumpfn;
}
static void dumpFuncs() {
    if (dirNow().empty()) { logFile("[7] funcs dump: no writable dir"); return; }
    if (!funcsNeeded()) { logFile("[7] pp_funcs.txt already there (press the app's funcs button to rewrite it)"); return; }
    uintptr_t base = g_il2Base;
    if (!base) { il2::Mod m; if (il2::findModule("libil2cpp.so", m)) base = m.base; }
    if (!base) { logFile("[7] funcs dump: libil2cpp base unknown"); return; }
    std::string fn = g_dir + "pp_funcs.txt"; FILE* f = fopen(fn.c_str(), "w"); if (!f) { logFile("[7] funcs dump: cannot write %s", fn.c_str()); return; }
    fprintf(f, "# PremiumPath funcs dump id=%ld base=0x%lx n=%d\n", (long)g_cfg.dumpfn, (unsigned long)base, (int)(sizeof FN_TABLE / sizeof FN_TABLE[0]));
    // sanity: CueBall.ApplySpin starts with 'stp d11,d10,[sp,#-0x50]!' = 0x6dbb2beb (seen in ApplySpin_verified.txt). Proves base + RVA is the right mapping.
    for (const FnRec& r : FN_TABLE) if (!strcmp(r.name, "CueBall.ApplySpin")) {
        uint32_t w = *(const uint32_t*)(base + r.rva);
        logFile("[7] rva check: CueBall.ApplySpin first word=0x%08x (expect 0x6dbb2beb) -> %s", w, w == 0x6dbb2bebu ? "OK" : "MISMATCH");
    }
    long total = 0;
    for (const FnRec& r : FN_TABLE) {
        const uint8_t* p = (const uint8_t*)(base + r.rva);
        fprintf(f, "F %s %X %u ", r.name, r.rva, r.len);
        for (uint32_t i = 0; i < r.len; ++i) fprintf(f, "%02x", p[i]);
        fputc('\n', f); total += r.len;
    }
    fclose(f); logFile("[7] wrote %s: %d functions, %ld bytes", fn.c_str(), (int)(sizeof FN_TABLE / sizeof FN_TABLE[0]), total);
}
static void dumpStatics() {
    Klass* k = findClass("PoolLiveTourMax.Physic.Handlers", "PhysicsSolver"); if (!k) k = findClass("PoolLiveTour.Physic.Handlers", "PhysicsSolver"); if (!k) k = findClass("", "PhysicsSolver");
    if (!k && il2cpp_image_get_class_count && il2cpp_image_get_class && il2cpp_class_get_name) {   // namespace differs from the guesses: scan every class by name
        size_t na = 0; Assembly** as = il2cpp_domain_get_assemblies(il2cpp_domain_get(), &na);
        for (size_t i = 0; as && i < na && !k; ++i) {
            const Image* im = il2cpp_assembly_get_image(as[i]); size_t nc = il2cpp_image_get_class_count(im);
            for (size_t c = 0; c < nc; ++c) {
                const Klass* kc = il2cpp_image_get_class(im, c); const char* cn = kc ? il2cpp_class_get_name(kc) : nullptr;
                if (cn && !strcmp(cn, "PhysicsSolver")) { k = (Klass*)kc; logFile("[7] statics: PhysicsSolver found by scan, namespace='%s'", il2cpp_class_get_namespace ? il2cpp_class_get_namespace(kc) : "?"); break; }
            }
        }
    }
    if (!k) { logFile("[7] statics: PhysicsSolver class not found"); return; }
    if (!il2cpp_class_get_field_from_name || !il2cpp_field_static_get_value) { logFile("[7] statics: il2cpp field API not exported"); return; }
    const char* names[2] = {"ballrestituation", "edgerestitution"};
    for (const char* nm : names) {
        void* fi = il2cpp_class_get_field_from_name(k, nm); float v = -1234.f;
        if (!fi) { logFile("[7] PhysicsSolver.%s: field not found", nm); continue; }
        il2cpp_field_static_get_value(fi, &v); logFile("[7] PhysicsSolver.%s = %.6f", nm, v);
    }
}

static bool readRestitution(float& b, float& e) {   // v37g: unthrottled read, also used right after a shot
    static void* fi[2] = {nullptr, nullptr}; static bool tried = false;
    if (!tried) {
        tried = true;
        if (!il2cpp_class_get_field_from_name || !il2cpp_field_static_get_value || !il2cpp_image_get_class_count || !il2cpp_image_get_class || !il2cpp_class_get_name) return false;
        size_t na = 0; Assembly** as = il2cpp_domain_get_assemblies(il2cpp_domain_get(), &na); Klass* k = nullptr;
        for (size_t i = 0; as && i < na && !k; ++i) {
            const Image* im = il2cpp_assembly_get_image(as[i]); size_t nc = il2cpp_image_get_class_count(im);
            for (size_t c2 = 0; c2 < nc; ++c2) { const Klass* kc = il2cpp_image_get_class(im, c2); const char* cn = kc ? il2cpp_class_get_name(kc) : nullptr; if (cn && !strcmp(cn, "PhysicsSolver")) { k = (Klass*)kc; break; } }
        }
        if (k) { fi[0] = il2cpp_class_get_field_from_name(k, "ballrestituation"); fi[1] = il2cpp_class_get_field_from_name(k, "edgerestitution"); }
    }
    if (!fi[0] || !fi[1]) return false;
    b = -1234.f; e = -1234.f; il2cpp_field_static_get_value(fi[0], &b); il2cpp_field_static_get_value(fi[1], &e);
    return true;
}
static void logRestitutionLive() {   // while aiming (every 4 s) - this is BEFORE the shot
    static double nl = 0; if (nowSec() < nl) return; nl = nowSec() + 4.0;
    float b, e; if (!readRestitution(b, e)) return;
    logFile("[7] LIVE(aiming, before shot) PhysicsSolver ballrestituation=%.6f edgerestitution=%.6f", (double)b, (double)e);
}
static void logRestitutionShot(const char* tag, double tRel) {   // v37g: AFTER the shot was released (ball moving / finished)
    float b, e; if (!readRestitution(b, e)) { logFile("[7] REST_%s: PhysicsSolver fields not found", tag); shotLog("REST_%s: PhysicsSolver fields not found", tag); return; }
    logFile("[7] REST_%s t=%.2f PhysicsSolver ballrestituation=%.6f edgerestitution=%.6f", tag, tRel, (double)b, (double)e);
    shotLog("REST_%s t=%.2f PhysicsSolver ballrestituation=%.6f edgerestitution=%.6f", tag, tRel, (double)b, (double)e);
}

static void initGame() {
    g_stage = 29;
    logFile("[3] waiting 20s for the game's runtime to finish starting before the first il2cpp call");
    for (int i = 0; i < 40; ++i) usleep(500000);
    g_stage = 30;
    Domain* dom = nullptr;
    for (int i = 0; i < 240 && !dom; ++i) { dom = il2cpp_domain_get(); if (!dom) usleep(500000); }
    if (!dom) { logFile("[3] il2cpp domain never became available"); return; }
    logFile("[3] domain=%p", (void*)dom);
    g_stage = 31;
    if (il2cpp_thread_attach) { il2cpp_thread_attach(dom); logFile("[3] init thread attached to il2cpp"); }
    else logFile("[3] il2cpp_thread_attach export missing - continuing unattached (risky)");
    g_stage = 32;
    bool have = false;
    for (int i = 0; i < 240 && !have; ++i) {
        size_t n = 0; Assembly** as = il2cpp_domain_get_assemblies(dom, &n);
        for (size_t k = 0; as && k < n && !have; ++k) { const char* nm = il2cpp_image_get_name(il2cpp_assembly_get_image(as[k])); if (nm && strstr(nm, "Assembly-CSharp")) have = true; }
        if (!have) usleep(500000);
    }
    if (!have) { logFile("[3] Assembly-CSharp never appeared"); return; }
    logFile("[3] game assembly present");
    g_stage = 33;
    Klass* kv = nullptr; for (int i = 0; i < 240 && !kv; ++i) { kv = findClass("", "CueBallView"); if (!kv) usleep(500000); }
    if (!kv) { logFile("[3] class CueBallView not found (names obfuscated differently in this build?)"); return; }
    logFile("[3] CueBallView found");
    g_stage = 40;
    const Method* m = findMethod(kv, "LateUpdate", 0);
    if (!m) { logFile("[4] CueBallView.LateUpdate not found - NOT hooking"); return; }
    if (!resolve()) { logFile("[4] could not resolve Unity methods (get_transform/get_position/Instantiate/LineRenderer...) - NOT hooking"); return; }
    logFile("[4] all methods resolved");
    g_stage = 50;
    loadCfg();
    g_orig = (void (*)(void*, const Method*))fnptr(m);
    __atomic_store_n(&fnptr(m), (void*)&hooked, __ATOMIC_SEQ_CST);
    logFile("hooked CueBallView.LateUpdate; bounces=%d chain=%d", g_cfg.bounces, g_cfg.chain);
    LOG("hooked");
    g_stage = 60; dumpStatics();   // v37: after the hook is installed, so a fault here (guarded by the init handler) can not cost the lines
    g_stage = 61; dumpFuncs();
}

// v24: EVERYTHING the init thread does (module lookup, dynsym parsing, il2cpp calls) now runs under the fault guard. In pp_report_9 an unnamed thread
// (tid name "app_process64" = our init thread, Unity threads are named) died with SIGSEGV addr 0x135 BEFORE the handler used to be installed.
static void bringUp() {
    bool apiOk = false; const char* how = "";
    for (int i = 0; i < 240 && !apiOk; ++i) {
        g_stage = 1;
        void* h = dlopen("libil2cpp.so", RTLD_NOLOAD);
        if (h && il2::load(h)) { apiOk = true; how = "dlopen"; break; }
        il2::Mod mod;
        g_stage = 2;
        if (il2::findModule("libil2cpp.so", mod)) {
            g_stage = 3;
            if (il2::loadMod(mod)) { apiOk = true; how = "dl_iterate_phdr+dynsym"; g_il2Base = mod.base; logFile("[2] il2cpp module %s base=%p nsym=%d", mod.path, (void*)mod.base, (int)mod.nsym); break; }
            static int w = 0; if (!w++) logFile("[2] libil2cpp.so found (%s) but il2cpp_* exports are missing (nsym=%d)", mod.path, (int)mod.nsym);
        }
        usleep(500000);
    }
    if (!apiOk) { logFile("[2] libil2cpp.so never appeared / exports unusable (waited 120s)"); return; }
    logFile("[2] il2cpp resolved via %s", how);
    logFile("[2] libil2cpp.so + il2cpp api OK");
    initGame();
}

static void* initThread(void*) {
    logFile("[1] payload loaded pid=%d uid=%d dir=%s", (int)getpid(), (int)getuid(), g_dir.c_str());
    struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_sigaction = onSegv; sa.sa_flags = SA_SIGINFO | SA_ONSTACK; sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, &g_old);
    g_tidI = tidNow(); g_inI = 1;
    if (sigsetjmp(g_jbI, 1) == 0) bringUp();
    else logFile("[X] FAULT during init at stage %d addr=%p pc=%p (libil2cpp+0x%lx) - hook aborted, game kept alive", (int)g_stage, (void*)g_fAddr, (void*)g_fPc, (unsigned long)(g_fPc - g_il2Base));
    g_inI = 0;
    // v12: park this thread forever so a runtime that has registered it never signals (pthread_kill) a thread that no longer exists = the SIGABRT in pp_report_9.
    for (;;) sleep(3600);
    return nullptr;
}

__attribute__((constructor)) static void entry() { pthread_t t; pthread_create(&t, nullptr, initThread, nullptr); pthread_detach(t); }
