# PremiumPath — ملف التسليم (للمتابعة في شات تاني)

## الهدف
خطوط مسار جوه اللعبة (com.PoolLiveTour) بنفس شكل خط اللعبة: البيضا ← باند (1|2|3) ← كورة ← مسار الكورة الهدف (باند/كورة/جيب)،
وطول المسار بيتحدد بالباور. من الصفر، بدون أي كود من الأداة القديمة (ReMius/AimTool_106). مفيش أوفرلاي.

## اللي اتعمل
- core/predict_core.hpp : محرك المسارات (C++ نقي). tests/test_core.cpp : 13 اختبار ناجحين  (g++ -std=c++17 tests/test_core.cpp)
- native/il2cpp.hpp     : حل الكلاسات والدوال بالاسم (من غير RVA ثابتة)
- native/payload.cpp    : بيتحمّل جوه اللعبة، بيبدّل methodPointer بتاع CueBallView.LateUpdate، وبيرسم بنسخ من TrajectoryHandler.targetLine
- native/CMakeLists.txt : بناء libpremiumpath.so (محتاج NDK، arm64-v8a)
- الحالة: فحص صياغة على الكمبيوتر بس. **ما اتجرّبش على اللعبة ولا اتبنى بـ NDK.**

## offsets المستخدمة (من dump.cs)
CueBallView: trajectoryHandler 0x20، cueBall 0x28، gameManager 0x30 | TrajectoryHandler.targetLine 0x40
CueBall: scaledDirection 0x1B0، CueRay 0x1F4 (direction عند +0x0C)، IsAiming 0x26D
Ball: radius 0xB4، isCue 0x109، insidePocket 0x10B | GameManager: balls 0xB8، tableTubes 0x190
PhysicsBuilder: previewForce 0x24، levelMaxPower 0x48 (لقيتها بـ FindObjectsByType) | List<T>: _items 0x10، _size 0x18، عناصر المصفوفة من 0x20
فيزياء: drag 0.62، vMax 4.3، نصف قطر الكورة بيختلف حسب الطاولة (0.0325–0.0335، من Ball+0xB4)

## اتضاف في الجولة التانية
- app/ : تطبيق أندرويد (Kotlin، بدون مكتبات) بيعمل بالروت: نسخ libpremiumpath.so لـ /data/local/tmp/pp، setprop wrap.com.PoolLiveTour LD_PRELOAD=..، إعادة تشغيل اللعبة،
  كتابة pp_cfg.txt (on / bounces 1-3 / chain 1-4)، قراءة pp_log.txt، وزرار Remove بيشيل الـ wrap.
- .github/workflows/build.yml : بيثبّت NDK 26 وCMake، بيشغّل اختبارات الفيزياء على الكمبيوتر، وبعدين gradle assembleDebug.
- ما اتبناش ولا اتجرّب على جهاز.

## لسه ناقص / مخاطر معروفة
1. طريقة التحميل wrap/LD_PRELOAD ممكن تترفض (روم مش debuggable، أو SELinux ما يسمحش). لو اللعبة اشتغلت وpp_log.txt فاضي أو مش موجود => الحقن ماحصلش.
   البديل المقترح: injector بـ ptrace يعمل dlopen في اللعبة (مش مكتوب لسه؛ لازم يوقف كل الـ threads وينسخ المكتبة لفولدر اللعبة بدل /data/local/tmp).
2. تقديرات لازم تتظبط من قياسات حقيقية: حدود الباند (inset 0.085 من الجيوب)، فتحة الجيب (corner 0.12 / mid 0.10)، معامل الارتداد (0.75).
   الاقتراح: قراءة PhysicsBuilder.caushions (List<Collider>, 0x50) وCollider.get_bounds وكتابتها في pp_log.txt.
3. تأكيد إن previewForce ÷ levelMaxPower هو فعلاً نسبة الباور، وإن CueRay.direction هو مصدر الاتجاه الصح (الأداة القديمة لاقت scaledDirection أصفار أحياناً).
4. أول تجربة: أوفلاين، شغّل، صوّب، وابعت pp_log.txt + أي رسالة Build لو فشل.
5. التسليم مش بيشمل ولا هيشمل أي حاجة لإخفاء الأداة عن اللعبة أو عن السيرفر.

## ملاحظات
- أي خطأ ذاكرة جوه الرسم بيوقف الميزة (sigsetjmp) ويتسجل في pp_log.txt.
- بعد أي تغيير في المسارات: شغّل tests/test_core.cpp قبل ما تبني.

## الجولة الأخيرة
- السبب الحقيقي لـ "/data/data/com.PoolLiveTour/cache: No such file": اللعبة على يوزر تاني (دوبل ماسنجر 95 / سيكيور فولدر 150). السكريبتات بتلاقي اليوزر (pp_common.sh) وتفتح اللعبة بـ am start --user N.
- diagnose بيطلّع VERDICT وبيحفظ Download/pp_report.txt. الدمج في الأداة اتعمل في AimTool_107.
- v9: الروت من التطبيق كان في namespace معزول (مش شايف فولدر اللعبة). الحل su -mm و/proc/1/root. الهوك بيكتب المراحل في logcat (tag PremiumPath). المكتبة اتحملت فعلاً على الجهاز (logcat dir=... uid=10247).
- v10: [2] كان بيفشل لأن dlopen("libil2cpp.so") من مكتبة LD_PRELOAD بيدور في namespace تاني. بقى بيلاقي الموديول بـ dl_iterate_phdr ويحل رموز il2cpp_* من dynsym (il2cpp.hpp: findModule/loadMod). اتجرّب على libil2cpp وهمية. [3] و[4] لسه ما اتجرّبوش.
- v11: اللعبة كانت بتقع بعد [2] (thread غير متسجل في il2cpp). دلوقتي: انتظار domain + 5ث + il2cpp_thread_attach + انتظار Assembly-CSharp + حارس أخطاء للـ init. diagnose بيضيف crash evidence (tombstone / Fatal signal).

## v12 (من تقرير pp_report_3)
- التقرير: [2] تمام، وبعدها FAULT في stage 30 (أول نداء il2cpp_domain_get) بعد ١٢ms من الحل، واللعبة بتعمل SIGABRT بعد ~1.5ث: "invalid pthread_t passed to pthread_kill" من libil2cpp (الـ GC بيبعت signal لـ thread مات).
- التفسير المرجّح: il2cpp بيسجّل الـ thread اللي بينده API من غير attach، والـ thread بتاعنا بيخلص بعد الـ FAULT => GC يكلّم thread ميت.
- التغيير: (١) انتظار ٢٠ث قبل أول نداء il2cpp (الـ runtime لسه بيبدأ)، (٢) الـ thread مبقاش بيخرج أبداً بعد الـ init (sleep لانهائي)، (٣) عند الـ FAULT بيتسجّل addr و pc و offset جوه libil2cpp.so عشان نعرف الدالة بالظبط.
- لو لسه FAULT: ابعت pp_report وهنقرأ الـ offset. البديل الأسلم: ننفّذ الـ init من جوه thread اللعبة نفسه (هوك على دالة بتتنده كل فريم بدل thread مستقل).

## v13 (من pp_report_4)
- v12 نجح: بعد الانتظار ٢٠ث: domain، attach، Assembly-CSharp، CueBallView، كل الدوال اتحلّت، والهوك اتركّب (مرتين على pid مختلفين) بدون FAULT وبدون وقوع. الـ VERDICT اللي فيه X كان بيقرا لوج قديم.
- v13: diagnose بيقرا آخر تشغيل بس. وإضافة لوج [5]: أول نداء للهوك + نبضة كل ٣ث وقت التصويب (عدد المسارات/الباور/الاتجاه).
- التجربة الجاية: ادخل ماتش أوفلاين، صوّب ٢٠ث، وبعدها Diagnose. لو [5] ظهر والخطوط مش باينة => المشكلة في الرسم (LineRenderer/الـ template).

## v14 (من Download/dump/auto/Table.zip)
- من dump100_table*.txt: مواقع الجيوب وـ ball.radius لطاولات 5/7/9/11 (radius: t5=0.0325، t7=0.0335، t9=t11=0.0275). مفيش حدود باند حقيقية فيها (collider.native=0).
- inset/keep/corner/mid/drag/vmax/lift كلهم أصلاً في pp_cfg.txt (التظبيط من غير بناء).
- v14: لوج [6] مرة لكل ماتش: الجيوب + ball.radius + bounds كل cushion collider (PhysicsBuilder+0x50 -> Collider.get_bounds). بعد ما تبعت pp_log هنحسب inset الحقيقي ونثبّته.

## v15 (من pp_report_5 = تشغيلة v13)
- التقرير: الهوك اتنده فعلاً ([5] hook is being called) بس مفيش ولا نبضة "[5] draw:" => draw() بيخرج بدري (مش بيوصل للـ Sim) أو ماكنش في تصويب. v13 ماكنش بيقول السبب.
- v15: كل خروج بدري من draw() بيتسجّل بسببه: "[5] draw skipped: <reason>" (لما السبب يتغيّر أو كل ٥ث). ومعاه لوج [6] بتاع حدود الكوشن من v14.

## v16 (من pp_report_6 = تشغيلة v15)
- التقرير: لما isAiming=true السبب كان "fewer than 4 pockets read (0)". السبب الحقيقي: GameManager.tableTubes (0x190) فيه كائنات Tube (كلاس عادي، مش Component: startPoint/endPoint) فـ get_transform عليها بيفشل دايماً => صفر جيوب.
- الإصلاح: الجيوب بقت من الكلاس PoolLiveTourMax.GameRules.Pocket (MonoBehaviour، pocketLocation @0x20 قيمها 1..6) عن طريق FindObjectsByType، والمكان من transform.position، واحد لكل pocketLocation. بيتحدّث كل ٣ث.
- نفس نتيجة الـ dump القديم (pocketObj[Top] pos=(-0.0010,-0.0281,0.4284) في طاولة 9).
- بعد كده المفروض يوصل للـ Sim ويظهر [5] draw: tracks=... ولوج [6] (حدود الكوشن).

## v17 (من pp_report_7 = تشغيلة v16)
- v16 نجح في الجيوب: الـ Sim بقى بيطلع مسارات ("[5] draw: tracks=7 ..." إلخ) ومفيش وقوع. لكن المستخدم بيقول مفيش خطوط ظاهرة في اللعبة => الاستنساخ/الرسم بيحصل بس الخط مش باين.
- مشتبه فيهم: الـ clone ورث حالة الـ template (GameObject مش active أو Renderer.enabled=false) أو عرض الخط صفر.
- v17: forceVisible() = SetActive(true) + Renderer.set_enabled(true) + startWidth/endWidth = width (cfg key "width"، افتراضي 0.014) عند الإنشاء وكل فريم. لوج "[7] line0 readback: activeInHierarchy / enabled / positionCount / startWidth" كل ٤ث، و"[4] optional methods: ..." لتأكيد حل الدوال.
- ملاحظة معروفة: power=1.00 دايماً في اللوج (previewForce/levelMaxPower مش بيتقري) => طول المسار مش بيتبع الباور لسه. نتعامل معاه بعد ما الخطوط تظهر.
- اكتشاف تاني من تقرير 7: مواقع الجيوب في اللوج [6] كانت غلط (مثلاً (0.62,-1.70)) لأن Pocket.transform مش هو نقطة الجيب. الأداة القديمة كانت بتاخد pocketObj[..] من orbitPoint (Pocket+0x28). v17 بياخد الموقع من orbitPoint. التحقق: لازم يطلع مثل طاولة 9: Top≈(-0.001,0.428)، BottomLeft≈(-1.16,-0.74).
- لوج [6] بيحاول كل ٢.٦ث (حد أقصى ١٢ مرة) لحد ما PhysicsBuilder يتلقى، عشان حدود الكوشن تتسجّل.

## v18 (من pp_report_8 + 4 صور)
- v17 نجح: الخطوط ظهرت (forceVisible). المشكلة دلوقتي: الخطوط بتبدأ من أماكن الكور الصح لكن اتجاهها غلط (٣٠-٨٠° بعيد عن تصويب اللعبة) والألوان كتير.
- التشخيص: CueRay.direction مش هو اتجاه التصويب الحقيقي. v18 فيه مصدر اتجاه قابل للتغيير من pp_cfg.txt: dirsrc=0 CueRay، 1 scaledDirection، 2 الكورة الشبح (circleBallPosition 0x260 - مكان البيضا) [الافتراضي]، 3 ballAngle (0x1BC) بالدرجات مع angoff/angsgn.
- لوج [8] كل ١.٥ث: زاوية كل مصدر + المصدر المستخدم.
- inset الافتراضي بقى 0.055 (مقاس من الصور: الكورة بتلمس الباند قريب من الجيب أكتر من 0.085).
- أي FAULT في draw بيتسجّل بالمرحلة والـ pc (الـ fault اللي ظهر في report 8 "fault inside draw()" كان من غير تفاصيل).
- (v18) لوج [9]: عدد الكور اللي بتدخل الـ Sim ومكان كل واحدة، كل ١.٥ث. السبب: في صورة IMG_3147 خط البيضا بيعدّي من مركز كورة (893,122 px) من غير ما يقف عندها => غالباً الكور مش داخلة الـ Sim كلها أو مكانها مش مظبوط.

## v19 (من pp_report_9 + صور pool_tables)
- v18 صلّح الاتجاه: scaledDirection والكورة الشبح اتفقوا (125.3°)، وCueRay.direction (-24.3°) هو الغلط. الأرقام اتحققت: الشبح بعيد 0.065 بالظبط عن كورة id=6 (= 2×نصف القطر) => الكورة الهدف صح ومكان بداية خطها صح رياضياً.
- الكور كلها (15) داخلة الـ Sim ومكانها منطقي. الجيوب صح (قيم طاولة 5).
- باج: PhysicsBuilder كلاسه في namespace PoolLiveTourMax.Physic.Handlers، والكود كان بيدوّر عليه في "" => دايماً null => power=1.00 دايماً + لوج [6] حدود الكوشن ما بيطلعش. v19 يصلّحه (الباور من previewForce/levelMaxPower + حدود الكوشن).

## v20 (من شكاوى المستخدم + صور pool_tables + pp_report_10) — لسه ما اتبناش ولا اتجرّب على جهاز
الشكاوى: ألوان متداخلة؛ هامش الباند؛ تصويبة باند ثم هدف الخط بيبعد؛ خط الجيب بيتشد للباند/بيعدّي فوق الجيب؛ خط الاسبين ثابت؛ الباور مش بيأثر؛ الشكل يطابق أداة "الشيتو" (حلقات + لون لكل كورة).
- **الجيب**: الباند كان جدار لانهائي بيمسك الشعاع قبل فتحة الجيب، وخط الجيب كان بيتسحب لمركز الجيب. دلوقتي: عبور الجدار جوه فتحة الجيب (gapc/gapm) أو الشعاع ماشي ناحية الجيب وخطه بيعدي في نصف قطر mouth (corner/mid) => جيب. نهاية الخط بتفضل ON خط التصويب (بدون تثبيت على المركز). اختبارات 9/10/10b.
- **باند ثم هدف**: الاتجاه الافتراضي بقى dirsrc=1 (scaledDirection). الكورة الشبح (dirsrc=2) في ضربة الباند بتبقى بعد الباند فاتجاه البيضا→الشبح غلط. اللوج [8] بيبيّن لو ghost≠scaled.
- **هامش الباند**: لو PhysicsBuilder اتلقى، حدود الكوشن بتتحسب من Collider.get_bounds (الوجه الداخلي ± نصف قطر الكورة، الوسيط لكل جهة) بدل inset المخمّن. اللوج: "[6] MEASURED ball-centre limits". لو فشل: inset (0.055) و"[6] cushion colliders could not be turned..." مع قيم bounds الخام.
- **كور الصينية**: الكور المصابة (id 1,3,7 عند z=-0.91 في report 10) كانت داخلة الـ Sim رغم إنها برا الطاولة. دلوقتي بتتفلتر (inside + 0.06).
- **الباور**: ثابت 1.00 في report 10 => previewForce/levelMaxPower مش بيتقري صح. أضفت لوج "[10] power: float@0x24=... levelMaxPower=..." و"[10] PhysicsBuilder+0xNN: a -> b" (أي float بيتغير وانت بتحرك الباور). المفتاح pwroff/pwrdiv في pp_cfg.txt لتغيير الأوفسيت من غير بناء.
- **الاسبين**: ما كانش في موديل اسبين خالص. أضفت في المحرك: follow/draw بعد الاصطدام بالكورة، وسبين جانبي على الباند (kside/kfollow/kdraw). مفتاح الاسبين جوه CueBall مش معروف => معطّل (spinxoff=spinyoff=0). اللوج "[10] CueBall+0xNN: a -> b" بيطلّع أي float بيتغير وانت بتحرك نقطة الاسبين؛ بعد ما نعرف الأوفسيت: spinxoff=0x.. spinyoff=0x.. (spinsgnx/spinsgny/spinscale للإشارة والمقياس).
- **الشكل**: لون لكل كورة (colormode=0) أو حسب الدور (1)، حلقة الكورة الشبح + حلقة نهاية المسارات (markers)، البيضا بترسم آخر حاجة (فوق)، كل خط أعلى من اللي قبله بـ0.0006 (ما فيش z-fighting). حد الخطوط 30، bounces لحد 6.
- التطبيق: bounces 1..6، chain الافتراضي 2، زرار الألوان، وwrite_cfg.sh بقى بيدمج المفاتيح بدل ما يمسح pp_cfg.txt كله.
- التجربة الجاية (أوفلاين): صوّب ٥ث وحرّك الباور من السلايدر، وبعدها حرّك نقطة الاسبين، ثم Diagnose وابعت التقرير (أنا محتاج سطور [6] و[10]).
- معروف: كراش SIGSEGV ظهر في آخر pp_report_10 بعد ٦٧ث من آخر لوج للهوك (مش جوه draw: ما فيش "fault inside draw()"). السبب غير معروف؛ ابعت tombstone لو اتكرر.

## v21 (من pp_report_11 + Readall.txt + Hex_En.txt)
- **سبب "التفعيل بيقفل بعد أول ماتش" وكراش التفعيل واللعبة مفتوحة**: pp_report_11 فيه `fault inside draw() at stage 6 ... feature disabled for this session`. خطوط الرسم (clones من targetLine) كائنات managed مؤشرها محفوظ عندنا بس، فالـ GC كان بيمسحها => مؤشر ميت => fault في stage 6، والنسخة القديمة كانت بتقفل الميزة للجلسة كلها (g_dead). وعند التفعيل بعد ما كانت مطفية كانت بتلمس نفس الخطوط الميتة => كراش.
  الإصلاح: (1) كل clone ماسكه il2cpp_gchandle_new (strong) ويتحرر في releasePool، (2) clone دمّره Unity (تغيير مشهد) بيتعمل من جديد في نفس الخانة بدل ما ensureLine ترجّع null للأبد، (3) أي fault بيصفّر كل الكاش (الخطوط، PhysicsBuilder، الجيوب، الكوشن) وبيرجع بعد ٢ث؛ مش بيقفل إلا بعد ٥ faults في دقيقتين.
- من Readall.txt: CueBall.forceDirectionAfterCollided @0x220 و collidedBallForceDirection @0x22C (اتجاهات اللعبة نفسها بعد أول احتكاك، بتحسب القطع والاسبين). الأداة بتستخدمهم بدل قاعدة الـ90° لو متوافقين مع خط المراكز (dot>0.94) — المفتاح useov=1. لوج "[11] game post-contact".
- من Readall.txt: PhysicsBuilder.horizontalForce@0x20, previewForce@0x24, finalVelocity@0x40, levelMaxPower@0x48. لسه الباور 1.00 في التقارير القديمة؛ شوف سطور [10] في التقرير الجاي (pwroff ممكن يتغير لـ0x20 أو 0x40 من pp_cfg.txt من غير بناء).
- الاسبين: مفيش حقل اسبين UI في Readall. الدوال PhysicsBuilder.PredictCueDirAfterEdgeCollision(Quaternion spinAngel, Vector3 dir, Vector3 normal) وPredictCueDirAfterBallCollision موجودة (الباند بيحسب بيها اللعبة)؛ لو لقينا الـ Quaternion بتاع الاسبين نقدر نندهها من il2cpp مباشرة ونوصل لدقة اللعبة نفسها.
- ما اتبناش بـ NDK ولا اتجرّب على جهاز: اختبارات المحرك (23) نجحت وفحص صياغة الـ payload نجح.

## v22 (من dump.cs + ApplySpin_verified + UpdateHorizontalForce_candidate)
- UpdateHorizontalForce_candidate: أول تعليمتين = set_HorizontalForce (str s0,[x0,#0x20]) => horizontalForce فعلاً عند PhysicsBuilder+0x20. الدالة الحقيقية مقطوعة (42 سطر).
- ApplySpin بتقرا من singleton تاني (0xB8/0xC8-0xD0/0xE0-0xEC) ماتحددش. بس dump.cs فيه الكلاسات الصح للاسبين:
  SpinController (PoolLiveTourMax.Gameplay.Shot, SingeltonNetwork): spinFactorx@0x11C spinFactory@0x120 (float)، spinFactor/spinAngelDeg NetworkVariable.
  ClientSpinController (PoolLiveTourMax.Client.UI): vertical@0x3C horizontal@0x40 radius@0x44.
- payload: بيلاقيهم بـ FindObjectsByType، لوج "[12] spin:" كل ٢ث، ومفتاح spinsrc (0 SpinController، 1 ClientSpinController، 2 مقفول). لو spinxoff/spinyoff مش مظبوطين بيستخدم المصدر ده. الإشارة/المقياس: spinsgnx/spinsgny/spinscale.
- التطبيق: زراير Power calibration (Start/Read/Apply) + Spin (Read / Src 0 / Src 1 / Off) في الشاشة والزر العايم (FloatingService).
- ما اتبناش بـ NDK ولا اتجرّب على جهاز: فحص صياغة payload.cpp نجح (g++ -fsyntax-only مع stub لـ android/log.h) واختبارات المحرك نجحت.

## v23 (من Hex_En.txt: فك الهيكس بتاع الفيزياء بدل التخمين)
**اتأكد من الهيكس (مش تخمين):**
- PhysicsSolver.cctor: `mov w8,#0x851f; movk w8,#0x3f6b,lsl 16` = float 0.92، و`dup`+`str d0,[statics]` بيكتب القيمة في الاتنين: ballrestituation(0x0) = edgerestitution(0x4) = **0.92**.
- BallToEdgeCollisionDir(vin, n): `(vin - 2(vin·n)n) * edgerestitution` => انعكاس مرآة صافي والسرعة × 0.92 بعد كل باند. (الأداة كانت 0.75 => طول الخط بعد الباند كان غلط.)
- PredictCueDirAfterEdgeCollision(spinAngel, dir, n): نفس المرآة، وبعدها الاتجاه بيتلف بالـ Quaternion بتاع الاسبين (استدعاء Quaternion*Vector3 @0x6c143b4).
- BallToBallCollisionDir: سرعة الكورة المضروبة بتتضرب في ballrestituation (0.92) وتتخزن في Ball+0x168/0x170. PredictTargetBallAfterCollision: مركّبة الهدف على خط المراكز والبيضا بتاخد المماس (نفس نموذج المحرك).
- Ball: الأداة بقت بتقرا اللون الحقيقي من Ball.color@0xF8 (كان بيتحدد من رقم في الليستة فبيتلخبط).
- GamePhysics.drag@0x34: بيتقرا كل ماتش (autophys=1) بدل 0.62 الثابتة.
**اتغير:** cushionKeep/ballKeep = 0.92، ارتدادات لحد 12، عمق كور لحد 6، عدد خطوط قابل للتحكم (maxlines 1..60)، دواير الجيوب (خافتة، وبتنوّر أخضر/أصفر لما مسار ينتهي فيها)، لوج [13] بقيم الطاولة/الفيزياء، واجهة جديدة (بالعرض + زر تحكم رئيسي)، الباور زرار واحد (اضغط مرتين)، اتشالت أزرار المعايرة التجريبية.
**لسه مش متأكد منه (محتاج لوج من جهازك):** (1) زاوية الاسبين على الباند (spinAngel مخزّنة في NetworkVariable، أوفست غير معروف) => نموذج kside/kfollow/kdraw تقديري لحد ما نقرأ الـ [12]. (2) صيغة الباور: PredictedFinalVelocity بتستخدم levelMaxPower@0x48/0x4C وclamp لـ20، الهيكس مقطوع قبل الجزء الأخير؛ استمر على [10]. (3) vMax=4.3 قيمة قديمة. (4) ما اتبناش بـ NDK/Kotlin ولا اتجرّب على جهاز: فحص صياغة C++ نجح + 23 اختبار محرك نجحوا.

## v24 (من pp_report_9: مشكلة الكراش)
- التقرير فيه 4 كراشات كلها **قبل** تشغيلة التقرير (06:43–06:53؛ التقرير 08:48، والتشغيلة pid 9071 اتحمّلت وعمل hook من غير وقوع).
  (أ) SIGABRT x3: "invalid pthread_t passed to pthread_kill" من libil2cpp (الـ GC بيبعت signal لـ thread مات) = نفس تشخيص v12 (thread الحقن بيخرج). v12+ بيخلّيه يعيش للأبد.
  (ب) SIGSEGV addr 0x135 على thread اسمه app_process64 (= thread الحقن، threads يونتي ليها أسماء). حصل قبل ما handler الحماية يتركّب (كان بيتركّب بعد [2]).
- v24: كل شغل thread الحقن (إيجاد الموديول + قراءة dynsym + il2cpp) بقى جوه حارس الأخطاء من أول سطر (bringUp()). لو حصل fault يتسجل "[X] FAULT during init at stage N" (1=dlopen/load 2=findModule 3=loadMod) واللعبة تفضل شغالة.
- diagnose.sh: بقى يعرض بس الكراشات بعد آخر "payload loaded" ويطبع آخر 3 tombstones (مع أي frame من libpremiumpath).
- لسه مش معروف: مصدر SIGSEGV 0x135 بالظبط (التقرير ما فيهوش الـ backtrace بتاعه). لو اتكرر ابعت Diagnose بعد الكراش مباشرة.

## v25 (من pp_report_12)
- **SIGBUS 13:33** (tid app_process64، pc داخل libpremiumpath.so فوق __pthread_start): الـ install.sh كان بينسخ الـ .so فوق الملف وهو متحمّل في لعبة شغّالة => الملف بيتقصّ تحت العملية. الحل: force-stop الأول، نسخ لـ .new، ثم mv (inode جديد).
- **SIGSEGV 13:42** (tid 5899 = ثريد اللعبة): "fault inside draw() at stage 6 addr=0xe4f08020 pc=libil2cpp+0x33677ec" وبعده الماتش وقع. سطر "E CRASH signal 11" (هاندلر يونتي) طلع قبل سطر الحارس بتاعنا بـ1.7ث ثم اللعبة ماتت بعدها بـ4ث. الاستنتاج: يونتي بيركّب هاندلره بعدنا فبيتنادى الأول وبيقتل العملية، فحارسنا ما كانش بيحمي. v25: ensureHandler() كل ٢ث بيعيد تركيب هاندلرنا فوق هاندلر يونتي. (نفس السبب غالباً لـ"التفعيل بيقفل").
- الفولت نفسه: pc داخل libil2cpp قريب من دوال الـ metadata المساعدة (0x3365xxx)، addr=0xe4f08020 مش مؤشر طبيعي => غالباً كائن clone مُحرَّر/متعاد استخدام ذاكرته. v25: validLine() بيقارن klass الـ clone بـ klass القالب قبل أي استخدام، وكل clone غلط بيتعمل من جديد؛ وبعد تغيّر الماتش/القالب بينتظر ثانية قبل أول رسم؛ لوج "[4] new match/template ... gchandle new=1 free=1".
- diagnose.sh بقى يطبع لوج Unity "CRASH" (فيه الـ stack الكامل اللي هيحدد الدالة).
- من [10] في التقرير: levelMaxPower=4.3 => vMax=4.3 اتأكدت من اللعبة نفسها. previewForce=0 (مش الباور)، horizontalForce=2.2030، finalVelocity=1.4242. لسه محتاج حركة سلايدر الباور عشان نعرف أنهي حقل بيتحرك.

## v26 (من سؤال المستخدم: زرار يقرا الناقص + شكل الخطوط)
- **زرار "قراءة الناقص: باور + اسبين"** (الشاشة الرئيسية + الزر العايم، الزر العايم بيعرض العد التنازلي على الفقاعة P28..S1). الـ app بيكتب `cap=<رقم جديد>` في pp_cap، والـ payload (capTick جوه الهوك) بيعمل:
  1. يفرّغ كود الآلة (0x500 بايت) لكل دالة اسمها فيه ApplySpin / HorizontalForce / FinalVelocity / LevelPower / PredictedFinal / GetPower / SetPower / SpinAngel / UpdatePower في **كل** كلاسات Assembly-CSharp (بالاسم، فبيطلّع كلاس الـ singleton المجهول بتاع ApplySpin) => سطور `[M] ns.Class::Method rva=0x..` + هيكس.
  2. مرحلة باور (٢٨ث): بياخد min/max/عدد التغييرات لكل float في PhysicsBuilder(0x10..0x90) وCueBall(0x1A0..0x320) والـ spin classes؛ مرحلة اسبين (٢٨ث) نفس الكلام؛ وسطر زمني كل 0.4ث (t= ... PB 20/24/40/48 | SC 11C/120 | CS 3C/40/44).
  3. الملخص في آخر pp_cap.txt (`--- POWER phase ...` / `--- SPIN phase ...` / `=== CAPTURE DONE`) ويتنسخ لـ Download/pp_cap.txt.
  - لازم المستخدم يبقى في ماتش أوفلاين وفي دوره (بيصوّب) أثناء الـ ٥٦ ثانية. قيمة cap القديمة في الـ cfg ما بتبدأش قراءة عند فتح اللعبة.
- **كراش**: (أ) حارس إعادة الدخول في onSegv (thread_local depth + ما نناديش نفسنا) عشان هاندلر يونتي وهاندلرنا ما يلفّوش على بعض. (ب) resetAll بقى بيحط الخطوط القديمة في g_pending وdrainPending() بيخبّيها ويحرر الـ gchandle من جوه مسار الرسم المحمي (كان بيسرّبها وتفضل ظاهرة).
- **الشكل**: نهاية مسار الكورة الهدف بقت نقطة مليانة بلون الكورة (حلقة رفيعة صغيرة بعرض كبير) زي الأداة المرجعية؛ الحلقة بتفضل عند الكورة الشبح؛ مفتاح `dots=0` يرجّعها حلقة. الألوان من Ball.color@0xF8 (colormode=0).
- ما اتبناش بـ NDK/Gradle ولا اتجرّب على جهاز: فحص صياغة payload.cpp نجح + اختبارات المحرك نجحت. عدم استخدام فاصل تعليق كتلة في ملفات Kotlin متراعى.

## v27 (ايم اسيست من AimTool_100)
- الايم اسيست في AimTool_100 = تعديل تعليمتين جوه CueBall.get_canDrawTarget (rva 0x5DD6EC0: `mov x1,xzr`→`mov w0,#1`، و0x5DD6EC8: `b GetCurrentTableAimAssistState`→`ret`) بحيث الرسم بس يشوف الحالة true وباقي المستدعين (البوت) يشوفوا القيمة الحقيقية. اتنقل كما هو لـ assets/aimassist.sh (كتابة بالروت عبر /proc/pid/mem، نفس طريقة الأداة القديمة).
- أمان: بيتحقق من بصمة libil2cpp (الـ4 كلمات حوالين get_LineLenght) والتعليمتين الأصليتين قبل أي كتابة، ولو مش متطابقين بيرفض ومايكتبش. ترتيب الكتابة: ret الأول ثم mov (والعكس عند الإيقاف). زر واحد بيبدّل (بيقرا الحالة الحالية بنفسه): الشاشة الرئيسية + شريحة "ايم" في الزر العايم.
- التعديل في الذاكرة بس: بعد إعادة تشغيل اللعبة اضغط الزر تاني. الـ RVAs لنسخة اللعبة اللي اتعمل عليها AimTool_100؛ لو اللعبة اتحدّثت البصمة هترفض.
- الاختبار: منطق السكربت اتجرّب على ملف ذاكرة وهمي (تشغيل → إيقاف → تشغيل)؛ ما اتجرّبش على اللعبة.

## v28 (الزر العايم)
- من صورة المستخدم: لما بيفتح الزر العايم القايمة كانت بتطلع عمود ضيق (بعرض فقاعة الـ48dp) والأزرار مقطوعة. السبب: الـ panel كان match-parent جوه box من نوع wrap-content فاخد عرض الفقاعة. الإصلاح: عرض صريح للـ panel والـ ScrollView (250dp / 280dp بالعرض، ومش أكبر من الشاشة)، والقايمة بتتزحزح لفوق/شمال لو هتخرج برا الشاشة، وشرايح الألوان/الجيوب/الباور/الاسبين/ايم اسيست في صفّين.
- القايمة بقت أزرار التشغيل بس (تشغيل/إيقاف، ارتدادات، عمق، عدد خطوط، ألوان، جيوب، باور، اسبين، ايم اسيست، قراءة الناقص، إغلاق). التثبيت والتشخيص والإزالة في شاشة التطبيق بس.
- ما اتبناش ولا اتجرّب على جهاز.

## v29 (واجهة جديدة + سكرول الزر العايم)
- الشكل: أسود فاخر + أحمر دموي مشع (CYAN="#FF2A44" بقت لون التمييز، الاسم اتساب عشان كل الاستدعاءات تفضل شغالة) + عناوين ذهبية. توهج الأزرار بإطار شفاف عريض (Ui.glow). الفقاعة بقت وش البنت (res/drawable-nodpi/bubble_face.png، مقصوصة من الصورة لحد الصدر) بإطار أحمر، وعليها شارة صغيرة بتعرض العد التنازلي لزرار القراءة.
- التنظيم: خانتين مميزتين: "الخطوط" (تشغيل/إيقاف + ارتدادات + عمق + عدد الخطوط) و"الأدوات" (ألوان، جيوب، باور، اسبين، ايم اسيست، قراءة الناقص). زرار ⚙ الإعدادات بيفتح/يقفل خانة الإعدادات (تثبيت، الزر العايم، تشخيص، إزالة، وفي العايم: إغلاق). نفس التقسيم في شاشة التطبيق وفي الزر العايم.
- السكرول: القايمة العايمة بقت بحجم ثابت (ScrollView بارتفاع ثابت + شريط حالة بارتفاع ثابت) وكان السبب إن نص الحالة جوه منطقة السكرول بيكبّر الشاشة (النافذة) كل ما يتغيّر. الإعدادات بتفتح فوق والسكرول بيرجع للأول.
- ما اتبناش ولا اتجرّب على جهاز؛ ملف Kotlin ما فيهوش فاصل تعليق كتلة.

## v31 UI-only continuation (2026-10-19)
- Floating overlay no longer uses `FLAG_LAYOUT_NO_LIMITS`.
- The floating button and expanded panel are clamped against measured overlay bounds when possible, with estimates as a fallback during drag.
- Scroll area height adapts to shorter screens and the lines/tools controls remain inside the Settings section so they can be reached by scrolling.
- No changes were made to game physics, spin, aim prediction, trajectory calculations, or native payload behavior in this continuation.
- Build/device verification remains pending because Gradle/Android SDK are not installed in the working environment.

## v27 (من pp_cap_2 + pp_report_14 + صورة الواجهة)
- الاسبين: ClientSpinController vertical@0x3C / horizontal@0x40 بالبكسل (radius@0x44=60) اتحركوا -60..60 في الكابتشر => الـ payload بيقسمهم على الـ radius (spinsrc=1 هو الافتراضي دلوقتي). SpinController 0x11C/0x120 مش موضع النقطة.
- الباور: finalVelocity@0x40 ÷ levelMaxPower@0x48 (levelMaxPower بيتغير 4.3 -> 5.3 حسب الليفل، فمفيش pwrdiv ثابت). pwroff=64 و pwrdiv=0 افتراضي، والتثبيت بيكتبهم في pp_cfg.txt عشان يمسح القديم (pwroff=32/pwrdiv=1 من powerTest القديم كان بيخلي الباور 1.00).
- الكراش: كان في "stage 90" (قبل أول مرحلة في draw) كل 3 ثواني بعد ما اللوحة تعمل reset. اتقسمت المنطقة العمياء: 91 فحوصات CueBallView/isAiming، 92 targetLine، 93 drainPending، 94 getPos/radius، 95 capTick. drainPending بقى بس يفك الـ gchandle من غير ما يندهي أي دالة على clone قديم (ممكن يكون Unity دمّره)؛ ولو وقع في 93 بيتقفل نهائياً.
- **التقرير الجاي لازم يبيّن رقم الـ stage الجديد**؛ لو لسه 94 يبقى المشكلة في cue ball transform (getPos).
- الواجهة: الـ ScrollView مخفي لحد ما تفتح الإعدادات (كان بياخد 34% من الشاشة فاضي)، سطر الحالة 13sp، وإطار الأزرار أفتح.
- ما اتبناش بـ NDK/Gradle ولا اتجرّب على جهاز؛ C++ اتفحص بـ g++ -fsyntax-only (مع stub للـ android/log.h) والـ 23 اختبار نجحوا.

## v28 (من pp_report_15 + pp_cap_3 + لقطات الشاشة)
- الكراش اتحل: بعد آخر تحميل مفيش fault في draw()؛ التومبستونز اللي في التقرير قديمة (06:52 و13:33 قبل آخر تحميل 22:39).
- الباور الصح: PhysicsBuilder+0x20 (horizontalForce) بيطلع خطي 0 -> levelMaxPower (4.3) مع السلايدر. +0x40 (finalVelocity) = السرعة عند أول تصادم = 0x20 ناقص خسارة ثابتة للتصويبة (0.971 و 0.536 في الكابتشر) فمينفعش يتقسم عليه (الـ sim بيطبق الـ drag بنفسه). pwroff=32 و pwrdiv=0 افتراضي، والصفر = السلايدر تحت مش "مجهول".
- الاسبين اتأكد: ClientSpin horizontal@0x40 و vertical@0x3C ÷ radius(60)؛ القيمة -31.5/-40.4 قابلت النقطة تحت-يسار في اللقطة الثالثة، فالإشارات الافتراضية (+1) غالباً صح.

## v29 (شكوى: الخط مش بيقف مكان الكورة بالظبط + الاسبين بعد الباند مش ماشي مع حركة النقطة)
- ماغيّرتش موديل الفيزيا (kSide=0.25 / kFollow / kDraw / drag) لأن مفيش بيانات حقيقية تقول القيم الصح؛ ثوابت الاسبين على الباند كانت تخمين.
- أضفت shot recorder في payload: كل تصويبة بتتكتب في pp_shots.txt: التوقع (power, dir, spin, مسارات كل track ونهاياتها، مواقع الكور قبل الضرب) جنب الحقيقة (مسار الكورة البيضا كل 0.04ث لحد ما توقف، ومواقع كل الكور في الآخر، P = في الجيب). الملف بيتفرغ لو عدّى 150KB.
- زر "حفظ تسجيل التصويبات" في الإعدادات بينسخه لـ Download/pp_shots.txt (read_shots.sh).
- الخطوة الجاية: من التسجيلات نظبط drag و cushionKeep و kSide (وإشارته) بالمقارنة PRED مقابل CUE_REAL.

## v30 (من pp_shots.txt + pp_cap_4.txt)
- النتيجة الحقيقية: الكورة 3 في تصويبة 2 (باند واحد) انتهت (-0.001,0.364) والتوقع (0.000,0.452): الاتجاه والباند صح، الطول زيادة ~7%.
- تصويبة 6: الكورة 4 وقفت بعد 1.1 مش 1.39 لأن اللاعب سحب باور واطي (سرعة البيضا الفعلية ~0.65 u/s) لكن التوقع المسجل كان power=1.0 => لقطة الباور وقت الإفلات غلط (مش خطأ فيزيا).
- pp_cap_4: PhysicsBuilder+0x20 = levelMaxPower (4.3) طول ما اللاعب مش لامس السلايدر، وبيتصفّر بعد الضربة. يعني آخر فريم aim=1 مش بالضرورة فيه قيمة السحب.
- الـ recorder القديم كان بيوقف في أنيميشن العصاية (تصويبات 1/5/9 فاضية) وبيمسك teleport (ball in hand) كأنه تصويبة. اتصلح: ما يوقفش قبل ما الكورة تتحرك >0.02، وبيقفل لو قفزت >0.6، والمسار بقى x,z,t.
- جديد: PWR_RING في كل تصويبة (t_rel/aim/0x20/0x28/0x40 كل 0.04ث من -2ث لـ +1.2ث حوالين الإفلات) علشان نعرف القيمة الصح وقت الإفلات.
- موديل الاحتكاك (v = v0 - drag*s, drag=0.62) متوافق مع شكل التباطؤ الأسي في المسارات الحقيقية.

## v36 (هندسة اللعبة نفسها بدل الموديل — من dump.cs + Hex_En.txt، من غير تسجيل ولا تخمين)
**اتأكد من الهيكس + dump.cs:**
- `CueBall.OnCastCueBall(Vector3 startPos, Vector3 dir, LayerMask castMask, out RaycastHit)` بتعمل tail-call لـ `Physics.SphereCast(origin, radius, direction, out hit, maxDistance, layerMask)` (6 باراميترز، rva 0x6CB674C) ونصف القطر = `Ball.radius` (this+0xB4) + 2 × `Physics.defaultContactOffset` (التعليمات: ldr s8,[x21,#0xb4] / bl get_defaultContactOffset / fadd s0,s11,s11 / fadd s11,s8,s0 / b SphereCast). والـ mask من CueBall.rayCastLayer@0x1C0 (LayerMask).
- الحركة الحقيقية Rigidbody (PhysX)؛ PhysicsBuilder بيعدّل السرعة بعد أحداث التصادم وبيستخدم `Collider.ClosestPointOnBounds`. الباند = `PhysicsBuilder.caushions` (List<Collider> @0x50) كلها MeshCollider (6 أو 8 حسب الطاولة).
- RaycastHit = 44 بايت (point 12، normal 12، faceID 4، distance 4، uv 8، collider instanceID 4).
- **dumps Table.zip مش موثوقة للهندسة:** كل `collider native=0x0` وقيم الجيوب بتتكرر بين الطاولات (نسخ ميتة من الهيب: 200 PhysicsBuilder / 116 GameTableSetup) — الجيوب الحية بتتقرا من Pocket.orbitPoint عن طريق FindObjectsByType (v17+).

**اتغير:**
- core: `pp::Probe` (واجهة) — `Sim::setProbe`. لو فيه probe: الباند من `cast(p,d,r,maxDist)` (نقطة اللمس + الـ normal الحقيقي)، والانعكاس مرآة حوالين الـ normal الحقيقي (= `PhysicsSolver.BallToEdgeCollisionDir`: vin − 2(vin·n)n، السرعة × 0.92). من غير probe: المستطيل القديم زي ما هو. اختبارات 12/13/14 جديدة (probe بصندوق = المستطيل، حيطة مائلة 45°، الكورة لسه بتقف على كورة).
- payload: `GameProbe` بينده `Physics.SphereCast` الحقيقية على كوليدرات الباند الحية فقط: الـ mask = OR لـ (1<<layer) لكل كوليدر في `caushions`، وأي ضربة مش كوليدر باند (لو الـ layer مشترك مع الكور) بتتخطى والـ cast بيكمل. نصف القطر = radius + `castoff` × defaultContactOffset (افتراضي castoff=2 زي اللعبة).
- pp_cfg.txt: `probe=1` (0 = المستطيل القديم) و`castoff=2`.
- لوج جديد: `[4] probe methods: ...` و`[14] probe: caushions listed/alive layers mask contactOffset` و`[14] geometry: GAME SphereCast | casts hits skipped lastHit t n castRadius` كل 3ث. لو الـ probe ما اشتغلش بيرجع للمستطيل ويكتب السبب.
- الجيوب لسه بالـ mouth/corner/mid (دايرة التقاط) — مش من هندسة اللعبة لسه. الاسبين على الباند لسه الموديل التقديري (مصدر الـ Quaternion بتاع PredictCueDirAfterEdgeCollision لسه ما اتحددش).
- ما اتبناش بـ NDK ولا اتجرّب على جهاز: فحص صياغة payload.cpp نجح، و26 اختبار محرك نجحوا (g++ -std=c++17 tests/test_core.cpp).
- أول تجربة: أوفلاين، صوّب، ابعت pp_log.txt وشوف سطور [14]: لو `GAME SphereCast` ظاهر والعدادات بتزيد يبقى الاستعلام شغال؛ لو `skippedNonCushion` عالي يبقى الـ layer مشترك مع الكور.

## v37 (تحليل الفيزياء: استخراج كود الدوال من اللعبة نفسها)
- الهدف: نقرأ معادلات الفيزياء الحقيقية (PhysicsSolver / PhysicsBuilder.Solve* / HandlePhysicsCollisions) بدل التخمين.
- native/funcs_table.inc (مولّد من dump.cs بـ tools/gen_funcs_table.py): 53 دالة، RVA وطول (لحد أول دالة بعدها) = 21824 بايت.
- payload.dumpFuncs(): بعد تركيب الهوك، بيقرأ base+RVA من ذاكرة libil2cpp ويكتب pp_funcs.txt (hex). بيكتبه لو الملف مش موجود أو لو cfg dumpfn اتغيّر.
  بيسجّل [7] rva check: أول كلمة في CueBall.ApplySpin لازم تبقى 0x6dbb2beb (من ApplySpin_verified.txt) => يثبت إن base+RVA صح.
- payload.dumpStatics(): بيسجّل [7] PhysicsSolver.ballrestituation / edgerestitution (الـ static) عن طريق il2cpp_field_static_get_value.
- التطبيق: "طلب تسجيل دوال الفيزياء" (بيكتب dumpfn) و"حفظ دوال الفيزياء" (read_funcs.sh -> Download/pp_funcs.txt).
- tools/disasm_funcs.py + workflow "Disassemble physics functions": بيفك الـ hex لأسمبلي ARM64 (capstone) ويطلّع analysis/physics_asm.txt كـ artifact.
- tools/extract_physics_asm.py: بديل لو عندك libil2cpp.so + llvm-objdump على كمبيوتر.
- ما اتبناش بـ NDK ولا اتجرّب على جهاز: فحص صياغة على الكمبيوتر بس + اختبارات الفيزياء (ALL PASSED).
- الناقص بعد ده: physics_asm.txt (بعد ما تبعته نحوّل المعادلات لـ predict_core.hpp)، وتسجيل ضربات حقيقية للمقارنة.
